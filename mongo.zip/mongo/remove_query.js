

var startTime = new Date();

db.Patient.update(
   { },
   { $unset: { new_field: "" } },
   { multi: true }
);


// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for deleting a column : " + timeTaken + " milliseconds");