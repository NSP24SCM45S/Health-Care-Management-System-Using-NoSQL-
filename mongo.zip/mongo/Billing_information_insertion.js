// Record the start time
var startTime = new Date();

// Your insertion operation with the current date as admissionDate
db.Billing_information.insertMany([
 {
   "policy_number": 845558,
   "phone_number": 6554312068,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Won",
   "payment_status": "Partial",
   "patient_id": 619486079
 },
 {
   "policy_number": 290575,
   "phone_number": 4578859079,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 892708688
 },
 {
   "policy_number": 745381,
   "phone_number": 3178531339,
   "insurance_provider": "Cigna",
   "billing_amount": "Naira",
   "payment_status": "Paid",
   "patient_id": 22195242
 },
 {
   "policy_number": 117516,
   "phone_number": 4537755142,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Partial",
   "patient_id": 668808523
 },
 {
   "policy_number": 175910,
   "phone_number": 8723684055,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 467612663
 },
 {
   "policy_number": 621702,
   "phone_number": 7845274897,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 61715603
 },
 {
   "policy_number": 206404,
   "phone_number": 2509749117,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 412618858
 },
 {
   "policy_number": 958981,
   "phone_number": 9024801713,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 947226484
 },
 {
   "policy_number": 635043,
   "phone_number": 8937113816,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 801335117
 },
 {
   "policy_number": 537629,
   "phone_number": 4512939323,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Unpaid",
   "patient_id": 737229538
 },
 {
   "policy_number": 912164,
   "phone_number": 1792649405,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 636959196
 },
 {
   "policy_number": 726738,
   "phone_number": 3266925290,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 299616270
 },
 {
   "policy_number": 412349,
   "phone_number": 8874450519,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 998132204
 },
 {
   "policy_number": 821611,
   "phone_number": 4851509116,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 676991253
 },
 {
   "policy_number": 885507,
   "phone_number": 6434628507,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 535659829
 },
 {
   "policy_number": 794947,
   "phone_number": 9857044882,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 997566304
 },
 {
   "policy_number": 219518,
   "phone_number": 1905466676,
   "insurance_provider": "Cigna",
   "billing_amount": "Kuna",
   "payment_status": "Partial",
   "patient_id": 518353983
 },
 {
   "policy_number": 107508,
   "phone_number": 9699242987,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 973884491
 },
 {
   "policy_number": 259774,
   "phone_number": 2872742338,
   "insurance_provider": "Cigna",
   "billing_amount": "Rand",
   "payment_status": "Unpaid",
   "patient_id": 19218704
 },
 {
   "policy_number": 580570,
   "phone_number": 2506931009,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rand",
   "payment_status": "Unpaid",
   "patient_id": 270549175
 },
 {
   "policy_number": 460683,
   "phone_number": 6503047059,
   "insurance_provider": "Cigna",
   "billing_amount": "Quetzal",
   "payment_status": "Unpaid",
   "patient_id": 209923864
 },
 {
   "policy_number": 421810,
   "phone_number": 2496453292,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 137555123
 },
 {
   "policy_number": 425945,
   "phone_number": 6409716540,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 140977191
 },
 {
   "policy_number": 716072,
   "phone_number": 7656049794,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 636359507
 },
 {
   "policy_number": 738208,
   "phone_number": 4687899618,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 70148713
 },
 {
   "policy_number": 872498,
   "phone_number": 4453033515,
   "insurance_provider": "Cigna",
   "billing_amount": "Birr",
   "payment_status": "Unpaid",
   "patient_id": 383354783
 },
 {
   "policy_number": 916931,
   "phone_number": 9629010010,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 704120718
 },
 {
   "policy_number": 409179,
   "phone_number": 4888606222,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 268909923
 },
 {
   "policy_number": 481330,
   "phone_number": 5504784500,
   "insurance_provider": "Aetna",
   "billing_amount": "Shekel",
   "payment_status": "Paid",
   "patient_id": 451085417
 },
 {
   "policy_number": 256833,
   "phone_number": 5502355438,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Shilling",
   "payment_status": "Paid",
   "patient_id": 175968229
 },
 {
   "policy_number": 105345,
   "phone_number": 3494092446,
   "insurance_provider": "Aetna",
   "billing_amount": "Dram",
   "payment_status": "Partial",
   "patient_id": 610584136
 },
 {
   "policy_number": 192006,
   "phone_number": 7073186338,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 561344897
 },
 {
   "policy_number": 168007,
   "phone_number": 6073330795,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 998726632
 },
 {
   "policy_number": 384101,
   "phone_number": 1465400067,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 337089339
 },
 {
   "policy_number": 750744,
   "phone_number": 6237463818,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 706231568
 },
 {
   "policy_number": 794885,
   "phone_number": 2395883917,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 918665870
 },
 {
   "policy_number": 456949,
   "phone_number": 7186852413,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Bolivar",
   "payment_status": "Partial",
   "patient_id": 705611321
 },
 {
   "policy_number": 462749,
   "phone_number": 1261422723,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 270932787
 },
 {
   "policy_number": 612825,
   "phone_number": 6474708228,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 223978219
 },
 {
   "policy_number": 999261,
   "phone_number": 3649634542,
   "insurance_provider": "Cigna",
   "billing_amount": "Ringgit",
   "payment_status": "Unpaid",
   "patient_id": 149248170
 },
 {
   "policy_number": 497321,
   "phone_number": 6054953216,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 265070821
 },
 {
   "policy_number": 309917,
   "phone_number": 3893569903,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 545441107
 },
 {
   "policy_number": 370436,
   "phone_number": 6578601002,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 485141889
 },
 {
   "policy_number": 707303,
   "phone_number": 7943020052,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 763165452
 },
 {
   "policy_number": 389961,
   "phone_number": 8634854393,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 685725493
 },
 {
   "policy_number": 405683,
   "phone_number": 7654314642,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 182844664
 },
 {
   "policy_number": 279602,
   "phone_number": 5116548302,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 916677356
 },
 {
   "policy_number": 890717,
   "phone_number": 5816049173,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 357367853
 },
 {
   "policy_number": 750251,
   "phone_number": 8286330705,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 622392191
 },
 {
   "policy_number": 643001,
   "phone_number": 5518155496,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 43273828
 },
 {
   "policy_number": 505277,
   "phone_number": 9501625380,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 86155929
 },
 {
   "policy_number": 694732,
   "phone_number": 5536077578,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 507055576
 },
 {
   "policy_number": 492480,
   "phone_number": 4767743188,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 307893801
 },
 {
   "policy_number": 182820,
   "phone_number": 3541282276,
   "insurance_provider": "Cigna",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 663957156
 },
 {
   "policy_number": 792093,
   "phone_number": 2143578312,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 714333176
 },
 {
   "policy_number": 821575,
   "phone_number": 9722665173,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 400106479
 },
 {
   "policy_number": 488100,
   "phone_number": 6181078987,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 995096308
 },
 {
   "policy_number": 263875,
   "phone_number": 7846888989,
   "insurance_provider": "Cigna",
   "billing_amount": "Dirham",
   "payment_status": "Paid",
   "patient_id": 798502775
 },
 {
   "policy_number": 777270,
   "phone_number": 3011768139,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 419853502
 },
 {
   "policy_number": 402694,
   "phone_number": 2325129917,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 451414638
 },
 {
   "policy_number": 861354,
   "phone_number": 2436002582,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 568952270
 },
 {
   "policy_number": 704938,
   "phone_number": 7944831878,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 493466447
 },
 {
   "policy_number": 764516,
   "phone_number": 5621436791,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 141915822
 },
 {
   "policy_number": 668629,
   "phone_number": 2312953503,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 244505818
 },
 {
   "policy_number": 919471,
   "phone_number": 9916555186,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 497746884
 },
 {
   "policy_number": 371837,
   "phone_number": 5766556542,
   "insurance_provider": "Aetna",
   "billing_amount": "Som",
   "payment_status": "Unpaid",
   "patient_id": 602220202
 },
 {
   "policy_number": 767308,
   "phone_number": 2372028027,
   "insurance_provider": "Aetna",
   "billing_amount": "Kwacha",
   "payment_status": "Paid",
   "patient_id": 428589723
 },
 {
   "policy_number": 588664,
   "phone_number": 4497512022,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 281852462
 },
 {
   "policy_number": 477762,
   "phone_number": 8789797135,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 819361042
 },
 {
   "policy_number": 426411,
   "phone_number": 1266694087,
   "insurance_provider": "Cigna",
   "billing_amount": "Lempira",
   "payment_status": "Unpaid",
   "patient_id": 893389209
 },
 {
   "policy_number": 643272,
   "phone_number": 7711441781,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 84494254
 },
 {
   "policy_number": 732707,
   "phone_number": 3705356691,
   "insurance_provider": "Cigna",
   "billing_amount": "Lev",
   "payment_status": "Unpaid",
   "patient_id": 533454936
 },
 {
   "policy_number": 702338,
   "phone_number": 3484958258,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 819542153
 },
 {
   "policy_number": 104574,
   "phone_number": 9939095785,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 428101685
 },
 {
   "policy_number": 722550,
   "phone_number": 8259654346,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 237724864
 },
 {
   "policy_number": 868825,
   "phone_number": 5461177113,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Paid",
   "patient_id": 807574651
 },
 {
   "policy_number": 221927,
   "phone_number": 7815157761,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 356217138
 },
 {
   "policy_number": 396664,
   "phone_number": 4473728771,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 264503896
 },
 {
   "policy_number": 954359,
   "phone_number": 5784008729,
   "insurance_provider": "Aetna",
   "billing_amount": "Kwanza",
   "payment_status": "Unpaid",
   "patient_id": 332749365
 },
 {
   "policy_number": 877757,
   "phone_number": 6615943457,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 110885783
 },
 {
   "policy_number": 348206,
   "phone_number": 5871926631,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 435852138
 },
 {
   "policy_number": 974985,
   "phone_number": 9669049909,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 23289163
 },
 {
   "policy_number": 612903,
   "phone_number": 8509357188,
   "insurance_provider": "Aetna",
   "billing_amount": "Krone",
   "payment_status": "Partial",
   "patient_id": 210758845
 },
 {
   "policy_number": 915704,
   "phone_number": 6018644563,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 420377926
 },
 {
   "policy_number": 376593,
   "phone_number": 4518915594,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 71883115
 },
 {
   "policy_number": 583113,
   "phone_number": 3569498153,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 519021437
 },
 {
   "policy_number": 437616,
   "phone_number": 1867605571,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 819499806
 },
 {
   "policy_number": 975210,
   "phone_number": 2689358263,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 357174398
 },
 {
   "policy_number": 664316,
   "phone_number": 3941948390,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 118718403
 },
 {
   "policy_number": 394981,
   "phone_number": 6228907487,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Shekel",
   "payment_status": "Unpaid",
   "patient_id": 682730119
 },
 {
   "policy_number": 669439,
   "phone_number": 2135001220,
   "insurance_provider": "Aetna",
   "billing_amount": "Dong",
   "payment_status": "Paid",
   "patient_id": 779692843
 },
 {
   "policy_number": 699593,
   "phone_number": 8484514851,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 966561466
 },
 {
   "policy_number": 368174,
   "phone_number": 4966710856,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 428639568
 },
 {
   "policy_number": 849497,
   "phone_number": 2351374849,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 872993792
 },
 {
   "policy_number": 641204,
   "phone_number": 8634885339,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 211820509
 },
 {
   "policy_number": 250387,
   "phone_number": 6007823632,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 973051723
 },
 {
   "policy_number": 565366,
   "phone_number": 8269927821,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 402541488
 },
 {
   "policy_number": 315629,
   "phone_number": 7827642471,
   "insurance_provider": "Cigna",
   "billing_amount": "Shekel",
   "payment_status": "Partial",
   "patient_id": 812263271
 },
 {
   "policy_number": 136977,
   "phone_number": 7303189505,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 486519720
 },
 {
   "policy_number": 287979,
   "phone_number": 7744005635,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 263114127
 },
 {
   "policy_number": 814243,
   "phone_number": 7936988122,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 363429428
 },
 {
   "policy_number": 390559,
   "phone_number": 2496529684,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 980267652
 },
 {
   "policy_number": 179325,
   "phone_number": 2214170577,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 625704501
 },
 {
   "policy_number": 726600,
   "phone_number": 6644144629,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 27052530
 },
 {
   "policy_number": 547797,
   "phone_number": 2663677999,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 580152369
 },
 {
   "policy_number": 718685,
   "phone_number": 6067737693,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 665158476
 },
 {
   "policy_number": 710722,
   "phone_number": 8753211681,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 868965426
 },
 {
   "policy_number": 739311,
   "phone_number": 2324339290,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 170168746
 },
 {
   "policy_number": 707584,
   "phone_number": 3252097311,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 850786317
 },
 {
   "policy_number": 348257,
   "phone_number": 8699059961,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 986935235
 },
 {
   "policy_number": 774092,
   "phone_number": 2058685248,
   "insurance_provider": "Aetna",
   "billing_amount": "Shilling",
   "payment_status": "Unpaid",
   "patient_id": 330037848
 },
 {
   "policy_number": 727912,
   "phone_number": 8895315493,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 863907370
 },
 {
   "policy_number": 587264,
   "phone_number": 6683634437,
   "insurance_provider": "Aetna",
   "billing_amount": "Lev",
   "payment_status": "Partial",
   "patient_id": 637676207
 },
 {
   "policy_number": 605679,
   "phone_number": 1055382806,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 355755490
 },
 {
   "policy_number": 924581,
   "phone_number": 5542505514,
   "insurance_provider": "Aetna",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 758980115
 },
 {
   "policy_number": 673109,
   "phone_number": 4343803047,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 927568245
 },
 {
   "policy_number": 357520,
   "phone_number": 9524993120,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 556553122
 },
 {
   "policy_number": 590634,
   "phone_number": 6352823724,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 265104769
 },
 {
   "policy_number": 585730,
   "phone_number": 4929162997,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 495145350
 },
 {
   "policy_number": 630715,
   "phone_number": 6672917497,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 542987340
 },
 {
   "policy_number": 182644,
   "phone_number": 8803504027,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 343416509
 },
 {
   "policy_number": 125342,
   "phone_number": 4826277840,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 879419974
 },
 {
   "policy_number": 744636,
   "phone_number": 3824446567,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 465471842
 },
 {
   "policy_number": 692229,
   "phone_number": 5964648350,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 394561574
 },
 {
   "policy_number": 566214,
   "phone_number": 1271301315,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 678980314
 },
 {
   "policy_number": 710933,
   "phone_number": 4125243814,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 628975390
 },
 {
   "policy_number": 274332,
   "phone_number": 3459272863,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 786632343
 },
 {
   "policy_number": 521953,
   "phone_number": 8596761223,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Shekel",
   "payment_status": "Partial",
   "patient_id": 780389679
 },
 {
   "policy_number": 458394,
   "phone_number": 7013672258,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 894988093
 },
 {
   "policy_number": 654515,
   "phone_number": 8846716157,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 85912857
 },
 {
   "policy_number": 318318,
   "phone_number": 8777127595,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 464105653
 },
 {
   "policy_number": 954103,
   "phone_number": 3476929232,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 501240471
 },
 {
   "policy_number": 643272,
   "phone_number": 1601928923,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 736976614
 },
 {
   "policy_number": 240231,
   "phone_number": 4462166172,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Unpaid",
   "patient_id": 189195112
 },
 {
   "policy_number": 435780,
   "phone_number": 7619515949,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 970400818
 },
 {
   "policy_number": 944106,
   "phone_number": 6822275406,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Litas",
   "payment_status": "Paid",
   "patient_id": 328916208
 },
 {
   "policy_number": 908714,
   "phone_number": 2211213240,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 725137844
 },
 {
   "policy_number": 620253,
   "phone_number": 4434648771,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 878816364
 },
 {
   "policy_number": 921622,
   "phone_number": 3407280334,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 645873334
 },
 {
   "policy_number": 410062,
   "phone_number": 4931783973,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 647910025
 },
 {
   "policy_number": 954157,
   "phone_number": 1476681009,
   "insurance_provider": "Aetna",
   "billing_amount": "Sol",
   "payment_status": "Partial",
   "patient_id": 807001272
 },
 {
   "policy_number": 913101,
   "phone_number": 1362967929,
   "insurance_provider": "Cigna",
   "billing_amount": "Litas",
   "payment_status": "Paid",
   "patient_id": 345537363
 },
 {
   "policy_number": 431014,
   "phone_number": 1157617804,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 972176057
 },
 {
   "policy_number": 538869,
   "phone_number": 3723162187,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 923473238
 },
 {
   "policy_number": 816649,
   "phone_number": 7745982760,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 923137516
 },
 {
   "policy_number": 721013,
   "phone_number": 4001534977,
   "insurance_provider": "Aetna",
   "billing_amount": "Guarani",
   "payment_status": "Partial",
   "patient_id": 297181670
 },
 {
   "policy_number": 894424,
   "phone_number": 4488487614,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Won",
   "payment_status": "Partial",
   "patient_id": 830274531
 },
 {
   "policy_number": 900802,
   "phone_number": 8842024349,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 967019844
 },
 {
   "policy_number": 681876,
   "phone_number": 6658962737,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 454949492
 },
 {
   "policy_number": 329977,
   "phone_number": 4922244336,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 317356374
 },
 {
   "policy_number": 126148,
   "phone_number": 1869421153,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 98693118
 },
 {
   "policy_number": 582483,
   "phone_number": 6124184998,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 859007943
 },
 {
   "policy_number": 880259,
   "phone_number": 6213790576,
   "insurance_provider": "Aetna",
   "billing_amount": "Afghani",
   "payment_status": "Unpaid",
   "patient_id": 936928571
 },
 {
   "policy_number": 344936,
   "phone_number": 3125298781,
   "insurance_provider": "Cigna",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 205802252
 },
 {
   "policy_number": 466458,
   "phone_number": 3948634797,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 491186752
 },
 {
   "policy_number": 519679,
   "phone_number": 1161206456,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 223671959
 },
 {
   "policy_number": 755510,
   "phone_number": 2096302210,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 574472765
 },
 {
   "policy_number": 148432,
   "phone_number": 9465993473,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 952307752
 },
 {
   "policy_number": 345370,
   "phone_number": 3884425328,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 147194170
 },
 {
   "policy_number": 409967,
   "phone_number": 9932523682,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 854815299
 },
 {
   "policy_number": 632819,
   "phone_number": 4503555983,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Cordoba",
   "payment_status": "Unpaid",
   "patient_id": 440602340
 },
 {
   "policy_number": 681178,
   "phone_number": 8527046383,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 442514024
 },
 {
   "policy_number": 824398,
   "phone_number": 3325160934,
   "insurance_provider": "Cigna",
   "billing_amount": "Ariary",
   "payment_status": "Paid",
   "patient_id": 367039032
 },
 {
   "policy_number": 581679,
   "phone_number": 9679612855,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 221469783
 },
 {
   "policy_number": 196839,
   "phone_number": 6943627893,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 984167189
 },
 {
   "policy_number": 539575,
   "phone_number": 4266209578,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 787798578
 },
 {
   "policy_number": 353454,
   "phone_number": 2174878785,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 142845775
 },
 {
   "policy_number": 868408,
   "phone_number": 3223147959,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 821563403
 },
 {
   "policy_number": 894308,
   "phone_number": 7825616114,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 113428938
 },
 {
   "policy_number": 777868,
   "phone_number": 5285578766,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 278052903
 },
 {
   "policy_number": 578376,
   "phone_number": 2681900949,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 27219464
 },
 {
   "policy_number": 300220,
   "phone_number": 2436539452,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 629539270
 },
 {
   "policy_number": 938854,
   "phone_number": 4988581931,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 522766694
 },
 {
   "policy_number": 945386,
   "phone_number": 6465999405,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 704278225
 },
 {
   "policy_number": 535291,
   "phone_number": 8482853109,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 809434019
 },
 {
   "policy_number": 359037,
   "phone_number": 4811755539,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 285355146
 },
 {
   "policy_number": 491094,
   "phone_number": 4064237920,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 448795592
 },
 {
   "policy_number": 289147,
   "phone_number": 7941090220,
   "insurance_provider": "Cigna",
   "billing_amount": "Kwacha",
   "payment_status": "Unpaid",
   "patient_id": 330412646
 },
 {
   "policy_number": 161588,
   "phone_number": 9211405720,
   "insurance_provider": "Aetna",
   "billing_amount": "Forint",
   "payment_status": "Paid",
   "patient_id": 936759440
 },
 {
   "policy_number": 964638,
   "phone_number": 9182204358,
   "insurance_provider": "Aetna",
   "billing_amount": "Won",
   "payment_status": "Partial",
   "patient_id": 617333642
 },
 {
   "policy_number": 376104,
   "phone_number": 6505066027,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 149020403
 },
 {
   "policy_number": 803723,
   "phone_number": 3002934125,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 589910221
 },
 {
   "policy_number": 146339,
   "phone_number": 8438819428,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Partial",
   "patient_id": 518193599
 },
 {
   "policy_number": 155079,
   "phone_number": 7905740643,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 242159553
 },
 {
   "policy_number": 486835,
   "phone_number": 1775557274,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 134715238
 },
 {
   "policy_number": 587184,
   "phone_number": 7271741633,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 715650420
 },
 {
   "policy_number": 707590,
   "phone_number": 4265500952,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 914591828
 },
 {
   "policy_number": 273613,
   "phone_number": 5738135670,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 972153413
 },
 {
   "policy_number": 231492,
   "phone_number": 2764450696,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 125269602
 },
 {
   "policy_number": 308611,
   "phone_number": 6455194863,
   "insurance_provider": "Aetna",
   "billing_amount": "Pound",
   "payment_status": "Partial",
   "patient_id": 719924698
 },
 {
   "policy_number": 395387,
   "phone_number": 5701453589,
   "insurance_provider": "Cigna",
   "billing_amount": "Manat",
   "payment_status": "Unpaid",
   "patient_id": 886564882
 },
 {
   "policy_number": 407045,
   "phone_number": 7772690481,
   "insurance_provider": "Cigna",
   "billing_amount": "Ariary",
   "payment_status": "Unpaid",
   "patient_id": 91001578
 },
 {
   "policy_number": 625916,
   "phone_number": 3275922024,
   "insurance_provider": "Aetna",
   "billing_amount": "Dirham",
   "payment_status": "Unpaid",
   "patient_id": 772603404
 },
 {
   "policy_number": 689255,
   "phone_number": 7957163469,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 877066317
 },
 {
   "policy_number": 586612,
   "phone_number": 9975551388,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Partial",
   "patient_id": 898517197
 },
 {
   "policy_number": 378847,
   "phone_number": 5132784228,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 753891596
 },
 {
   "policy_number": 937013,
   "phone_number": 6742318432,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 62856092
 },
 {
   "policy_number": 453421,
   "phone_number": 1968769403,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Shilling",
   "payment_status": "Partial",
   "patient_id": 986432212
 },
 {
   "policy_number": 235306,
   "phone_number": 2032874126,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 525470834
 },
 {
   "policy_number": 380268,
   "phone_number": 1242087296,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Unpaid",
   "patient_id": 700240328
 },
 {
   "policy_number": 942527,
   "phone_number": 4767444969,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 320432402
 },
 {
   "policy_number": 507583,
   "phone_number": 1893066294,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 837749245
 },
 {
   "policy_number": 503881,
   "phone_number": 5802831904,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 559388733
 },
 {
   "policy_number": 945507,
   "phone_number": 4904147847,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 231392472
 },
 {
   "policy_number": 188197,
   "phone_number": 8546078572,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Pound",
   "payment_status": "Paid",
   "patient_id": 821884164
 },
 {
   "policy_number": 983313,
   "phone_number": 3067565293,
   "insurance_provider": "Cigna",
   "billing_amount": "Lev",
   "payment_status": "Paid",
   "patient_id": 264174687
 },
 {
   "policy_number": 344919,
   "phone_number": 8222793728,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 84704238
 },
 {
   "policy_number": 350140,
   "phone_number": 6955945745,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 666716175
 },
 {
   "policy_number": 631792,
   "phone_number": 4417796937,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 779941389
 },
 {
   "policy_number": 559745,
   "phone_number": 1345234008,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 316875241
 },
 {
   "policy_number": 888115,
   "phone_number": 5928903319,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 145036888
 },
 {
   "policy_number": 675554,
   "phone_number": 5681097810,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 86604517
 },
 {
   "policy_number": 923318,
   "phone_number": 9848463402,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 848344783
 },
 {
   "policy_number": 330776,
   "phone_number": 8493403214,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 565377768
 },
 {
   "policy_number": 530418,
   "phone_number": 1139077368,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 816548704
 },
 {
   "policy_number": 953792,
   "phone_number": 6929228493,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 227010807
 },
 {
   "policy_number": 380818,
   "phone_number": 6148052727,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 742041410
 },
 {
   "policy_number": 116593,
   "phone_number": 6896084081,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 354636790
 },
 {
   "policy_number": 577797,
   "phone_number": 1066231530,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 364779149
 },
 {
   "policy_number": 124500,
   "phone_number": 3422192130,
   "insurance_provider": "Cigna",
   "billing_amount": "Krone",
   "payment_status": "Paid",
   "patient_id": 967051114
 },
 {
   "policy_number": 316223,
   "phone_number": 3597287930,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 739531310
 },
 {
   "policy_number": 259223,
   "phone_number": 4277133578,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 231170029
 },
 {
   "policy_number": 413961,
   "phone_number": 8984859939,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Partial",
   "patient_id": 415092686
 },
 {
   "policy_number": 535568,
   "phone_number": 2763036784,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 685766483
 },
 {
   "policy_number": 962090,
   "phone_number": 4396545561,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 892466058
 },
 {
   "policy_number": 289265,
   "phone_number": 1242924600,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 667805562
 },
 {
   "policy_number": 603555,
   "phone_number": 3111113414,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 345421752
 },
 {
   "policy_number": 830723,
   "phone_number": 7993881553,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Paid",
   "patient_id": 197677169
 },
 {
   "policy_number": 934388,
   "phone_number": 7225764917,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krona",
   "payment_status": "Partial",
   "patient_id": 530103186
 },
 {
   "policy_number": 351961,
   "phone_number": 3397282264,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 844561658
 },
 {
   "policy_number": 388096,
   "phone_number": 8666150934,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 316841341
 },
 {
   "policy_number": 727449,
   "phone_number": 3518414390,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Forint",
   "payment_status": "Unpaid",
   "patient_id": 322114020
 },
 {
   "policy_number": 491575,
   "phone_number": 2167556831,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 631285783
 },
 {
   "policy_number": 492888,
   "phone_number": 3403800934,
   "insurance_provider": "Cigna",
   "billing_amount": "Bolivar",
   "payment_status": "Unpaid",
   "patient_id": 747193545
 },
 {
   "policy_number": 976407,
   "phone_number": 7363631025,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 857842158
 },
 {
   "policy_number": 997935,
   "phone_number": 9469277732,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 847421326
 },
 {
   "policy_number": 826243,
   "phone_number": 3528842841,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 422046345
 },
 {
   "policy_number": 566236,
   "phone_number": 2455010480,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kip",
   "payment_status": "Unpaid",
   "patient_id": 62674061
 },
 {
   "policy_number": 570400,
   "phone_number": 8253873646,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 601918930
 },
 {
   "policy_number": 264869,
   "phone_number": 7524464562,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 173607718
 },
 {
   "policy_number": 189936,
   "phone_number": 3922496186,
   "insurance_provider": "Cigna",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 785973041
 },
 {
   "policy_number": 995335,
   "phone_number": 3322116874,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 291078712
 },
 {
   "policy_number": 929695,
   "phone_number": 7708115214,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 425269856
 },
 {
   "policy_number": 470934,
   "phone_number": 4066993121,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 226934857
 },
 {
   "policy_number": 781512,
   "phone_number": 4745099263,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 120223760
 },
 {
   "policy_number": 185391,
   "phone_number": 4601774057,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 448283482
 },
 {
   "policy_number": 112817,
   "phone_number": 6981845884,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 170598357
 },
 {
   "policy_number": 744995,
   "phone_number": 6873348370,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 421045209
 },
 {
   "policy_number": 987271,
   "phone_number": 9731784730,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 607681595
 },
 {
   "policy_number": 947226,
   "phone_number": 1076170788,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 889722477
 },
 {
   "policy_number": 111620,
   "phone_number": 7633862308,
   "insurance_provider": "Cigna",
   "billing_amount": "Shekel",
   "payment_status": "Paid",
   "patient_id": 203000145
 },
 {
   "policy_number": 615031,
   "phone_number": 8903117842,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 62505395
 },
 {
   "policy_number": 174925,
   "phone_number": 4751141589,
   "insurance_provider": "Aetna",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 814755149
 },
 {
   "policy_number": 842052,
   "phone_number": 2891201301,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 981089876
 },
 {
   "policy_number": 329822,
   "phone_number": 2663004772,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 333845615
 },
 {
   "policy_number": 166161,
   "phone_number": 8416188713,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 553237679
 },
 {
   "policy_number": 463497,
   "phone_number": 2527506703,
   "insurance_provider": "Cigna",
   "billing_amount": "Afghani",
   "payment_status": "Unpaid",
   "patient_id": 204913870
 },
 {
   "policy_number": 292810,
   "phone_number": 7573715035,
   "insurance_provider": "Cigna",
   "billing_amount": "Won",
   "payment_status": "Unpaid",
   "patient_id": 206636350
 },
 {
   "policy_number": 690792,
   "phone_number": 3561941994,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 790878684
 },
 {
   "policy_number": 343375,
   "phone_number": 7366908231,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 975972568
 },
 {
   "policy_number": 745879,
   "phone_number": 9359535042,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 225299968
 },
 {
   "policy_number": 883646,
   "phone_number": 4465560760,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Litas",
   "payment_status": "Paid",
   "patient_id": 290533830
 },
 {
   "policy_number": 616809,
   "phone_number": 7498131168,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 426101339
 },
 {
   "policy_number": 720338,
   "phone_number": 8214144075,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rial",
   "payment_status": "Partial",
   "patient_id": 399388732
 },
 {
   "policy_number": 932978,
   "phone_number": 7601016234,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kwacha",
   "payment_status": "Unpaid",
   "patient_id": 450658408
 },
 {
   "policy_number": 379609,
   "phone_number": 2069072385,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 225825384
 },
 {
   "policy_number": 909216,
   "phone_number": 5484075245,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 88420477
 },
 {
   "policy_number": 482443,
   "phone_number": 6017920745,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 915669969
 },
 {
   "policy_number": 491147,
   "phone_number": 1327216059,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 298778071
 },
 {
   "policy_number": 216452,
   "phone_number": 9032040552,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 296897508
 },
 {
   "policy_number": 617311,
   "phone_number": 4832123112,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 669017571
 },
 {
   "policy_number": 501715,
   "phone_number": 3746821021,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 641421685
 },
 {
   "policy_number": 124753,
   "phone_number": 7948981772,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 952728246
 },
 {
   "policy_number": 473276,
   "phone_number": 9789649829,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 73649927
 },
 {
   "policy_number": 937532,
   "phone_number": 7671204926,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 671507928
 },
 {
   "policy_number": 525498,
   "phone_number": 8225427862,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 286025845
 },
 {
   "policy_number": 780055,
   "phone_number": 5746320818,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 304922871
 },
 {
   "policy_number": 347681,
   "phone_number": 6792916372,
   "insurance_provider": "Cigna",
   "billing_amount": "Kuna",
   "payment_status": "Paid",
   "patient_id": 582980783
 },
 {
   "policy_number": 967134,
   "phone_number": 3015222451,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 288518803
 },
 {
   "policy_number": 988426,
   "phone_number": 6749883530,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 484167075
 },
 {
   "policy_number": 714600,
   "phone_number": 2669143023,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 772005956
 },
 {
   "policy_number": 512636,
   "phone_number": 1914096989,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 264582659
 },
 {
   "policy_number": 565028,
   "phone_number": 4467823954,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 592112447
 },
 {
   "policy_number": 759356,
   "phone_number": 8084691340,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 894373636
 },
 {
   "policy_number": 301193,
   "phone_number": 2693415000,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 497715155
 },
 {
   "policy_number": 172948,
   "phone_number": 4645397527,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Partial",
   "patient_id": 438624573
 },
 {
   "policy_number": 179287,
   "phone_number": 2169036726,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Partial",
   "patient_id": 345715688
 },
 {
   "policy_number": 932285,
   "phone_number": 5061496687,
   "insurance_provider": "Aetna",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 132559883
 },
 {
   "policy_number": 438521,
   "phone_number": 4367701808,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 967079673
 },
 {
   "policy_number": 118137,
   "phone_number": 2261071665,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 477166121
 },
 {
   "policy_number": 373410,
   "phone_number": 8302491109,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 182844422
 },
 {
   "policy_number": 430591,
   "phone_number": 6688046793,
   "insurance_provider": "Aetna",
   "billing_amount": "Quetzal",
   "payment_status": "Paid",
   "patient_id": 547880674
 },
 {
   "policy_number": 690557,
   "phone_number": 6979653251,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 995701962
 },
 {
   "policy_number": 351346,
   "phone_number": 4131851742,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 741359872
 },
 {
   "policy_number": 232724,
   "phone_number": 3232019629,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 20314008
 },
 {
   "policy_number": 247896,
   "phone_number": 8935771666,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 646819878
 },
 {
   "policy_number": 505981,
   "phone_number": 8924418527,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 886992264
 },
 {
   "policy_number": 179725,
   "phone_number": 7858613298,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 798580686
 },
 {
   "policy_number": 850355,
   "phone_number": 7653540742,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 137845579
 },
 {
   "policy_number": 332510,
   "phone_number": 5383778227,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 844857052
 },
 {
   "policy_number": 615864,
   "phone_number": 6153802282,
   "insurance_provider": "Cigna",
   "billing_amount": "Quetzal",
   "payment_status": "Unpaid",
   "patient_id": 561739729
 },
 {
   "policy_number": 698638,
   "phone_number": 4586926619,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 589802751
 },
 {
   "policy_number": 692649,
   "phone_number": 5032874208,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 938341356
 },
 {
   "policy_number": 878748,
   "phone_number": 9198899892,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 412252964
 },
 {
   "policy_number": 257675,
   "phone_number": 4548342929,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 688954037
 },
 {
   "policy_number": 572811,
   "phone_number": 4977867740,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 195133202
 },
 {
   "policy_number": 411356,
   "phone_number": 2113881775,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 993194584
 },
 {
   "policy_number": 219406,
   "phone_number": 3514719010,
   "insurance_provider": "Cigna",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 751677696
 },
 {
   "policy_number": 633157,
   "phone_number": 1891180475,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 629097045
 },
 {
   "policy_number": 628946,
   "phone_number": 4366568178,
   "insurance_provider": "Aetna",
   "billing_amount": "Dalasi",
   "payment_status": "Partial",
   "patient_id": 734762728
 },
 {
   "policy_number": 251643,
   "phone_number": 4121757814,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 184662655
 },
 {
   "policy_number": 560067,
   "phone_number": 1722413445,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 636811037
 },
 {
   "policy_number": 626668,
   "phone_number": 2483697065,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 633502640
 },
 {
   "policy_number": 425738,
   "phone_number": 8446752781,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 539492226
 },
 {
   "policy_number": 708734,
   "phone_number": 4596746160,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 359353686
 },
 {
   "policy_number": 583991,
   "phone_number": 6254562681,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 804688279
 },
 {
   "policy_number": 464739,
   "phone_number": 8921819648,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 510708767
 },
 {
   "policy_number": 363567,
   "phone_number": 2802226888,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Unpaid",
   "patient_id": 667148888
 },
 {
   "policy_number": 750482,
   "phone_number": 9469020537,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 439725005
 },
 {
   "policy_number": 572364,
   "phone_number": 5004470049,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 366580016
 },
 {
   "policy_number": 352183,
   "phone_number": 5022384341,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 832436540
 },
 {
   "policy_number": 431245,
   "phone_number": 9585591524,
   "insurance_provider": "Aetna",
   "billing_amount": "Cedi",
   "payment_status": "Unpaid",
   "patient_id": 118189821
 },
 {
   "policy_number": 135563,
   "phone_number": 1541418823,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 142386290
 },
 {
   "policy_number": 690402,
   "phone_number": 9294255435,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 10890207
 },
 {
   "policy_number": 572200,
   "phone_number": 8122321104,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 364075393
 },
 {
   "policy_number": 362014,
   "phone_number": 2561955646,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 841358317
 },
 {
   "policy_number": 379603,
   "phone_number": 5727735513,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 830073825
 },
 {
   "policy_number": 108566,
   "phone_number": 8882530216,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Bolivar",
   "payment_status": "Paid",
   "patient_id": 616964315
 },
 {
   "policy_number": 500377,
   "phone_number": 3028500859,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 289140264
 },
 {
   "policy_number": 494238,
   "phone_number": 1621198333,
   "insurance_provider": "Cigna",
   "billing_amount": "Tugrik",
   "payment_status": "Paid",
   "patient_id": 564585080
 },
 {
   "policy_number": 853238,
   "phone_number": 5797790695,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 425903349
 },
 {
   "policy_number": 782377,
   "phone_number": 2311061431,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 79773476
 },
 {
   "policy_number": 715035,
   "phone_number": 6676407280,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 177646991
 },
 {
   "policy_number": 752352,
   "phone_number": 1534706184,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Gourde",
   "payment_status": "Paid",
   "patient_id": 846745304
 },
 {
   "policy_number": 608968,
   "phone_number": 1581165885,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Paid",
   "patient_id": 988770075
 },
 {
   "policy_number": 855747,
   "phone_number": 8103980793,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 791742898
 },
 {
   "policy_number": 629831,
   "phone_number": 4867788542,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krone",
   "payment_status": "Partial",
   "patient_id": 529288405
 },
 {
   "policy_number": 529906,
   "phone_number": 9798157824,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 314273459
 },
 {
   "policy_number": 129949,
   "phone_number": 1192001525,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 797445830
 },
 {
   "policy_number": 373283,
   "phone_number": 7993131501,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 453787601
 },
 {
   "policy_number": 698933,
   "phone_number": 4963906895,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 388503082
 },
 {
   "policy_number": 183279,
   "phone_number": 8591893194,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 640029536
 },
 {
   "policy_number": 368529,
   "phone_number": 7669950856,
   "insurance_provider": "Cigna",
   "billing_amount": "Lek",
   "payment_status": "Unpaid",
   "patient_id": 735342884
 },
 {
   "policy_number": 791528,
   "phone_number": 6216108007,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Paid",
   "patient_id": 585713445
 },
 {
   "policy_number": 465195,
   "phone_number": 5088135105,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 393558923
 },
 {
   "policy_number": 843803,
   "phone_number": 8091158928,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 757255325
 },
 {
   "policy_number": 209259,
   "phone_number": 2843004131,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 308646340
 },
 {
   "policy_number": 655737,
   "phone_number": 6525493313,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 687945795
 },
 {
   "policy_number": 681693,
   "phone_number": 5726066465,
   "insurance_provider": "Cigna",
   "billing_amount": "Naira",
   "payment_status": "Paid",
   "patient_id": 623031103
 },
 {
   "policy_number": 228096,
   "phone_number": 8406784244,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Koruna",
   "payment_status": "Partial",
   "patient_id": 876250646
 },
 {
   "policy_number": 249293,
   "phone_number": 2489408097,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dram",
   "payment_status": "Unpaid",
   "patient_id": 344454710
 },
 {
   "policy_number": 753638,
   "phone_number": 8409785627,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 995352285
 },
 {
   "policy_number": 319868,
   "phone_number": 2469206697,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 973927366
 },
 {
   "policy_number": 197026,
   "phone_number": 6913972876,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 218742481
 },
 {
   "policy_number": 252695,
   "phone_number": 4529394739,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 517790823
 },
 {
   "policy_number": 617383,
   "phone_number": 3743476738,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 964797340
 },
 {
   "policy_number": 173094,
   "phone_number": 1022354015,
   "insurance_provider": "Aetna",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 575157065
 },
 {
   "policy_number": 747772,
   "phone_number": 2288502199,
   "insurance_provider": "Aetna",
   "billing_amount": "Birr",
   "payment_status": "Partial",
   "patient_id": 468469624
 },
 {
   "policy_number": 999584,
   "phone_number": 3113739327,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 883643157
 },
 {
   "policy_number": 324037,
   "phone_number": 9457180051,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 704435054
 },
 {
   "policy_number": 327711,
   "phone_number": 6579858841,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 948301490
 },
 {
   "policy_number": 254174,
   "phone_number": 7038639642,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 992901019
 },
 {
   "policy_number": 898910,
   "phone_number": 7309231361,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 462510418
 },
 {
   "policy_number": 986461,
   "phone_number": 8321321910,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 386514075
 },
 {
   "policy_number": 670058,
   "phone_number": 7481280387,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 1590456
 },
 {
   "policy_number": 831832,
   "phone_number": 5447239102,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 54935676
 },
 {
   "policy_number": 247943,
   "phone_number": 4975225423,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 161105413
 },
 {
   "policy_number": 976020,
   "phone_number": 6251637137,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 146106230
 },
 {
   "policy_number": 561632,
   "phone_number": 5648267397,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 681225657
 },
 {
   "policy_number": 660017,
   "phone_number": 9153494871,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 390007509
 },
 {
   "policy_number": 716199,
   "phone_number": 8122865056,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 648341355
 },
 {
   "policy_number": 491349,
   "phone_number": 1345927501,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 179766140
 },
 {
   "policy_number": 972526,
   "phone_number": 5202780750,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 143586442
 },
 {
   "policy_number": 113901,
   "phone_number": 3612434703,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 976032998
 },
 {
   "policy_number": 121322,
   "phone_number": 5997576478,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Unpaid",
   "patient_id": 118190694
 },
 {
   "policy_number": 196661,
   "phone_number": 1353192377,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 576286948
 },
 {
   "policy_number": 380835,
   "phone_number": 7663501426,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 235592819
 },
 {
   "policy_number": 128956,
   "phone_number": 7844105527,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 190580163
 },
 {
   "policy_number": 256101,
   "phone_number": 2732036832,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 595786856
 },
 {
   "policy_number": 837251,
   "phone_number": 6202408000,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 604700309
 },
 {
   "policy_number": 419363,
   "phone_number": 2827674666,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 902219821
 },
 {
   "policy_number": 863266,
   "phone_number": 2692434401,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 188976169
 },
 {
   "policy_number": 507842,
   "phone_number": 3815177157,
   "insurance_provider": "Aetna",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 369442227
 },
 {
   "policy_number": 606128,
   "phone_number": 5115847447,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 18906918
 },
 {
   "policy_number": 782133,
   "phone_number": 7168997973,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 35693825
 },
 {
   "policy_number": 311063,
   "phone_number": 1929026329,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 362364938
 },
 {
   "policy_number": 203111,
   "phone_number": 7959374746,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 973178479
 },
 {
   "policy_number": 326685,
   "phone_number": 9766973782,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 421353640
 },
 {
   "policy_number": 883474,
   "phone_number": 7457868606,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 665583477
 },
 {
   "policy_number": 574422,
   "phone_number": 3952899348,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 672042085
 },
 {
   "policy_number": 710882,
   "phone_number": 5064807383,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 208512165
 },
 {
   "policy_number": 788230,
   "phone_number": 8006449303,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 696254421
 },
 {
   "policy_number": 705563,
   "phone_number": 6946964979,
   "insurance_provider": "Aetna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 785024059
 },
 {
   "policy_number": 734898,
   "phone_number": 6177968280,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 104852602
 },
 {
   "policy_number": 327507,
   "phone_number": 3862807291,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 169056437
 },
 {
   "policy_number": 619209,
   "phone_number": 3047749990,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 353612846
 },
 {
   "policy_number": 843605,
   "phone_number": 9569208926,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Partial",
   "patient_id": 623874543
 },
 {
   "policy_number": 721401,
   "phone_number": 2098167563,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 174674776
 },
 {
   "policy_number": 297673,
   "phone_number": 9741083492,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 207832878
 },
 {
   "policy_number": 489591,
   "phone_number": 9527501879,
   "insurance_provider": "Cigna",
   "billing_amount": "Afghani",
   "payment_status": "Paid",
   "patient_id": 248029357
 },
 {
   "policy_number": 271887,
   "phone_number": 1076314652,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 358243418
 },
 {
   "policy_number": 405238,
   "phone_number": 1298159688,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 90632849
 },
 {
   "policy_number": 329002,
   "phone_number": 3375536736,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 998686365
 },
 {
   "policy_number": 565349,
   "phone_number": 4695292725,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 819078814
 },
 {
   "policy_number": 641302,
   "phone_number": 7584908233,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Pound",
   "payment_status": "Unpaid",
   "patient_id": 412893753
 },
 {
   "policy_number": 112842,
   "phone_number": 4301611063,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 32778867
 },
 {
   "policy_number": 900976,
   "phone_number": 2633335379,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 930710192
 },
 {
   "policy_number": 277243,
   "phone_number": 8133083544,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 645199470
 },
 {
   "policy_number": 807315,
   "phone_number": 2798450584,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Paid",
   "patient_id": 396282953
 },
 {
   "policy_number": 396214,
   "phone_number": 5042460773,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 537457424
 },
 {
   "policy_number": 273465,
   "phone_number": 4235113634,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 202267689
 },
 {
   "policy_number": 864969,
   "phone_number": 5662576384,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 696593451
 },
 {
   "policy_number": 553547,
   "phone_number": 1145202485,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 173354845
 },
 {
   "policy_number": 885639,
   "phone_number": 4077802452,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 195955527
 },
 {
   "policy_number": 254628,
   "phone_number": 6593726476,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Leone",
   "payment_status": "Partial",
   "patient_id": 467823139
 },
 {
   "policy_number": 918362,
   "phone_number": 2636077309,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 446009214
 },
 {
   "policy_number": 422067,
   "phone_number": 4683981510,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 404831768
 },
 {
   "policy_number": 311515,
   "phone_number": 3623215013,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 582248667
 },
 {
   "policy_number": 737258,
   "phone_number": 4976665286,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Partial",
   "patient_id": 362633029
 },
 {
   "policy_number": 261250,
   "phone_number": 8409143217,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 260717309
 },
 {
   "policy_number": 208442,
   "phone_number": 3692390648,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 630281586
 },
 {
   "policy_number": 234002,
   "phone_number": 6006643371,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 895975590
 },
 {
   "policy_number": 409164,
   "phone_number": 4697740921,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dram",
   "payment_status": "Paid",
   "patient_id": 816280609
 },
 {
   "policy_number": 970539,
   "phone_number": 9185946173,
   "insurance_provider": "Cigna",
   "billing_amount": "Baht",
   "payment_status": "Paid",
   "patient_id": 239527640
 },
 {
   "policy_number": 999504,
   "phone_number": 5291288467,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 362959196
 },
 {
   "policy_number": 887397,
   "phone_number": 3168696097,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 524081774
 },
 {
   "policy_number": 300735,
   "phone_number": 2364227823,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Colon",
   "payment_status": "Unpaid",
   "patient_id": 982501745
 },
 {
   "policy_number": 265182,
   "phone_number": 4739415832,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Partial",
   "patient_id": 786322265
 },
 {
   "policy_number": 241835,
   "phone_number": 9904896600,
   "insurance_provider": "Cigna",
   "billing_amount": "Rand",
   "payment_status": "Partial",
   "patient_id": 469585889
 },
 {
   "policy_number": 673675,
   "phone_number": 3574836678,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 787573949
 },
 {
   "policy_number": 874209,
   "phone_number": 6709262927,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 346855516
 },
 {
   "policy_number": 962661,
   "phone_number": 6198721964,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 313267691
 },
 {
   "policy_number": 365546,
   "phone_number": 2776315154,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 621609609
 },
 {
   "policy_number": 159816,
   "phone_number": 5935395422,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 650036716
 },
 {
   "policy_number": 305087,
   "phone_number": 4389323859,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 85032150
 },
 {
   "policy_number": 345090,
   "phone_number": 7073979078,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 749112003
 },
 {
   "policy_number": 929648,
   "phone_number": 4722025035,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 667496237
 },
 {
   "policy_number": 652795,
   "phone_number": 4476733930,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 498148613
 },
 {
   "policy_number": 381139,
   "phone_number": 1655882253,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 648972547
 },
 {
   "policy_number": 541410,
   "phone_number": 8477619942,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 804337980
 },
 {
   "policy_number": 169030,
   "phone_number": 7555492186,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 509309578
 },
 {
   "policy_number": 646537,
   "phone_number": 3522220723,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Balboa",
   "payment_status": "Unpaid",
   "patient_id": 235463303
 },
 {
   "policy_number": 694622,
   "phone_number": 4927966391,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 27255569
 },
 {
   "policy_number": 773523,
   "phone_number": 3387294449,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 532706040
 },
 {
   "policy_number": 280130,
   "phone_number": 1921787372,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 692001184
 },
 {
   "policy_number": 203966,
   "phone_number": 7771848976,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 142758365
 },
 {
   "policy_number": 589617,
   "phone_number": 2142451198,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 82048598
 },
 {
   "policy_number": 741640,
   "phone_number": 4169739736,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 174628396
 },
 {
   "policy_number": 670448,
   "phone_number": 3673743704,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 560384589
 },
 {
   "policy_number": 842260,
   "phone_number": 3446936059,
   "insurance_provider": "Aetna",
   "billing_amount": "Naira",
   "payment_status": "Unpaid",
   "patient_id": 624936117
 },
 {
   "policy_number": 468542,
   "phone_number": 5362328395,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 398885724
 },
 {
   "policy_number": 689387,
   "phone_number": 3757589554,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 54328749
 },
 {
   "policy_number": 561686,
   "phone_number": 6343651017,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 992634308
 },
 {
   "policy_number": 883850,
   "phone_number": 3401433150,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 793003815
 },
 {
   "policy_number": 832571,
   "phone_number": 6405621756,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 495787877
 },
 {
   "policy_number": 128509,
   "phone_number": 6156842395,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 267743189
 },
 {
   "policy_number": 719258,
   "phone_number": 6966643962,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 55659397
 },
 {
   "policy_number": 466933,
   "phone_number": 8922533217,
   "insurance_provider": "Aetna",
   "billing_amount": "Krone",
   "payment_status": "Paid",
   "patient_id": 122404338
 },
 {
   "policy_number": 923735,
   "phone_number": 8569299178,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 77165315
 },
 {
   "policy_number": 138744,
   "phone_number": 1803400396,
   "insurance_provider": "Cigna",
   "billing_amount": "Kwacha",
   "payment_status": "Partial",
   "patient_id": 275412918
 },
 {
   "policy_number": 782361,
   "phone_number": 6517599558,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 828460468
 },
 {
   "policy_number": 361378,
   "phone_number": 8548799605,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 556879037
 },
 {
   "policy_number": 296134,
   "phone_number": 6276030142,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 514125439
 },
 {
   "policy_number": 551335,
   "phone_number": 5843803914,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 727065332
 },
 {
   "policy_number": 731263,
   "phone_number": 7344104587,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Partial",
   "patient_id": 422709967
 },
 {
   "policy_number": 179650,
   "phone_number": 6293574293,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 355411103
 },
 {
   "policy_number": 831297,
   "phone_number": 8313157401,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 722061898
 },
 {
   "policy_number": 794581,
   "phone_number": 8425945848,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 834934164
 },
 {
   "policy_number": 287501,
   "phone_number": 9731518473,
   "insurance_provider": "Cigna",
   "billing_amount": "Franc",
   "payment_status": "Partial",
   "patient_id": 399411276
 },
 {
   "policy_number": 359342,
   "phone_number": 6022608595,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 711641592
 },
 {
   "policy_number": 998337,
   "phone_number": 8881120300,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 828018247
 },
 {
   "policy_number": 461141,
   "phone_number": 1169581613,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 220892804
 },
 {
   "policy_number": 805327,
   "phone_number": 3457424337,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 927887398
 },
 {
   "policy_number": 454675,
   "phone_number": 5014512802,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupee",
   "payment_status": "Paid",
   "patient_id": 196667880
 },
 {
   "policy_number": 463912,
   "phone_number": 1726619194,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 606450439
 },
 {
   "policy_number": 495626,
   "phone_number": 6699416185,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 425822956
 },
 {
   "policy_number": 328643,
   "phone_number": 3219022972,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 204069482
 },
 {
   "policy_number": 573407,
   "phone_number": 2775038741,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 783006925
 },
 {
   "policy_number": 962812,
   "phone_number": 5111857847,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 663380934
 },
 {
   "policy_number": 281888,
   "phone_number": 6024964832,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 370327248
 },
 {
   "policy_number": 659554,
   "phone_number": 5605785190,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 751139588
 },
 {
   "policy_number": 704396,
   "phone_number": 7767225211,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krone",
   "payment_status": "Partial",
   "patient_id": 71234680
 },
 {
   "policy_number": 389445,
   "phone_number": 6927518822,
   "insurance_provider": "Cigna",
   "billing_amount": "Kuna",
   "payment_status": "Unpaid",
   "patient_id": 158221518
 },
 {
   "policy_number": 732060,
   "phone_number": 1416657726,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 610043626
 },
 {
   "policy_number": 421393,
   "phone_number": 4175009722,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 302026565
 },
 {
   "policy_number": 339649,
   "phone_number": 3789269491,
   "insurance_provider": "Aetna",
   "billing_amount": "Tenge",
   "payment_status": "Paid",
   "patient_id": 614049323
 },
 {
   "policy_number": 649828,
   "phone_number": 6306314957,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 146173247
 },
 {
   "policy_number": 141446,
   "phone_number": 2985676386,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 447848844
 },
 {
   "policy_number": 159937,
   "phone_number": 6586086486,
   "insurance_provider": "Cigna",
   "billing_amount": "Krone",
   "payment_status": "Partial",
   "patient_id": 962204244
 },
 {
   "policy_number": 849608,
   "phone_number": 4304634782,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 58847187
 },
 {
   "policy_number": 728085,
   "phone_number": 2525176387,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 727571485
 },
 {
   "policy_number": 600901,
   "phone_number": 4313673005,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Paid",
   "patient_id": 387562934
 },
 {
   "policy_number": 543123,
   "phone_number": 6591686552,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 578778803
 },
 {
   "policy_number": 734966,
   "phone_number": 7136579002,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 852057075
 },
 {
   "policy_number": 327390,
   "phone_number": 1494768803,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 841305837
 },
 {
   "policy_number": 276534,
   "phone_number": 3072106120,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rand",
   "payment_status": "Unpaid",
   "patient_id": 163440809
 },
 {
   "policy_number": 475711,
   "phone_number": 6569856380,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 234840191
 },
 {
   "policy_number": 547583,
   "phone_number": 8682606145,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 628295878
 },
 {
   "policy_number": 864100,
   "phone_number": 8821955140,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 293277773
 },
 {
   "policy_number": 318145,
   "phone_number": 6034122124,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 380391051
 },
 {
   "policy_number": 879972,
   "phone_number": 8294932329,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 822119060
 },
 {
   "policy_number": 185540,
   "phone_number": 9525477563,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 216341589
 },
 {
   "policy_number": 610210,
   "phone_number": 4734548468,
   "insurance_provider": "Aetna",
   "billing_amount": "Ariary",
   "payment_status": "Paid",
   "patient_id": 341005835
 },
 {
   "policy_number": 447680,
   "phone_number": 6253098147,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 723143458
 },
 {
   "policy_number": 201718,
   "phone_number": 6363744828,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 871416790
 },
 {
   "policy_number": 128189,
   "phone_number": 5745217000,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 975198286
 },
 {
   "policy_number": 709071,
   "phone_number": 3981947444,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 180585272
 },
 {
   "policy_number": 823339,
   "phone_number": 4975952267,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 552127421
 },
 {
   "policy_number": 165500,
   "phone_number": 3607157262,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 53267561
 },
 {
   "policy_number": 756347,
   "phone_number": 6769834589,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 488000191
 },
 {
   "policy_number": 803460,
   "phone_number": 9335767110,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 172196320
 },
 {
   "policy_number": 548796,
   "phone_number": 4065167922,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 394991105
 },
 {
   "policy_number": 554906,
   "phone_number": 1592989076,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Unpaid",
   "patient_id": 673388522
 },
 {
   "policy_number": 680517,
   "phone_number": 7001913736,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 524560183
 },
 {
   "policy_number": 290621,
   "phone_number": 4384257270,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 454773624
 },
 {
   "policy_number": 924429,
   "phone_number": 9851928298,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 237338496
 },
 {
   "policy_number": 931961,
   "phone_number": 6935470828,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 558371102
 },
 {
   "policy_number": 122923,
   "phone_number": 6321330517,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krone",
   "payment_status": "Unpaid",
   "patient_id": 174952221
 },
 {
   "policy_number": 235174,
   "phone_number": 3777602956,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 958673895
 },
 {
   "policy_number": 973131,
   "phone_number": 1348064818,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 15872130
 },
 {
   "policy_number": 403895,
   "phone_number": 8046266125,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 100833952
 },
 {
   "policy_number": 164179,
   "phone_number": 7027040527,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 443049773
 },
 {
   "policy_number": 495105,
   "phone_number": 8419197724,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 373128023
 },
 {
   "policy_number": 197450,
   "phone_number": 8275203228,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 583820076
 },
 {
   "policy_number": 629484,
   "phone_number": 7452027151,
   "insurance_provider": "Cigna",
   "billing_amount": "Hryvnia",
   "payment_status": "Paid",
   "patient_id": 16645202
 },
 {
   "policy_number": 486143,
   "phone_number": 2957774803,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 358659356
 },
 {
   "policy_number": 802350,
   "phone_number": 1163454657,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 767925392
 },
 {
   "policy_number": 331758,
   "phone_number": 5671821220,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Vatu",
   "payment_status": "Unpaid",
   "patient_id": 442239244
 },
 {
   "policy_number": 909937,
   "phone_number": 6276320343,
   "insurance_provider": "Aetna",
   "billing_amount": "Dong",
   "payment_status": "Partial",
   "patient_id": 360962395
 },
 {
   "policy_number": 694839,
   "phone_number": 1551366093,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 969926022
 },
 {
   "policy_number": 639130,
   "phone_number": 4321849501,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 760783680
 },
 {
   "policy_number": 411569,
   "phone_number": 2011043602,
   "insurance_provider": "Cigna",
   "billing_amount": "Manat",
   "payment_status": "Paid",
   "patient_id": 426150282
 },
 {
   "policy_number": 332314,
   "phone_number": 4904868675,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 245156077
 },
 {
   "policy_number": 505225,
   "phone_number": 5493006295,
   "insurance_provider": "Aetna",
   "billing_amount": "Franc",
   "payment_status": "Unpaid",
   "patient_id": 845135006
 },
 {
   "policy_number": 416107,
   "phone_number": 6565543473,
   "insurance_provider": "Cigna",
   "billing_amount": "Lek",
   "payment_status": "Unpaid",
   "patient_id": 95439846
 },
 {
   "policy_number": 832197,
   "phone_number": 3084472601,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 491504279
 },
 {
   "policy_number": 389707,
   "phone_number": 4388379562,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Paid",
   "patient_id": 561522838
 },
 {
   "policy_number": 440990,
   "phone_number": 5122672289,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 63383900
 },
 {
   "policy_number": 958827,
   "phone_number": 2182374761,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kuna",
   "payment_status": "Partial",
   "patient_id": 726967084
 },
 {
   "policy_number": 903981,
   "phone_number": 2688349923,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 951806645
 },
 {
   "policy_number": 900482,
   "phone_number": 5666195635,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 56796787
 },
 {
   "policy_number": 646098,
   "phone_number": 9829590117,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 592008114
 },
 {
   "policy_number": 483235,
   "phone_number": 7352062019,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 737894934
 },
 {
   "policy_number": 340843,
   "phone_number": 3031171815,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 642803844
 },
 {
   "policy_number": 943960,
   "phone_number": 5137119796,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 750433834
 },
 {
   "policy_number": 602080,
   "phone_number": 3929698641,
   "insurance_provider": "Cigna",
   "billing_amount": "Shilling",
   "payment_status": "Partial",
   "patient_id": 627864350
 },
 {
   "policy_number": 877387,
   "phone_number": 6974559788,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Birr",
   "payment_status": "Unpaid",
   "patient_id": 222715264
 },
 {
   "policy_number": 178523,
   "phone_number": 3958932134,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 649394034
 },
 {
   "policy_number": 559122,
   "phone_number": 1777636250,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 591904943
 },
 {
   "policy_number": 832765,
   "phone_number": 5609838000,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 810238921
 },
 {
   "policy_number": 800518,
   "phone_number": 1066871080,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 666059384
 },
 {
   "policy_number": 725241,
   "phone_number": 9183250172,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 381282331
 },
 {
   "policy_number": 506555,
   "phone_number": 2638844793,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 924528870
 },
 {
   "policy_number": 810189,
   "phone_number": 7243407940,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 86059531
 },
 {
   "policy_number": 512345,
   "phone_number": 1411010941,
   "insurance_provider": "Aetna",
   "billing_amount": "Denar",
   "payment_status": "Partial",
   "patient_id": 407769727
 },
 {
   "policy_number": 281220,
   "phone_number": 2562422566,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 282326788
 },
 {
   "policy_number": 972954,
   "phone_number": 5762892442,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 186918018
 },
 {
   "policy_number": 885510,
   "phone_number": 8681734019,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 890414331
 },
 {
   "policy_number": 438981,
   "phone_number": 9818602480,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 708402744
 },
 {
   "policy_number": 409589,
   "phone_number": 4853457949,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 447124052
 },
 {
   "policy_number": 395084,
   "phone_number": 8708849871,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 418087409
 },
 {
   "policy_number": 237130,
   "phone_number": 5831786129,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 196178628
 },
 {
   "policy_number": 693317,
   "phone_number": 8206278374,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 627492498
 },
 {
   "policy_number": 375712,
   "phone_number": 1313365794,
   "insurance_provider": "Cigna",
   "billing_amount": "Shilling",
   "payment_status": "Unpaid",
   "patient_id": 134474461
 },
 {
   "policy_number": 259252,
   "phone_number": 2531446757,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 853201296
 },
 {
   "policy_number": 516103,
   "phone_number": 1487849617,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 474252687
 },
 {
   "policy_number": 801056,
   "phone_number": 9673310140,
   "insurance_provider": "Cigna",
   "billing_amount": "Manat",
   "payment_status": "Partial",
   "patient_id": 137137630
 },
 {
   "policy_number": 259027,
   "phone_number": 2744337788,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 661910972
 },
 {
   "policy_number": 375565,
   "phone_number": 6057767899,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 536786017
 },
 {
   "policy_number": 161636,
   "phone_number": 1142732032,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 778253730
 },
 {
   "policy_number": 441166,
   "phone_number": 5519077269,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 518505968
 },
 {
   "policy_number": 995020,
   "phone_number": 5249425003,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 707411426
 },
 {
   "policy_number": 242603,
   "phone_number": 3398743833,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 249741020
 },
 {
   "policy_number": 295894,
   "phone_number": 8877530817,
   "insurance_provider": "Aetna",
   "billing_amount": "Balboa",
   "payment_status": "Unpaid",
   "patient_id": 783018434
 },
 {
   "policy_number": 881316,
   "phone_number": 7252822860,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Partial",
   "patient_id": 349597755
 },
 {
   "policy_number": 188671,
   "phone_number": 9042895605,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 582503638
 },
 {
   "policy_number": 403645,
   "phone_number": 7915400045,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 759950584
 },
 {
   "policy_number": 608944,
   "phone_number": 9714837206,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 625735054
 },
 {
   "policy_number": 963598,
   "phone_number": 9725575582,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 570818174
 },
 {
   "policy_number": 840558,
   "phone_number": 8261970586,
   "insurance_provider": "Aetna",
   "billing_amount": "Dram",
   "payment_status": "Unpaid",
   "patient_id": 902124954
 },
 {
   "policy_number": 304694,
   "phone_number": 8433293389,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 245274251
 },
 {
   "policy_number": 696574,
   "phone_number": 4243186314,
   "insurance_provider": "Cigna",
   "billing_amount": "Rial",
   "payment_status": "Unpaid",
   "patient_id": 478632290
 },
 {
   "policy_number": 494007,
   "phone_number": 9111300218,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Pound",
   "payment_status": "Unpaid",
   "patient_id": 500039825
 },
 {
   "policy_number": 669074,
   "phone_number": 6456654600,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 338587764
 },
 {
   "policy_number": 893697,
   "phone_number": 4903293955,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 751396983
 },
 {
   "policy_number": 124452,
   "phone_number": 1034915849,
   "insurance_provider": "Aetna",
   "billing_amount": "Dong",
   "payment_status": "Partial",
   "patient_id": 50742910
 },
 {
   "policy_number": 208833,
   "phone_number": 7763897693,
   "insurance_provider": "Cigna",
   "billing_amount": "Baht",
   "payment_status": "Paid",
   "patient_id": 165462262
 },
 {
   "policy_number": 521774,
   "phone_number": 4671335626,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 863180058
 },
 {
   "policy_number": 865006,
   "phone_number": 9586939243,
   "insurance_provider": "Cigna",
   "billing_amount": "Ringgit",
   "payment_status": "Unpaid",
   "patient_id": 102052438
 },
 {
   "policy_number": 440264,
   "phone_number": 1011626750,
   "insurance_provider": "Cigna",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 871619181
 },
 {
   "policy_number": 878397,
   "phone_number": 1663616869,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 423531147
 },
 {
   "policy_number": 169280,
   "phone_number": 1655441409,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 187843865
 },
 {
   "policy_number": 184814,
   "phone_number": 9108159367,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 667342061
 },
 {
   "policy_number": 611966,
   "phone_number": 8254701202,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 140472123
 },
 {
   "policy_number": 275616,
   "phone_number": 7471753378,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 966654090
 },
 {
   "policy_number": 936894,
   "phone_number": 2605626345,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 196472497
 },
 {
   "policy_number": 815463,
   "phone_number": 7828963736,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 353386211
 },
 {
   "policy_number": 947469,
   "phone_number": 9453005475,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 980884320
 },
 {
   "policy_number": 184515,
   "phone_number": 9206761440,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 846986230
 },
 {
   "policy_number": 368120,
   "phone_number": 7892069996,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 376436306
 },
 {
   "policy_number": 881365,
   "phone_number": 4739126168,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 942341893
 },
 {
   "policy_number": 491626,
   "phone_number": 2858735595,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 521982124
 },
 {
   "policy_number": 531988,
   "phone_number": 2148963630,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 927918713
 },
 {
   "policy_number": 132922,
   "phone_number": 6402240815,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 781909731
 },
 {
   "policy_number": 903547,
   "phone_number": 1497394177,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 547279741
 },
 {
   "policy_number": 510981,
   "phone_number": 1109218439,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 215793399
 },
 {
   "policy_number": 188302,
   "phone_number": 8119298186,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 486924060
 },
 {
   "policy_number": 751959,
   "phone_number": 6923103257,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 148654152
 },
 {
   "policy_number": 464141,
   "phone_number": 1002197904,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 197898918
 },
 {
   "policy_number": 924288,
   "phone_number": 9989230554,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 160534729
 },
 {
   "policy_number": 739998,
   "phone_number": 9458746640,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 653097176
 },
 {
   "policy_number": 979840,
   "phone_number": 9757098902,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 121001453
 },
 {
   "policy_number": 974452,
   "phone_number": 9511455822,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 606965170
 },
 {
   "policy_number": 758241,
   "phone_number": 9242100393,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 637796172
 },
 {
   "policy_number": 880677,
   "phone_number": 6055464829,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 435260700
 },
 {
   "policy_number": 916870,
   "phone_number": 1816134517,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 706180084
 },
 {
   "policy_number": 218186,
   "phone_number": 4676408816,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 623294770
 },
 {
   "policy_number": 724163,
   "phone_number": 8572074912,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 660125232
 },
 {
   "policy_number": 463014,
   "phone_number": 8508462565,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 768934003
 },
 {
   "policy_number": 465770,
   "phone_number": 6345331825,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 350104204
 },
 {
   "policy_number": 477093,
   "phone_number": 3954893217,
   "insurance_provider": "Aetna",
   "billing_amount": "Shekel",
   "payment_status": "Unpaid",
   "patient_id": 484172695
 },
 {
   "policy_number": 227553,
   "phone_number": 7682609804,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Baht",
   "payment_status": "Unpaid",
   "patient_id": 883839913
 },
 {
   "policy_number": 305324,
   "phone_number": 4934359478,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 488400609
 },
 {
   "policy_number": 648207,
   "phone_number": 5332447046,
   "insurance_provider": "Cigna",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 625023306
 },
 {
   "policy_number": 152421,
   "phone_number": 2247533695,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 829378323
 },
 {
   "policy_number": 194727,
   "phone_number": 6595702353,
   "insurance_provider": "Cigna",
   "billing_amount": "Balboa",
   "payment_status": "Unpaid",
   "patient_id": 738299771
 },
 {
   "policy_number": 640110,
   "phone_number": 4211435940,
   "insurance_provider": "Cigna",
   "billing_amount": "Pula",
   "payment_status": "Paid",
   "patient_id": 76270626
 },
 {
   "policy_number": 475913,
   "phone_number": 7165839732,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 881194918
 },
 {
   "policy_number": 959108,
   "phone_number": 2563773952,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 890556032
 },
 {
   "policy_number": 897642,
   "phone_number": 5337123148,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 655152320
 },
 {
   "policy_number": 517786,
   "phone_number": 5353626341,
   "insurance_provider": "Aetna",
   "billing_amount": "Denar",
   "payment_status": "Unpaid",
   "patient_id": 734169746
 },
 {
   "policy_number": 445954,
   "phone_number": 6959392662,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kuna",
   "payment_status": "Partial",
   "patient_id": 37776151
 },
 {
   "policy_number": 584048,
   "phone_number": 8108012694,
   "insurance_provider": "Aetna",
   "billing_amount": "Krone",
   "payment_status": "Partial",
   "patient_id": 929970592
 },
 {
   "policy_number": 835728,
   "phone_number": 2402054717,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 946192834
 },
 {
   "policy_number": 126542,
   "phone_number": 1652928776,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 880451231
 },
 {
   "policy_number": 336178,
   "phone_number": 1367443397,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 415234328
 },
 {
   "policy_number": 292861,
   "phone_number": 9761738088,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 666654684
 },
 {
   "policy_number": 457123,
   "phone_number": 4547305763,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 583467087
 },
 {
   "policy_number": 719653,
   "phone_number": 6716002417,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 527249909
 },
 {
   "policy_number": 335667,
   "phone_number": 4313749779,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 14394039
 },
 {
   "policy_number": 177959,
   "phone_number": 9429237269,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 218900712
 },
 {
   "policy_number": 302241,
   "phone_number": 9325174475,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 300141645
 },
 {
   "policy_number": 542493,
   "phone_number": 3905584788,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 630381666
 },
 {
   "policy_number": 951624,
   "phone_number": 4669353757,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 786152038
 },
 {
   "policy_number": 183097,
   "phone_number": 1486994831,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 858357322
 },
 {
   "policy_number": 598045,
   "phone_number": 1932195179,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 22415356
 },
 {
   "policy_number": 274591,
   "phone_number": 5322444878,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 366151155
 },
 {
   "policy_number": 578923,
   "phone_number": 2751980644,
   "insurance_provider": "Cigna",
   "billing_amount": "Won",
   "payment_status": "Unpaid",
   "patient_id": 954313360
 },
 {
   "policy_number": 938852,
   "phone_number": 3471413671,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 386026887
 },
 {
   "policy_number": 470218,
   "phone_number": 8967728056,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 324923515
 },
 {
   "policy_number": 761591,
   "phone_number": 2945015548,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 943575883
 },
 {
   "policy_number": 791990,
   "phone_number": 8903041342,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 883167311
 },
 {
   "policy_number": 149115,
   "phone_number": 5264001164,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dong",
   "payment_status": "Unpaid",
   "patient_id": 731826895
 },
 {
   "policy_number": 319821,
   "phone_number": 8645238652,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Unpaid",
   "patient_id": 703959081
 },
 {
   "policy_number": 348016,
   "phone_number": 1736552643,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 744223687
 },
 {
   "policy_number": 528354,
   "phone_number": 8265899266,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 612258223
 },
 {
   "policy_number": 546667,
   "phone_number": 8133252503,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 709888692
 },
 {
   "policy_number": 447048,
   "phone_number": 8556564163,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 669229183
 },
 {
   "policy_number": 520303,
   "phone_number": 3651099653,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 858823891
 },
 {
   "policy_number": 388361,
   "phone_number": 7898958818,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 654723307
 },
 {
   "policy_number": 858007,
   "phone_number": 1355471408,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 63960445
 },
 {
   "policy_number": 570407,
   "phone_number": 8301445382,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 42843440
 },
 {
   "policy_number": 179008,
   "phone_number": 4066427445,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 819407643
 },
 {
   "policy_number": 930518,
   "phone_number": 8612390366,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 25927147
 },
 {
   "policy_number": 211040,
   "phone_number": 5182048633,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 353202695
 },
 {
   "policy_number": 245904,
   "phone_number": 6765492841,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 747592361
 },
 {
   "policy_number": 721670,
   "phone_number": 1721042601,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 627415781
 },
 {
   "policy_number": 653766,
   "phone_number": 7388067998,
   "insurance_provider": "Aetna",
   "billing_amount": "Manat",
   "payment_status": "Unpaid",
   "patient_id": 18573610
 },
 {
   "policy_number": 756643,
   "phone_number": 9839614530,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 39917989
 },
 {
   "policy_number": 635349,
   "phone_number": 6789571193,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 878378933
 },
 {
   "policy_number": 941573,
   "phone_number": 4727530543,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 879106274
 },
 {
   "policy_number": 864522,
   "phone_number": 5365327267,
   "insurance_provider": "Cigna",
   "billing_amount": "Kwacha",
   "payment_status": "Partial",
   "patient_id": 454491716
 },
 {
   "policy_number": 882461,
   "phone_number": 1515524241,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 483478758
 },
 {
   "policy_number": 658322,
   "phone_number": 4574091546,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 572319515
 },
 {
   "policy_number": 198433,
   "phone_number": 2439109626,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 366575206
 },
 {
   "policy_number": 410664,
   "phone_number": 7005214197,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 846657317
 },
 {
   "policy_number": 180669,
   "phone_number": 2239930736,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 25021711
 },
 {
   "policy_number": 161010,
   "phone_number": 7851308552,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 74695298
 },
 {
   "policy_number": 201119,
   "phone_number": 3194988064,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 147212329
 },
 {
   "policy_number": 379286,
   "phone_number": 6379200002,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Won",
   "payment_status": "Partial",
   "patient_id": 811639771
 },
 {
   "policy_number": 419559,
   "phone_number": 9078307149,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 331010101
 },
 {
   "policy_number": 123840,
   "phone_number": 1294156568,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 2297959
 },
 {
   "policy_number": 109517,
   "phone_number": 4039366327,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 934262350
 },
 {
   "policy_number": 171287,
   "phone_number": 7956352754,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 290461967
 },
 {
   "policy_number": 494675,
   "phone_number": 4372456476,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 900240510
 },
 {
   "policy_number": 471178,
   "phone_number": 3359978735,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 973387827
 },
 {
   "policy_number": 593769,
   "phone_number": 8301808232,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 681948800
 },
 {
   "policy_number": 352613,
   "phone_number": 4193365254,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 178145847
 },
 {
   "policy_number": 582197,
   "phone_number": 9471975095,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 187208422
 },
 {
   "policy_number": 380059,
   "phone_number": 9474329873,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 341300963
 },
 {
   "policy_number": 794652,
   "phone_number": 2921844886,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 56390042
 },
 {
   "policy_number": 347807,
   "phone_number": 3669017278,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 590508251
 },
 {
   "policy_number": 310340,
   "phone_number": 5448032687,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 935388170
 },
 {
   "policy_number": 730950,
   "phone_number": 7582334869,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Denar",
   "payment_status": "Unpaid",
   "patient_id": 969405591
 },
 {
   "policy_number": 141258,
   "phone_number": 6604588404,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 381131738
 },
 {
   "policy_number": 956306,
   "phone_number": 8227987549,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 592055135
 },
 {
   "policy_number": 608662,
   "phone_number": 9351433728,
   "insurance_provider": "Aetna",
   "billing_amount": "Som",
   "payment_status": "Paid",
   "patient_id": 599939092
 },
 {
   "policy_number": 847632,
   "phone_number": 7196712708,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 207667394
 },
 {
   "policy_number": 126473,
   "phone_number": 8273247073,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 447750689
 },
 {
   "policy_number": 519974,
   "phone_number": 7198046965,
   "insurance_provider": "Aetna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 429411258
 },
 {
   "policy_number": 761950,
   "phone_number": 1578694333,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 797862327
 },
 {
   "policy_number": 320965,
   "phone_number": 3835225792,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 479407967
 },
 {
   "policy_number": 838806,
   "phone_number": 3778233571,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 210876543
 },
 {
   "policy_number": 354995,
   "phone_number": 1118278707,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dong",
   "payment_status": "Unpaid",
   "patient_id": 604515794
 },
 {
   "policy_number": 751647,
   "phone_number": 2399011988,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 989879335
 },
 {
   "policy_number": 534690,
   "phone_number": 7595535757,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 220735964
 },
 {
   "policy_number": 537972,
   "phone_number": 3136411293,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 808413564
 },
 {
   "policy_number": 733475,
   "phone_number": 3461758911,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 829467866
 },
 {
   "policy_number": 755653,
   "phone_number": 1471582277,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 188513616
 },
 {
   "policy_number": 218209,
   "phone_number": 9939061185,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupee",
   "payment_status": "Unpaid",
   "patient_id": 901854803
 },
 {
   "policy_number": 182922,
   "phone_number": 3007833330,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Unpaid",
   "patient_id": 491919538
 },
 {
   "policy_number": 534431,
   "phone_number": 3191737104,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupee",
   "payment_status": "Partial",
   "patient_id": 659724148
 },
 {
   "policy_number": 550895,
   "phone_number": 8684229904,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 145389062
 },
 {
   "policy_number": 870209,
   "phone_number": 3692573187,
   "insurance_provider": "Cigna",
   "billing_amount": "Shekel",
   "payment_status": "Partial",
   "patient_id": 776243688
 },
 {
   "policy_number": 391276,
   "phone_number": 6021807377,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 184592138
 },
 {
   "policy_number": 314011,
   "phone_number": 8575377869,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Hryvnia",
   "payment_status": "Paid",
   "patient_id": 621004408
 },
 {
   "policy_number": 813681,
   "phone_number": 8113673897,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 252815187
 },
 {
   "policy_number": 287195,
   "phone_number": 9388722086,
   "insurance_provider": "Aetna",
   "billing_amount": "Naira",
   "payment_status": "Unpaid",
   "patient_id": 545455312
 },
 {
   "policy_number": 126621,
   "phone_number": 9102397685,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 523320726
 },
 {
   "policy_number": 918038,
   "phone_number": 1918710953,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 598563519
 },
 {
   "policy_number": 635237,
   "phone_number": 1045513002,
   "insurance_provider": "Aetna",
   "billing_amount": "Dirham",
   "payment_status": "Partial",
   "patient_id": 937545077
 },
 {
   "policy_number": 392461,
   "phone_number": 9621362278,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Hryvnia",
   "payment_status": "Paid",
   "patient_id": 99096823
 },
 {
   "policy_number": 350804,
   "phone_number": 4536058028,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 436995951
 },
 {
   "policy_number": 140115,
   "phone_number": 8244068259,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Afghani",
   "payment_status": "Partial",
   "patient_id": 42423535
 },
 {
   "policy_number": 362397,
   "phone_number": 3673013302,
   "insurance_provider": "Cigna",
   "billing_amount": "Rand",
   "payment_status": "Unpaid",
   "patient_id": 806821599
 },
 {
   "policy_number": 765779,
   "phone_number": 7819812258,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 428044745
 },
 {
   "policy_number": 299927,
   "phone_number": 5668557977,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 585156219
 },
 {
   "policy_number": 826807,
   "phone_number": 3649775588,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 960806565
 },
 {
   "policy_number": 109337,
   "phone_number": 1227256260,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 376111879
 },
 {
   "policy_number": 523597,
   "phone_number": 7768432906,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 246164908
 },
 {
   "policy_number": 961691,
   "phone_number": 7778684961,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 208177476
 },
 {
   "policy_number": 127215,
   "phone_number": 3152936420,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Quetzal",
   "payment_status": "Unpaid",
   "patient_id": 35575624
 },
 {
   "policy_number": 760294,
   "phone_number": 1346871216,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 255011495
 },
 {
   "policy_number": 646166,
   "phone_number": 7718989680,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 204613429
 },
 {
   "policy_number": 971037,
   "phone_number": 3357898405,
   "insurance_provider": "Aetna",
   "billing_amount": "Sol",
   "payment_status": "Partial",
   "patient_id": 3920046
 },
 {
   "policy_number": 947928,
   "phone_number": 8155145900,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 730244038
 },
 {
   "policy_number": 231342,
   "phone_number": 1601448579,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 907809267
 },
 {
   "policy_number": 223907,
   "phone_number": 2242507422,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Naira",
   "payment_status": "Paid",
   "patient_id": 328484013
 },
 {
   "policy_number": 239504,
   "phone_number": 3336213934,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 154597673
 },
 {
   "policy_number": 539283,
   "phone_number": 2537255660,
   "insurance_provider": "Aetna",
   "billing_amount": "Won",
   "payment_status": "Partial",
   "patient_id": 697094684
 },
 {
   "policy_number": 896383,
   "phone_number": 4882906961,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 929063617
 },
 {
   "policy_number": 864475,
   "phone_number": 2706778134,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 603095791
 },
 {
   "policy_number": 953988,
   "phone_number": 5542308841,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 333820060
 },
 {
   "policy_number": 736277,
   "phone_number": 4477331045,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 682607507
 },
 {
   "policy_number": 451550,
   "phone_number": 8591737796,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 994855858
 },
 {
   "policy_number": 675968,
   "phone_number": 1711463915,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 592374001
 },
 {
   "policy_number": 224347,
   "phone_number": 4732507082,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 273416192
 },
 {
   "policy_number": 188152,
   "phone_number": 7322447397,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 364249880
 },
 {
   "policy_number": 602933,
   "phone_number": 3641267910,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 273661298
 },
 {
   "policy_number": 193691,
   "phone_number": 8898211067,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 65371072
 },
 {
   "policy_number": 187006,
   "phone_number": 9859514311,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 180138867
 },
 {
   "policy_number": 552614,
   "phone_number": 2992343033,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 155537626
 },
 {
   "policy_number": 483946,
   "phone_number": 4466858476,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 506688784
 },
 {
   "policy_number": 475296,
   "phone_number": 5262213820,
   "insurance_provider": "Cigna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 71090443
 },
 {
   "policy_number": 269831,
   "phone_number": 4369723030,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 394352457
 },
 {
   "policy_number": 403852,
   "phone_number": 8998626609,
   "insurance_provider": "Cigna",
   "billing_amount": "Lek",
   "payment_status": "Paid",
   "patient_id": 581906070
 },
 {
   "policy_number": 545444,
   "phone_number": 7742962306,
   "insurance_provider": "Cigna",
   "billing_amount": "Franc",
   "payment_status": "Paid",
   "patient_id": 719019779
 },
 {
   "policy_number": 199390,
   "phone_number": 4401127436,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 649261849
 },
 {
   "policy_number": 774435,
   "phone_number": 5091221646,
   "insurance_provider": "Cigna",
   "billing_amount": "Cordoba",
   "payment_status": "Partial",
   "patient_id": 333221560
 },
 {
   "policy_number": 927023,
   "phone_number": 1184713060,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 372813190
 },
 {
   "policy_number": 460364,
   "phone_number": 3422799705,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 85007457
 },
 {
   "policy_number": 429984,
   "phone_number": 9533337443,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 388072192
 },
 {
   "policy_number": 219721,
   "phone_number": 4266435931,
   "insurance_provider": "Cigna",
   "billing_amount": "Hryvnia",
   "payment_status": "Unpaid",
   "patient_id": 502880069
 },
 {
   "policy_number": 653939,
   "phone_number": 8549371818,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kyat",
   "payment_status": "Unpaid",
   "patient_id": 403168081
 },
 {
   "policy_number": 184739,
   "phone_number": 7669572140,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 444020272
 },
 {
   "policy_number": 482889,
   "phone_number": 1601266455,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 643925198
 },
 {
   "policy_number": 410577,
   "phone_number": 7483706315,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 395843428
 },
 {
   "policy_number": 705383,
   "phone_number": 9753818028,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Unpaid",
   "patient_id": 567334355
 },
 {
   "policy_number": 330851,
   "phone_number": 2286589174,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 388051628
 },
 {
   "policy_number": 690881,
   "phone_number": 8331835586,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 390924633
 },
 {
   "policy_number": 874486,
   "phone_number": 1028601419,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 416720452
 },
 {
   "policy_number": 810624,
   "phone_number": 8362407438,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 797659316
 },
 {
   "policy_number": 552052,
   "phone_number": 6045467604,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 752517319
 },
 {
   "policy_number": 605315,
   "phone_number": 7571743793,
   "insurance_provider": "Cigna",
   "billing_amount": "Pound",
   "payment_status": "Unpaid",
   "patient_id": 47866943
 },
 {
   "policy_number": 833971,
   "phone_number": 7837044674,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 877265404
 },
 {
   "policy_number": 882767,
   "phone_number": 9203751365,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 228493718
 },
 {
   "policy_number": 709512,
   "phone_number": 5047851408,
   "insurance_provider": "Aetna",
   "billing_amount": "Lempira",
   "payment_status": "Unpaid",
   "patient_id": 806283022
 },
 {
   "policy_number": 794787,
   "phone_number": 1772364331,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 939205933
 },
 {
   "policy_number": 333952,
   "phone_number": 3738684449,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Partial",
   "patient_id": 257708969
 },
 {
   "policy_number": 253966,
   "phone_number": 7188617004,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 883510909
 },
 {
   "policy_number": 620714,
   "phone_number": 8133895057,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 472481729
 },
 {
   "policy_number": 153345,
   "phone_number": 7614773257,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 780975441
 },
 {
   "policy_number": 436272,
   "phone_number": 3517523420,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 873684294
 },
 {
   "policy_number": 971189,
   "phone_number": 6819002099,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 318485506
 },
 {
   "policy_number": 580060,
   "phone_number": 5209346618,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 970283344
 },
 {
   "policy_number": 941999,
   "phone_number": 4531845575,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 813290433
 },
 {
   "policy_number": 480919,
   "phone_number": 5894057635,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 684321934
 },
 {
   "policy_number": 765200,
   "phone_number": 7337345181,
   "insurance_provider": "Cigna",
   "billing_amount": "Lev",
   "payment_status": "Unpaid",
   "patient_id": 396824525
 },
 {
   "policy_number": 574552,
   "phone_number": 1584857869,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 747195788
 },
 {
   "policy_number": 589112,
   "phone_number": 3867547825,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 738184994
 },
 {
   "policy_number": 910074,
   "phone_number": 4643958408,
   "insurance_provider": "Cigna",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 306449774
 },
 {
   "policy_number": 171081,
   "phone_number": 2719274927,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 31093536
 },
 {
   "policy_number": 441254,
   "phone_number": 6774644161,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 443159557
 },
 {
   "policy_number": 617341,
   "phone_number": 8816486757,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Shilling",
   "payment_status": "Unpaid",
   "patient_id": 505834958
 },
 {
   "policy_number": 502035,
   "phone_number": 3101578025,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 732127954
 },
 {
   "policy_number": 309202,
   "phone_number": 5179680655,
   "insurance_provider": "Cigna",
   "billing_amount": "Rial",
   "payment_status": "Partial",
   "patient_id": 203291276
 },
 {
   "policy_number": 134172,
   "phone_number": 3065030505,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 699496459
 },
 {
   "policy_number": 669118,
   "phone_number": 8414451047,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 384857728
 },
 {
   "policy_number": 431586,
   "phone_number": 6829680633,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Unpaid",
   "patient_id": 820763212
 },
 {
   "policy_number": 705582,
   "phone_number": 7247942450,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 632031678
 },
 {
   "policy_number": 167673,
   "phone_number": 2979868842,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 45145366
 },
 {
   "policy_number": 718395,
   "phone_number": 8157991202,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 404231713
 },
 {
   "policy_number": 772754,
   "phone_number": 8595162914,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 769193118
 },
 {
   "policy_number": 338219,
   "phone_number": 7199622254,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 858031186
 },
 {
   "policy_number": 435059,
   "phone_number": 7566584940,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 666404959
 },
 {
   "policy_number": 582986,
   "phone_number": 1289053317,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 995167361
 },
 {
   "policy_number": 512185,
   "phone_number": 2791980019,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dram",
   "payment_status": "Paid",
   "patient_id": 969806601
 },
 {
   "policy_number": 694496,
   "phone_number": 1012744187,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 161179524
 },
 {
   "policy_number": 935059,
   "phone_number": 7549828509,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Litas",
   "payment_status": "Paid",
   "patient_id": 587742970
 },
 {
   "policy_number": 954380,
   "phone_number": 5241943628,
   "insurance_provider": "Aetna",
   "billing_amount": "Lempira",
   "payment_status": "Paid",
   "patient_id": 312156718
 },
 {
   "policy_number": 526432,
   "phone_number": 9893471448,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 800183744
 },
 {
   "policy_number": 372597,
   "phone_number": 2526906582,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 582841888
 },
 {
   "policy_number": 475329,
   "phone_number": 9757270676,
   "insurance_provider": "Aetna",
   "billing_amount": "Sol",
   "payment_status": "Partial",
   "patient_id": 5567131
 },
 {
   "policy_number": 497358,
   "phone_number": 2542138468,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 505693890
 },
 {
   "policy_number": 325301,
   "phone_number": 9017714279,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 791250786
 },
 {
   "policy_number": 755316,
   "phone_number": 9703485221,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 130571109
 },
 {
   "policy_number": 528959,
   "phone_number": 3852696843,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 875417523
 },
 {
   "policy_number": 188337,
   "phone_number": 1761455682,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Krone",
   "payment_status": "Unpaid",
   "patient_id": 842734890
 },
 {
   "policy_number": 775381,
   "phone_number": 4159970646,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 533119949
 },
 {
   "policy_number": 863459,
   "phone_number": 4094230097,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 240344681
 },
 {
   "policy_number": 323376,
   "phone_number": 6451747369,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 966324907
 },
 {
   "policy_number": 729866,
   "phone_number": 4795333577,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 267175698
 },
 {
   "policy_number": 501801,
   "phone_number": 1624916112,
   "insurance_provider": "Cigna",
   "billing_amount": "Baht",
   "payment_status": "Unpaid",
   "patient_id": 789751037
 },
 {
   "policy_number": 990581,
   "phone_number": 8637512354,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Tugrik",
   "payment_status": "Paid",
   "patient_id": 864220310
 },
 {
   "policy_number": 222921,
   "phone_number": 7712190688,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 734341774
 },
 {
   "policy_number": 734483,
   "phone_number": 3431937972,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 864719756
 },
 {
   "policy_number": 127209,
   "phone_number": 5325123769,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 697049992
 },
 {
   "policy_number": 956079,
   "phone_number": 2471379742,
   "insurance_provider": "Cigna",
   "billing_amount": "Hryvnia",
   "payment_status": "Unpaid",
   "patient_id": 187125560
 },
 {
   "policy_number": 162984,
   "phone_number": 6146365327,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 28045487
 },
 {
   "policy_number": 496466,
   "phone_number": 4839717593,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 558447165
 },
 {
   "policy_number": 645599,
   "phone_number": 6055697059,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 908185378
 },
 {
   "policy_number": 435709,
   "phone_number": 7893927174,
   "insurance_provider": "Aetna",
   "billing_amount": "Baht",
   "payment_status": "Partial",
   "patient_id": 495424841
 },
 {
   "policy_number": 343344,
   "phone_number": 1275164524,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 752047936
 },
 {
   "policy_number": 918183,
   "phone_number": 4679143669,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 313519494
 },
 {
   "policy_number": 741298,
   "phone_number": 9123821511,
   "insurance_provider": "Aetna",
   "billing_amount": "Cedi",
   "payment_status": "Unpaid",
   "patient_id": 520593545
 },
 {
   "policy_number": 307859,
   "phone_number": 5945347726,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 110191095
 },
 {
   "policy_number": 186642,
   "phone_number": 6965348116,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 676935066
 },
 {
   "policy_number": 898132,
   "phone_number": 5093562492,
   "insurance_provider": "Aetna",
   "billing_amount": "Dirham",
   "payment_status": "Partial",
   "patient_id": 61612635
 },
 {
   "policy_number": 651172,
   "phone_number": 5645288401,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 760052236
 },
 {
   "policy_number": 834607,
   "phone_number": 9599180290,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 758646284
 },
 {
   "policy_number": 799249,
   "phone_number": 2501724863,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 223365582
 },
 {
   "policy_number": 287720,
   "phone_number": 6167475316,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 715222613
 },
 {
   "policy_number": 301047,
   "phone_number": 4701318588,
   "insurance_provider": "Aetna",
   "billing_amount": "Krone",
   "payment_status": "Unpaid",
   "patient_id": 974261172
 },
 {
   "policy_number": 118170,
   "phone_number": 5844807243,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ringgit",
   "payment_status": "Partial",
   "patient_id": 455378373
 },
 {
   "policy_number": 802990,
   "phone_number": 9559122540,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 993573279
 },
 {
   "policy_number": 244572,
   "phone_number": 3368262550,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 429524030
 },
 {
   "policy_number": 210340,
   "phone_number": 9662699537,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Unpaid",
   "patient_id": 503292829
 },
 {
   "policy_number": 909889,
   "phone_number": 9531533768,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 526234604
 },
 {
   "policy_number": 765366,
   "phone_number": 7482215370,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 389263482
 },
 {
   "policy_number": 277042,
   "phone_number": 3428185537,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 423750746
 },
 {
   "policy_number": 418545,
   "phone_number": 5328620107,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 167149706
 },
 {
   "policy_number": 750241,
   "phone_number": 7253881967,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 725148885
 },
 {
   "policy_number": 927870,
   "phone_number": 6908221107,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 271367290
 },
 {
   "policy_number": 926065,
   "phone_number": 1483758193,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 360920760
 },
 {
   "policy_number": 738555,
   "phone_number": 8567120050,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 351155334
 },
 {
   "policy_number": 805443,
   "phone_number": 5569580834,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 398053484
 },
 {
   "policy_number": 777213,
   "phone_number": 1555163968,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 446219873
 },
 {
   "policy_number": 995379,
   "phone_number": 6056228364,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Partial",
   "patient_id": 610671700
 },
 {
   "policy_number": 158002,
   "phone_number": 2382057279,
   "insurance_provider": "Aetna",
   "billing_amount": "Shilling",
   "payment_status": "Unpaid",
   "patient_id": 62402667
 },
 {
   "policy_number": 688401,
   "phone_number": 4271219151,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 476321216
 },
 {
   "policy_number": 943602,
   "phone_number": 1645558227,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 680145556
 },
 {
   "policy_number": 898019,
   "phone_number": 4552224506,
   "insurance_provider": "Aetna",
   "billing_amount": "Dong",
   "payment_status": "Unpaid",
   "patient_id": 636520697
 },
 {
   "policy_number": 157381,
   "phone_number": 6183958871,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 829420116
 },
 {
   "policy_number": 663412,
   "phone_number": 7369884907,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 505455481
 },
 {
   "policy_number": 704722,
   "phone_number": 8341063948,
   "insurance_provider": "Aetna",
   "billing_amount": "Pound",
   "payment_status": "Unpaid",
   "patient_id": 348420494
 },
 {
   "policy_number": 122623,
   "phone_number": 5532696999,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 677253395
 },
 {
   "policy_number": 236093,
   "phone_number": 1104478678,
   "insurance_provider": "Cigna",
   "billing_amount": "Rand",
   "payment_status": "Partial",
   "patient_id": 835227317
 },
 {
   "policy_number": 586404,
   "phone_number": 3351842701,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 338410930
 },
 {
   "policy_number": 635847,
   "phone_number": 9269812198,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 82516801
 },
 {
   "policy_number": 332796,
   "phone_number": 3452289602,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 490636288
 },
 {
   "policy_number": 535834,
   "phone_number": 2922856818,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 830911448
 },
 {
   "policy_number": 600008,
   "phone_number": 9458774845,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 307020250
 },
 {
   "policy_number": 519210,
   "phone_number": 4712230555,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 653344568
 },
 {
   "policy_number": 728230,
   "phone_number": 1756478130,
   "insurance_provider": "Aetna",
   "billing_amount": "Naira",
   "payment_status": "Paid",
   "patient_id": 803974891
 },
 {
   "policy_number": 301341,
   "phone_number": 4683198292,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 319052571
 },
 {
   "policy_number": 158707,
   "phone_number": 3138787613,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 456625759
 },
 {
   "policy_number": 713116,
   "phone_number": 4123707333,
   "insurance_provider": "Aetna",
   "billing_amount": "Dollar",
   "payment_status": "Unpaid",
   "patient_id": 286802785
 },
 {
   "policy_number": 116825,
   "phone_number": 3785873875,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Unpaid",
   "patient_id": 160595895
 },
 {
   "policy_number": 694380,
   "phone_number": 1069806620,
   "insurance_provider": "Aetna",
   "billing_amount": "Kuna",
   "payment_status": "Unpaid",
   "patient_id": 394950834
 },
 {
   "policy_number": 472400,
   "phone_number": 9987014538,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 664878310
 },
 {
   "policy_number": 146397,
   "phone_number": 8018927905,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 411640905
 },
 {
   "policy_number": 715377,
   "phone_number": 8624199882,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 766949552
 },
 {
   "policy_number": 236752,
   "phone_number": 8779481737,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 136525515
 },
 {
   "policy_number": 955913,
   "phone_number": 4468900212,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 629360169
 },
 {
   "policy_number": 430595,
   "phone_number": 8609517550,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Unpaid",
   "patient_id": 978079253
 },
 {
   "policy_number": 665764,
   "phone_number": 5532588199,
   "insurance_provider": "Cigna",
   "billing_amount": "Pound",
   "payment_status": "Unpaid",
   "patient_id": 740012748
 },
 {
   "policy_number": 875571,
   "phone_number": 9157328719,
   "insurance_provider": "Aetna",
   "billing_amount": "Tugrik",
   "payment_status": "Unpaid",
   "patient_id": 634565899
 },
 {
   "policy_number": 738486,
   "phone_number": 7982813403,
   "insurance_provider": "Aetna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 170169666
 },
 {
   "policy_number": 556964,
   "phone_number": 2644478181,
   "insurance_provider": "Aetna",
   "billing_amount": "Lek",
   "payment_status": "Unpaid",
   "patient_id": 575653879
 },
 {
   "policy_number": 391810,
   "phone_number": 3725950594,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 613797911
 },
 {
   "policy_number": 380321,
   "phone_number": 6208566892,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 805570965
 },
 {
   "policy_number": 764236,
   "phone_number": 4952670735,
   "insurance_provider": "Aetna",
   "billing_amount": "Pound",
   "payment_status": "Paid",
   "patient_id": 533980153
 },
 {
   "policy_number": 627127,
   "phone_number": 4676533902,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 410895481
 },
 {
   "policy_number": 896975,
   "phone_number": 6266335521,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Paid",
   "patient_id": 172199378
 },
 {
   "policy_number": 550107,
   "phone_number": 8519375584,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 42603162
 },
 {
   "policy_number": 781656,
   "phone_number": 9079934757,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 457685546
 },
 {
   "policy_number": 514664,
   "phone_number": 4676064198,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 737188999
 },
 {
   "policy_number": 209245,
   "phone_number": 5413926156,
   "insurance_provider": "Cigna",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 941996225
 },
 {
   "policy_number": 771940,
   "phone_number": 8674409888,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Franc",
   "payment_status": "Unpaid",
   "patient_id": 334830018
 },
 {
   "policy_number": 445728,
   "phone_number": 6976660108,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 827834808
 },
 {
   "policy_number": 432775,
   "phone_number": 3944549551,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 82428620
 },
 {
   "policy_number": 750225,
   "phone_number": 4758879151,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 920397895
 },
 {
   "policy_number": 599232,
   "phone_number": 3066460173,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 598094261
 },
 {
   "policy_number": 213537,
   "phone_number": 1797310842,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 710298268
 },
 {
   "policy_number": 558676,
   "phone_number": 2198157448,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 544336421
 },
 {
   "policy_number": 756175,
   "phone_number": 9152106991,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 701693862
 },
 {
   "policy_number": 841784,
   "phone_number": 5583612575,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Paid",
   "patient_id": 617236500
 },
 {
   "policy_number": 294462,
   "phone_number": 3952998633,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 426606480
 },
 {
   "policy_number": 415457,
   "phone_number": 2027061317,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 954134662
 },
 {
   "policy_number": 741549,
   "phone_number": 9951249822,
   "insurance_provider": "Aetna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 970865766
 },
 {
   "policy_number": 548176,
   "phone_number": 7869606309,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 483638406
 },
 {
   "policy_number": 843247,
   "phone_number": 3347967028,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 705580317
 },
 {
   "policy_number": 763625,
   "phone_number": 4704390716,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Paid",
   "patient_id": 799059055
 },
 {
   "policy_number": 710034,
   "phone_number": 7111229858,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 17338453
 },
 {
   "policy_number": 311871,
   "phone_number": 4325293536,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 377306027
 },
 {
   "policy_number": 470590,
   "phone_number": 1282105027,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Partial",
   "patient_id": 588625438
 },
 {
   "policy_number": 470566,
   "phone_number": 8052616887,
   "insurance_provider": "Cigna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 858545236
 },
 {
   "policy_number": 345781,
   "phone_number": 9218485999,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 207627194
 },
 {
   "policy_number": 957021,
   "phone_number": 4379092721,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 886836391
 },
 {
   "policy_number": 694333,
   "phone_number": 7655470396,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Lari",
   "payment_status": "Unpaid",
   "patient_id": 357098270
 },
 {
   "policy_number": 367386,
   "phone_number": 7936639226,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 749114152
 },
 {
   "policy_number": 417193,
   "phone_number": 4448708499,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Paid",
   "patient_id": 642128006
 },
 {
   "policy_number": 377650,
   "phone_number": 1439683672,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 54104016
 },
 {
   "policy_number": 185375,
   "phone_number": 5256537294,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 65340054
 },
 {
   "policy_number": 220661,
   "phone_number": 2609240364,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Unpaid",
   "patient_id": 127514732
 },
 {
   "policy_number": 833118,
   "phone_number": 6086101366,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 603227507
 },
 {
   "policy_number": 982718,
   "phone_number": 1062810848,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 793312476
 },
 {
   "policy_number": 943822,
   "phone_number": 8463730011,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Partial",
   "patient_id": 926837897
 },
 {
   "policy_number": 871437,
   "phone_number": 3546311210,
   "insurance_provider": "Cigna",
   "billing_amount": "Pula",
   "payment_status": "Partial",
   "patient_id": 651066349
 },
 {
   "policy_number": 466284,
   "phone_number": 4787320880,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 738850041
 },
 {
   "policy_number": 658397,
   "phone_number": 7841543784,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 905531458
 },
 {
   "policy_number": 327331,
   "phone_number": 9828816371,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dinar",
   "payment_status": "Paid",
   "patient_id": 202945400
 },
 {
   "policy_number": 315983,
   "phone_number": 4738775967,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 948692529
 },
 {
   "policy_number": 760845,
   "phone_number": 3542407054,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Unpaid",
   "patient_id": 954112687
 },
 {
   "policy_number": 700248,
   "phone_number": 7136638823,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 353318290
 },
 {
   "policy_number": 786267,
   "phone_number": 5717563485,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Dollar",
   "payment_status": "Partial",
   "patient_id": 38612144
 },
 {
   "policy_number": 499503,
   "phone_number": 4031795316,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 878198207
 },
 {
   "policy_number": 836945,
   "phone_number": 7045131297,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 30260222
 },
 {
   "policy_number": 436667,
   "phone_number": 2427558479,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 416034690
 },
 {
   "policy_number": 798205,
   "phone_number": 7985448040,
   "insurance_provider": "Aetna",
   "billing_amount": "Manat",
   "payment_status": "Partial",
   "patient_id": 865213684
 },
 {
   "policy_number": 696071,
   "phone_number": 5281973290,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 693441454
 },
 {
   "policy_number": 747235,
   "phone_number": 9634549236,
   "insurance_provider": "Cigna",
   "billing_amount": "Tugrik",
   "payment_status": "Partial",
   "patient_id": 595184482
 },
 {
   "policy_number": 263353,
   "phone_number": 7329163435,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ringgit",
   "payment_status": "Paid",
   "patient_id": 36541113
 },
 {
   "policy_number": 120260,
   "phone_number": 2549400262,
   "insurance_provider": "Cigna",
   "billing_amount": "Tenge",
   "payment_status": "Unpaid",
   "patient_id": 267413981
 },
 {
   "policy_number": 304261,
   "phone_number": 5725019595,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 118145479
 },
 {
   "policy_number": 528758,
   "phone_number": 6105895054,
   "insurance_provider": "Cigna",
   "billing_amount": "Yen",
   "payment_status": "Unpaid",
   "patient_id": 56538788
 },
 {
   "policy_number": 626512,
   "phone_number": 5699056872,
   "insurance_provider": "Cigna",
   "billing_amount": "Dollar",
   "payment_status": "Paid",
   "patient_id": 631870869
 },
 {
   "policy_number": 761417,
   "phone_number": 9148262155,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 627832947
 },
 {
   "policy_number": 555294,
   "phone_number": 4186719929,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 963998441
 },
 {
   "policy_number": 686462,
   "phone_number": 1227570965,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 783858327
 },
 {
   "policy_number": 281472,
   "phone_number": 4886667847,
   "insurance_provider": "Cigna",
   "billing_amount": "Dinar",
   "payment_status": "Unpaid",
   "patient_id": 787822005
 },
 {
   "policy_number": 884547,
   "phone_number": 1641760619,
   "insurance_provider": "Aetna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 751031194
 },
 {
   "policy_number": 855934,
   "phone_number": 7592293384,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 655100135
 },
 {
   "policy_number": 319430,
   "phone_number": 2942071886,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 668110119
 },
 {
   "policy_number": 511851,
   "phone_number": 3863306036,
   "insurance_provider": "Aetna",
   "billing_amount": "Naira",
   "payment_status": "Partial",
   "patient_id": 686409607
 },
 {
   "policy_number": 248050,
   "phone_number": 8402865517,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 759161476
 },
 {
   "policy_number": 402606,
   "phone_number": 8162643664,
   "insurance_provider": "Aetna",
   "billing_amount": "Shekel",
   "payment_status": "Partial",
   "patient_id": 569000498
 },
 {
   "policy_number": 140517,
   "phone_number": 9534629256,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Koruna",
   "payment_status": "Paid",
   "patient_id": 53392125
 },
 {
   "policy_number": 443677,
   "phone_number": 4338811344,
   "insurance_provider": "Aetna",
   "billing_amount": "Real",
   "payment_status": "Paid",
   "patient_id": 355821067
 },
 {
   "policy_number": 141977,
   "phone_number": 3961866957,
   "insurance_provider": "Aetna",
   "billing_amount": "Zloty",
   "payment_status": "Paid",
   "patient_id": 190058585
 },
 {
   "policy_number": 461287,
   "phone_number": 3324484508,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Real",
   "payment_status": "Unpaid",
   "patient_id": 795916875
 },
 {
   "policy_number": 511094,
   "phone_number": 4395778942,
   "insurance_provider": "Cigna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 904946044
 },
 {
   "policy_number": 379298,
   "phone_number": 4092228612,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 750457543
 },
 {
   "policy_number": 711238,
   "phone_number": 5635423517,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 911206717
 },
 {
   "policy_number": 203490,
   "phone_number": 3801003450,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 978085718
 },
 {
   "policy_number": 704115,
   "phone_number": 7886524338,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 772647129
 },
 {
   "policy_number": 201862,
   "phone_number": 6991205612,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Unpaid",
   "patient_id": 644204092
 },
 {
   "policy_number": 426856,
   "phone_number": 9228642559,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Partial",
   "patient_id": 927165195
 },
 {
   "policy_number": 881854,
   "phone_number": 4465668826,
   "insurance_provider": "Cigna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 418668646
 },
 {
   "policy_number": 303124,
   "phone_number": 7841283028,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 400366873
 },
 {
   "policy_number": 520856,
   "phone_number": 8295299940,
   "insurance_provider": "Aetna",
   "billing_amount": "Krona",
   "payment_status": "Unpaid",
   "patient_id": 604383105
 },
 {
   "policy_number": 471674,
   "phone_number": 6664626066,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Rupiah",
   "payment_status": "Partial",
   "patient_id": 786646728
 },
 {
   "policy_number": 443453,
   "phone_number": 3258687239,
   "insurance_provider": "Aetna",
   "billing_amount": "Hryvnia",
   "payment_status": "Partial",
   "patient_id": 747988027
 },
 {
   "policy_number": 570352,
   "phone_number": 1393581859,
   "insurance_provider": "Aetna",
   "billing_amount": "Sol",
   "payment_status": "Unpaid",
   "patient_id": 515946802
 },
 {
   "policy_number": 111389,
   "phone_number": 5304408626,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 421660732
 },
 {
   "policy_number": 404812,
   "phone_number": 7115065791,
   "insurance_provider": "Aetna",
   "billing_amount": "Afghani",
   "payment_status": "Paid",
   "patient_id": 123224346
 },
 {
   "policy_number": 967078,
   "phone_number": 9907732924,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 298641329
 },
 {
   "policy_number": 740685,
   "phone_number": 6705551614,
   "insurance_provider": "Cigna",
   "billing_amount": "Rupee",
   "payment_status": "Unpaid",
   "patient_id": 544608506
 },
 {
   "policy_number": 931568,
   "phone_number": 2273380439,
   "insurance_provider": "Aetna",
   "billing_amount": "Bolivar",
   "payment_status": "Partial",
   "patient_id": 305845556
 },
 {
   "policy_number": 797468,
   "phone_number": 5145754996,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 635180616
 },
 {
   "policy_number": 921843,
   "phone_number": 4091276038,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 254289496
 },
 {
   "policy_number": 574800,
   "phone_number": 3702739506,
   "insurance_provider": "Cigna",
   "billing_amount": "Ruble",
   "payment_status": "Partial",
   "patient_id": 744132499
 },
 {
   "policy_number": 869078,
   "phone_number": 8527016179,
   "insurance_provider": "Cigna",
   "billing_amount": "Ariary",
   "payment_status": "Unpaid",
   "patient_id": 838486941
 },
 {
   "policy_number": 699394,
   "phone_number": 8395027923,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ruble",
   "payment_status": "Paid",
   "patient_id": 14003406
 },
 {
   "policy_number": 176497,
   "phone_number": 7127743482,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Paid",
   "patient_id": 2232128
 },
 {
   "policy_number": 147847,
   "phone_number": 4839867612,
   "insurance_provider": "Aetna",
   "billing_amount": "Dinar",
   "payment_status": "Partial",
   "patient_id": 937385430
 },
 {
   "policy_number": 264307,
   "phone_number": 3974621810,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Kyat",
   "payment_status": "Unpaid",
   "patient_id": 568706422
 },
 {
   "policy_number": 306537,
   "phone_number": 7796686103,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Ringgit",
   "payment_status": "Partial",
   "patient_id": 872187881
 },
 {
   "policy_number": 873777,
   "phone_number": 3417134920,
   "insurance_provider": "Aetna",
   "billing_amount": "Yen",
   "payment_status": "Paid",
   "patient_id": 216523313
 },
 {
   "policy_number": 405773,
   "phone_number": 6348534797,
   "insurance_provider": "Aetna",
   "billing_amount": "Lek",
   "payment_status": "Unpaid",
   "patient_id": 84624609
 },
 {
   "policy_number": 228160,
   "phone_number": 5815522390,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Naira",
   "payment_status": "Unpaid",
   "patient_id": 335106388
 },
 {
   "policy_number": 195327,
   "phone_number": 7791118749,
   "insurance_provider": "Aetna",
   "billing_amount": "Peso",
   "payment_status": "Paid",
   "patient_id": 878716595
 },
 {
   "policy_number": 352485,
   "phone_number": 9076760876,
   "insurance_provider": "Aetna",
   "billing_amount": "Euro",
   "payment_status": "Paid",
   "patient_id": 666832461
 },
 {
   "policy_number": 175205,
   "phone_number": 5959420897,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Peso",
   "payment_status": "Partial",
   "patient_id": 710642619
 },
 {
   "policy_number": 903517,
   "phone_number": 5186402775,
   "insurance_provider": "Cigna",
   "billing_amount": "Krona",
   "payment_status": "Paid",
   "patient_id": 831776062
 },
 {
   "policy_number": 174282,
   "phone_number": 2852435710,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 786222900
 },
 {
   "policy_number": 712981,
   "phone_number": 2818316418,
   "insurance_provider": "Cigna",
   "billing_amount": "Euro",
   "payment_status": "Unpaid",
   "patient_id": 515400834
 },
 {
   "policy_number": 613771,
   "phone_number": 5317806181,
   "insurance_provider": "Cigna",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Partial",
   "patient_id": 952690846
 },
 {
   "policy_number": 112423,
   "phone_number": 8608843024,
   "insurance_provider": "Cigna",
   "billing_amount": "Dong",
   "payment_status": "Partial",
   "patient_id": 841533027
 },
 {
   "policy_number": 806371,
   "phone_number": 7868760081,
   "insurance_provider": "Blue Cross Blue Shield",
   "billing_amount": "Yuan Renminbi",
   "payment_status": "Unpaid",
   "patient_id": 654504908
 }
]);

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for insertion: " + timeTaken + " milliseconds");