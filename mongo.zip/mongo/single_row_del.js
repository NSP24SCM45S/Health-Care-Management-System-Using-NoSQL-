
var startTime = new Date();

var deletionCondition = { prescription_id:380802288 };
db.Prescription.deleteOne(deletionCondition);

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for single record deletion: " + timeTaken + " milliseconds");