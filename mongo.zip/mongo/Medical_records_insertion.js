// Record the start time
var startTime = new Date();

// Your insertion operation with the current date as admissionDate
db.Medical_records.insertMany([
 {
   "diagnosis": "S42256P",
   "record_date": "2014-02-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b6e8",
   "patient_id": 619486079,
   "doctor_id": 11302
 },
 {
   "diagnosis": "M4693",
   "record_date": "2007-02-15",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6e9",
   "patient_id": 892708688,
   "doctor_id": 11303
 },
 {
   "diagnosis": "V104XXS",
   "record_date": "2021-07-01",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6ea",
   "patient_id": 22195242,
   "doctor_id": 11304
 },
 {
   "diagnosis": "S75029",
   "record_date": "2000-09-16",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6eb",
   "patient_id": 668808523,
   "doctor_id": 11305
 },
 {
   "diagnosis": "S89301A",
   "record_date": "2020-05-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6ec",
   "patient_id": 467612663,
   "doctor_id": 11306
 },
 {
   "diagnosis": "S82464S",
   "record_date": "2003-06-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6ed",
   "patient_id": 61715603,
   "doctor_id": 11307
 },
 {
   "diagnosis": "Y386X1",
   "record_date": "2021-04-08",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b6ee",
   "patient_id": 412618858,
   "doctor_id": 11308
 },
 {
   "diagnosis": "H15831",
   "record_date": "2004-08-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b6ef",
   "patient_id": 947226484,
   "doctor_id": 11309
 },
 {
   "diagnosis": "S82235Q",
   "record_date": "2006-03-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b6f0",
   "patient_id": 801335117,
   "doctor_id": 11310
 },
 {
   "diagnosis": "S93514D",
   "record_date": "2020-10-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b6f1",
   "patient_id": 737229538,
   "doctor_id": 11311
 },
 {
   "diagnosis": "S63142",
   "record_date": "2021-03-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6f2",
   "patient_id": 636959196,
   "doctor_id": 11312
 },
 {
   "diagnosis": "V171XXD",
   "record_date": "2015-10-15",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6f3",
   "patient_id": 299616270,
   "doctor_id": 11313
 },
 {
   "diagnosis": "H16039",
   "record_date": "2007-01-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b6f4",
   "patient_id": 998132204,
   "doctor_id": 11314
 },
 {
   "diagnosis": "V031",
   "record_date": "2019-08-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6f5",
   "patient_id": 676991253,
   "doctor_id": 11315
 },
 {
   "diagnosis": "M26211",
   "record_date": "2000-08-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6f6",
   "patient_id": 535659829,
   "doctor_id": 11316
 },
 {
   "diagnosis": "T2123XS",
   "record_date": "2001-01-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6f7",
   "patient_id": 997566304,
   "doctor_id": 11317
 },
 {
   "diagnosis": "S93312D",
   "record_date": "2011-11-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b6f8",
   "patient_id": 518353983,
   "doctor_id": 11318
 },
 {
   "diagnosis": "M364",
   "record_date": "2022-09-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6f9",
   "patient_id": 973884491,
   "doctor_id": 11319
 },
 {
   "diagnosis": "Y35011",
   "record_date": "2010-09-12",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6fa",
   "patient_id": 19218704,
   "doctor_id": 11320
 },
 {
   "diagnosis": "S56591",
   "record_date": "2008-06-20",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b6fb",
   "patient_id": 270549175,
   "doctor_id": 11321
 },
 {
   "diagnosis": "S21422S",
   "record_date": "2020-12-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b6fc",
   "patient_id": 209923864,
   "doctor_id": 11322
 },
 {
   "diagnosis": "S72432D",
   "record_date": "2022-01-29",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b6fd",
   "patient_id": 137555123,
   "doctor_id": 11323
 },
 {
   "diagnosis": "S42326D",
   "record_date": "2003-03-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b6fe",
   "patient_id": 140977191,
   "doctor_id": 11324
 },
 {
   "diagnosis": "O334XX9",
   "record_date": "2020-10-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b6ff",
   "patient_id": 636359507,
   "doctor_id": 11325
 },
 {
   "diagnosis": "H5319",
   "record_date": "2000-02-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b700",
   "patient_id": 70148713,
   "doctor_id": 11326
 },
 {
   "diagnosis": "S56411",
   "record_date": "2006-11-26",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b701",
   "patient_id": 383354783,
   "doctor_id": 11327
 },
 {
   "diagnosis": "V9213",
   "record_date": "2005-04-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b702",
   "patient_id": 704120718,
   "doctor_id": 11328
 },
 {
   "diagnosis": "S99102B",
   "record_date": "2006-11-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b703",
   "patient_id": 268909923,
   "doctor_id": 11329
 },
 {
   "diagnosis": "T63462S",
   "record_date": "2001-02-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b704",
   "patient_id": 451085417,
   "doctor_id": 11330
 },
 {
   "diagnosis": "M101",
   "record_date": "2005-12-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b705",
   "patient_id": 175968229,
   "doctor_id": 11331
 },
 {
   "diagnosis": "S71011",
   "record_date": "2002-08-22",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b706",
   "patient_id": 610584136,
   "doctor_id": 11332
 },
 {
   "diagnosis": "C838",
   "record_date": "2005-03-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b707",
   "patient_id": 561344897,
   "doctor_id": 11333
 },
 {
   "diagnosis": "T650X2",
   "record_date": "2007-01-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b708",
   "patient_id": 998726632,
   "doctor_id": 11334
 },
 {
   "diagnosis": "J962",
   "record_date": "2013-04-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b709",
   "patient_id": 337089339,
   "doctor_id": 11335
 },
 {
   "diagnosis": "V0400XA",
   "record_date": "2019-02-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b70a",
   "patient_id": 706231568,
   "doctor_id": 11336
 },
 {
   "diagnosis": "S52236H",
   "record_date": "2008-07-13",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b70b",
   "patient_id": 918665870,
   "doctor_id": 11337
 },
 {
   "diagnosis": "S43036D",
   "record_date": "2011-11-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b70c",
   "patient_id": 705611321,
   "doctor_id": 11338
 },
 {
   "diagnosis": "C34",
   "record_date": "2001-11-27",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b70d",
   "patient_id": 270932787,
   "doctor_id": 11339
 },
 {
   "diagnosis": "V665XXA",
   "record_date": "2001-09-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b70e",
   "patient_id": 223978219,
   "doctor_id": 11340
 },
 {
   "diagnosis": "S70269S",
   "record_date": "2000-06-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b70f",
   "patient_id": 149248170,
   "doctor_id": 11341
 },
 {
   "diagnosis": "S73025",
   "record_date": "2018-04-16",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b710",
   "patient_id": 265070821,
   "doctor_id": 11342
 },
 {
   "diagnosis": "S06368S",
   "record_date": "2007-11-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b711",
   "patient_id": 545441107,
   "doctor_id": 11343
 },
 {
   "diagnosis": "N319",
   "record_date": "2021-09-06",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b712",
   "patient_id": 485141889,
   "doctor_id": 11344
 },
 {
   "diagnosis": "T81598",
   "record_date": "2002-03-27",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b713",
   "patient_id": 763165452,
   "doctor_id": 11345
 },
 {
   "diagnosis": "C44229",
   "record_date": "2022-07-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b714",
   "patient_id": 685725493,
   "doctor_id": 11346
 },
 {
   "diagnosis": "S01319S",
   "record_date": "2004-06-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b715",
   "patient_id": 182844664,
   "doctor_id": 11347
 },
 {
   "diagnosis": "M8438XD",
   "record_date": "2003-10-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b716",
   "patient_id": 916677356,
   "doctor_id": 11348
 },
 {
   "diagnosis": "Q302",
   "record_date": "2008-06-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b717",
   "patient_id": 357367853,
   "doctor_id": 11349
 },
 {
   "diagnosis": "M1A139",
   "record_date": "2013-08-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b718",
   "patient_id": 622392191,
   "doctor_id": 11350
 },
 {
   "diagnosis": "S73102A",
   "record_date": "2015-03-09",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b719",
   "patient_id": 43273828,
   "doctor_id": 11351
 },
 {
   "diagnosis": "S72336M",
   "record_date": "2015-04-18",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b71a",
   "patient_id": 86155929,
   "doctor_id": 11352
 },
 {
   "diagnosis": "S6032",
   "record_date": "2009-03-09",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b71b",
   "patient_id": 507055576,
   "doctor_id": 11353
 },
 {
   "diagnosis": "H0234",
   "record_date": "2006-06-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b71c",
   "patient_id": 307893801,
   "doctor_id": 11354
 },
 {
   "diagnosis": "M18",
   "record_date": "2015-04-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b71d",
   "patient_id": 663957156,
   "doctor_id": 11355
 },
 {
   "diagnosis": "S75119S",
   "record_date": "2001-02-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b71e",
   "patient_id": 714333176,
   "doctor_id": 11356
 },
 {
   "diagnosis": "T24732S",
   "record_date": "2006-09-15",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b71f",
   "patient_id": 400106479,
   "doctor_id": 11357
 },
 {
   "diagnosis": "O879",
   "record_date": "2022-06-22",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b720",
   "patient_id": 995096308,
   "doctor_id": 11358
 },
 {
   "diagnosis": "J955",
   "record_date": "2021-12-30",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b721",
   "patient_id": 798502775,
   "doctor_id": 11359
 },
 {
   "diagnosis": "S63245S",
   "record_date": "2002-04-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b722",
   "patient_id": 419853502,
   "doctor_id": 11360
 },
 {
   "diagnosis": "S79922D",
   "record_date": "2010-01-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b723",
   "patient_id": 451414638,
   "doctor_id": 11361
 },
 {
   "diagnosis": "M86271",
   "record_date": "2003-11-28",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b724",
   "patient_id": 568952270,
   "doctor_id": 11362
 },
 {
   "diagnosis": "Q796",
   "record_date": "2007-10-14",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b725",
   "patient_id": 493466447,
   "doctor_id": 11363
 },
 {
   "diagnosis": "S5321",
   "record_date": "2020-01-12",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b726",
   "patient_id": 141915822,
   "doctor_id": 11364
 },
 {
   "diagnosis": "C099",
   "record_date": "2011-04-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b727",
   "patient_id": 244505818,
   "doctor_id": 11365
 },
 {
   "diagnosis": "M4135",
   "record_date": "2015-08-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b728",
   "patient_id": 497746884,
   "doctor_id": 11366
 },
 {
   "diagnosis": "M24369",
   "record_date": "2017-06-22",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b729",
   "patient_id": 602220202,
   "doctor_id": 11367
 },
 {
   "diagnosis": "T23769",
   "record_date": "2015-07-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b72a",
   "patient_id": 428589723,
   "doctor_id": 11368
 },
 {
   "diagnosis": "S43036S",
   "record_date": "2022-12-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b72b",
   "patient_id": 281852462,
   "doctor_id": 11369
 },
 {
   "diagnosis": "S92341B",
   "record_date": "2012-12-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b72c",
   "patient_id": 819361042,
   "doctor_id": 11370
 },
 {
   "diagnosis": "I80203",
   "record_date": "2004-05-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b72d",
   "patient_id": 893389209,
   "doctor_id": 11371
 },
 {
   "diagnosis": "E7202",
   "record_date": "2012-10-23",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b72e",
   "patient_id": 84494254,
   "doctor_id": 11372
 },
 {
   "diagnosis": "S14153",
   "record_date": "2009-02-10",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b72f",
   "patient_id": 533454936,
   "doctor_id": 11373
 },
 {
   "diagnosis": "H02126",
   "record_date": "2014-04-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b730",
   "patient_id": 819542153,
   "doctor_id": 11374
 },
 {
   "diagnosis": "S45192D",
   "record_date": "2015-01-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b731",
   "patient_id": 428101685,
   "doctor_id": 11375
 },
 {
   "diagnosis": "W100XXA",
   "record_date": "2012-08-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b732",
   "patient_id": 237724864,
   "doctor_id": 11376
 },
 {
   "diagnosis": "M8000XD",
   "record_date": "2001-01-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b733",
   "patient_id": 807574651,
   "doctor_id": 11377
 },
 {
   "diagnosis": "S52246D",
   "record_date": "2011-02-01",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b734",
   "patient_id": 356217138,
   "doctor_id": 11378
 },
 {
   "diagnosis": "H11001",
   "record_date": "2010-11-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b735",
   "patient_id": 264503896,
   "doctor_id": 11379
 },
 {
   "diagnosis": "D891",
   "record_date": "2010-01-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b736",
   "patient_id": 332749365,
   "doctor_id": 11380
 },
 {
   "diagnosis": "M9909",
   "record_date": "2016-06-22",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b737",
   "patient_id": 110885783,
   "doctor_id": 11381
 },
 {
   "diagnosis": "Z45010",
   "record_date": "2003-09-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b738",
   "patient_id": 435852138,
   "doctor_id": 11382
 },
 {
   "diagnosis": "D447",
   "record_date": "2004-06-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b739",
   "patient_id": 23289163,
   "doctor_id": 11383
 },
 {
   "diagnosis": "S8251XH",
   "record_date": "2019-01-28",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b73a",
   "patient_id": 210758845,
   "doctor_id": 11384
 },
 {
   "diagnosis": "T572X2",
   "record_date": "2009-02-22",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b73b",
   "patient_id": 420377926,
   "doctor_id": 11385
 },
 {
   "diagnosis": "S79129P",
   "record_date": "2009-06-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b73c",
   "patient_id": 71883115,
   "doctor_id": 11386
 },
 {
   "diagnosis": "M21062",
   "record_date": "2016-09-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b73d",
   "patient_id": 519021437,
   "doctor_id": 11387
 },
 {
   "diagnosis": "M61261",
   "record_date": "2013-04-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b73e",
   "patient_id": 819499806,
   "doctor_id": 11388
 },
 {
   "diagnosis": "S65909S",
   "record_date": "2018-12-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b73f",
   "patient_id": 357174398,
   "doctor_id": 11389
 },
 {
   "diagnosis": "S93522D",
   "record_date": "2016-07-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b740",
   "patient_id": 118718403,
   "doctor_id": 11390
 },
 {
   "diagnosis": "I6031",
   "record_date": "2016-01-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b741",
   "patient_id": 682730119,
   "doctor_id": 11391
 },
 {
   "diagnosis": "E103313",
   "record_date": "2005-06-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b742",
   "patient_id": 779692843,
   "doctor_id": 11392
 },
 {
   "diagnosis": "T2113XA",
   "record_date": "2008-03-30",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b743",
   "patient_id": 966561466,
   "doctor_id": 11393
 },
 {
   "diagnosis": "S63225S",
   "record_date": "2000-01-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b744",
   "patient_id": 428639568,
   "doctor_id": 11394
 },
 {
   "diagnosis": "S63075",
   "record_date": "2004-06-26",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b745",
   "patient_id": 872993792,
   "doctor_id": 11395
 },
 {
   "diagnosis": "G937",
   "record_date": "2002-07-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b746",
   "patient_id": 211820509,
   "doctor_id": 11396
 },
 {
   "diagnosis": "T431X3",
   "record_date": "2021-09-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b747",
   "patient_id": 973051723,
   "doctor_id": 11397
 },
 {
   "diagnosis": "V9014XD",
   "record_date": "2011-05-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b748",
   "patient_id": 402541488,
   "doctor_id": 11398
 },
 {
   "diagnosis": "S32462",
   "record_date": "2001-11-26",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b749",
   "patient_id": 812263271,
   "doctor_id": 11399
 },
 {
   "diagnosis": "S99202",
   "record_date": "2016-12-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b74a",
   "patient_id": 486519720,
   "doctor_id": 11400
 },
 {
   "diagnosis": "K50011",
   "record_date": "2012-04-05",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b74b",
   "patient_id": 263114127,
   "doctor_id": 11401
 },
 {
   "diagnosis": "S92209P",
   "record_date": "2003-08-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b74c",
   "patient_id": 363429428,
   "doctor_id": 11402
 },
 {
   "diagnosis": "M84454K",
   "record_date": "2006-03-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b74d",
   "patient_id": 980267652,
   "doctor_id": 11403
 },
 {
   "diagnosis": "S52262J",
   "record_date": "2011-03-23",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b74e",
   "patient_id": 625704501,
   "doctor_id": 11404
 },
 {
   "diagnosis": "H02124",
   "record_date": "2011-09-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b74f",
   "patient_id": 27052530,
   "doctor_id": 11405
 },
 {
   "diagnosis": "I7035",
   "record_date": "2021-05-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b750",
   "patient_id": 580152369,
   "doctor_id": 11406
 },
 {
   "diagnosis": "S50359S",
   "record_date": "2000-03-25",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b751",
   "patient_id": 665158476,
   "doctor_id": 11407
 },
 {
   "diagnosis": "S9001XD",
   "record_date": "2017-11-18",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b752",
   "patient_id": 868965426,
   "doctor_id": 11408
 },
 {
   "diagnosis": "S66198S",
   "record_date": "2017-08-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b753",
   "patient_id": 170168746,
   "doctor_id": 11409
 },
 {
   "diagnosis": "S82436M",
   "record_date": "2017-11-18",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b754",
   "patient_id": 850786317,
   "doctor_id": 11410
 },
 {
   "diagnosis": "K08131",
   "record_date": "2018-02-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b755",
   "patient_id": 986935235,
   "doctor_id": 11411
 },
 {
   "diagnosis": "S72302Q",
   "record_date": "2011-12-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b756",
   "patient_id": 330037848,
   "doctor_id": 11412
 },
 {
   "diagnosis": "P031",
   "record_date": "2001-10-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b757",
   "patient_id": 863907370,
   "doctor_id": 11413
 },
 {
   "diagnosis": "T85828A",
   "record_date": "2002-12-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b758",
   "patient_id": 637676207,
   "doctor_id": 11414
 },
 {
   "diagnosis": "I82499",
   "record_date": "2011-09-09",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b759",
   "patient_id": 355755490,
   "doctor_id": 11415
 },
 {
   "diagnosis": "S76199",
   "record_date": "2002-06-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b75a",
   "patient_id": 758980115,
   "doctor_id": 11416
 },
 {
   "diagnosis": "J84111",
   "record_date": "2002-05-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b75b",
   "patient_id": 927568245,
   "doctor_id": 11417
 },
 {
   "diagnosis": "T2367",
   "record_date": "2001-03-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b75c",
   "patient_id": 556553122,
   "doctor_id": 11418
 },
 {
   "diagnosis": "S23171",
   "record_date": "2012-03-29",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b75d",
   "patient_id": 265104769,
   "doctor_id": 11419
 },
 {
   "diagnosis": "T84223A",
   "record_date": "2018-12-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b75e",
   "patient_id": 495145350,
   "doctor_id": 11420
 },
 {
   "diagnosis": "H44532",
   "record_date": "2018-09-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b75f",
   "patient_id": 542987340,
   "doctor_id": 11421
 },
 {
   "diagnosis": "T85620A",
   "record_date": "2001-09-18",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b760",
   "patient_id": 343416509,
   "doctor_id": 11422
 },
 {
   "diagnosis": "Z78",
   "record_date": "2019-04-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b761",
   "patient_id": 879419974,
   "doctor_id": 11423
 },
 {
   "diagnosis": "T40993D",
   "record_date": "2017-03-11",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b762",
   "patient_id": 465471842,
   "doctor_id": 11424
 },
 {
   "diagnosis": "S14134D",
   "record_date": "2003-09-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b763",
   "patient_id": 394561574,
   "doctor_id": 11425
 },
 {
   "diagnosis": "S72146J",
   "record_date": "2013-10-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b764",
   "patient_id": 678980314,
   "doctor_id": 11426
 },
 {
   "diagnosis": "T23069",
   "record_date": "2019-07-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b765",
   "patient_id": 628975390,
   "doctor_id": 11427
 },
 {
   "diagnosis": "S62658S",
   "record_date": "2019-02-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b766",
   "patient_id": 786632343,
   "doctor_id": 11428
 },
 {
   "diagnosis": "I702",
   "record_date": "2014-11-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b767",
   "patient_id": 780389679,
   "doctor_id": 11429
 },
 {
   "diagnosis": "Y37130A",
   "record_date": "2002-10-01",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b768",
   "patient_id": 894988093,
   "doctor_id": 11430
 },
 {
   "diagnosis": "S15029A",
   "record_date": "2018-11-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b769",
   "patient_id": 85912857,
   "doctor_id": 11431
 },
 {
   "diagnosis": "S52549R",
   "record_date": "2019-12-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b76a",
   "patient_id": 464105653,
   "doctor_id": 11432
 },
 {
   "diagnosis": "V0299XD",
   "record_date": "2005-05-06",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b76b",
   "patient_id": 501240471,
   "doctor_id": 11433
 },
 {
   "diagnosis": "T506X4",
   "record_date": "2003-03-20",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b76c",
   "patient_id": 736976614,
   "doctor_id": 11434
 },
 {
   "diagnosis": "S52622G",
   "record_date": "2002-09-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b76d",
   "patient_id": 189195112,
   "doctor_id": 11435
 },
 {
   "diagnosis": "T507X3A",
   "record_date": "2005-12-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b76e",
   "patient_id": 970400818,
   "doctor_id": 11436
 },
 {
   "diagnosis": "V1919",
   "record_date": "2003-11-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b76f",
   "patient_id": 328916208,
   "doctor_id": 11437
 },
 {
   "diagnosis": "S91144A",
   "record_date": "2010-12-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b770",
   "patient_id": 725137844,
   "doctor_id": 11438
 },
 {
   "diagnosis": "S86922A",
   "record_date": "2008-09-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b771",
   "patient_id": 878816364,
   "doctor_id": 11439
 },
 {
   "diagnosis": "S82409Q",
   "record_date": "2013-08-22",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b772",
   "patient_id": 645873334,
   "doctor_id": 11440
 },
 {
   "diagnosis": "R29701",
   "record_date": "2002-04-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b773",
   "patient_id": 647910025,
   "doctor_id": 11441
 },
 {
   "diagnosis": "T83724D",
   "record_date": "2019-07-22",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b774",
   "patient_id": 807001272,
   "doctor_id": 11442
 },
 {
   "diagnosis": "W6109XA",
   "record_date": "2000-07-02",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b775",
   "patient_id": 345537363,
   "doctor_id": 11443
 },
 {
   "diagnosis": "T454X3A",
   "record_date": "2012-07-06",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b776",
   "patient_id": 972176057,
   "doctor_id": 11444
 },
 {
   "diagnosis": "S0230XK",
   "record_date": "2019-07-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b777",
   "patient_id": 923473238,
   "doctor_id": 11445
 },
 {
   "diagnosis": "S62654P",
   "record_date": "2006-06-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b778",
   "patient_id": 923137516,
   "doctor_id": 11446
 },
 {
   "diagnosis": "T23539A",
   "record_date": "2008-08-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b779",
   "patient_id": 297181670,
   "doctor_id": 11447
 },
 {
   "diagnosis": "S50851A",
   "record_date": "2014-09-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b77a",
   "patient_id": 830274531,
   "doctor_id": 11448
 },
 {
   "diagnosis": "C44722",
   "record_date": "2016-10-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b77b",
   "patient_id": 967019844,
   "doctor_id": 11449
 },
 {
   "diagnosis": "S6539",
   "record_date": "2011-11-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b77c",
   "patient_id": 454949492,
   "doctor_id": 11450
 },
 {
   "diagnosis": "B42",
   "record_date": "2017-09-15",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b77d",
   "patient_id": 317356374,
   "doctor_id": 11451
 },
 {
   "diagnosis": "M9941",
   "record_date": "2012-07-30",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b77e",
   "patient_id": 98693118,
   "doctor_id": 11452
 },
 {
   "diagnosis": "S85169D",
   "record_date": "2021-12-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b77f",
   "patient_id": 859007943,
   "doctor_id": 11453
 },
 {
   "diagnosis": "S52101C",
   "record_date": "2003-11-27",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b780",
   "patient_id": 936928571,
   "doctor_id": 11454
 },
 {
   "diagnosis": "S22018B",
   "record_date": "2011-04-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b781",
   "patient_id": 205802252,
   "doctor_id": 11455
 },
 {
   "diagnosis": "S92045A",
   "record_date": "2002-06-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b782",
   "patient_id": 491186752,
   "doctor_id": 11456
 },
 {
   "diagnosis": "S81041S",
   "record_date": "2022-04-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b783",
   "patient_id": 223671959,
   "doctor_id": 11457
 },
 {
   "diagnosis": "S83012A",
   "record_date": "2017-12-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b784",
   "patient_id": 574472765,
   "doctor_id": 11458
 },
 {
   "diagnosis": "S52133R",
   "record_date": "2012-10-18",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b785",
   "patient_id": 952307752,
   "doctor_id": 11459
 },
 {
   "diagnosis": "S22050B",
   "record_date": "2002-09-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b786",
   "patient_id": 147194170,
   "doctor_id": 11460
 },
 {
   "diagnosis": "O401XX1",
   "record_date": "2021-09-02",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b787",
   "patient_id": 854815299,
   "doctor_id": 11461
 },
 {
   "diagnosis": "T84010A",
   "record_date": "2011-08-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b788",
   "patient_id": 440602340,
   "doctor_id": 11462
 },
 {
   "diagnosis": "T45611S",
   "record_date": "2004-06-06",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b789",
   "patient_id": 442514024,
   "doctor_id": 11463
 },
 {
   "diagnosis": "F1215",
   "record_date": "2008-11-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b78a",
   "patient_id": 367039032,
   "doctor_id": 11464
 },
 {
   "diagnosis": "T385X6S",
   "record_date": "2004-10-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b78b",
   "patient_id": 221469783,
   "doctor_id": 11465
 },
 {
   "diagnosis": "S5432",
   "record_date": "2006-04-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b78c",
   "patient_id": 984167189,
   "doctor_id": 11466
 },
 {
   "diagnosis": "S65191D",
   "record_date": "2015-09-20",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b78d",
   "patient_id": 787798578,
   "doctor_id": 11467
 },
 {
   "diagnosis": "S95009",
   "record_date": "2012-07-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b78e",
   "patient_id": 142845775,
   "doctor_id": 11468
 },
 {
   "diagnosis": "T452X3",
   "record_date": "2021-12-06",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b78f",
   "patient_id": 821563403,
   "doctor_id": 11469
 },
 {
   "diagnosis": "T43694D",
   "record_date": "2016-02-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b790",
   "patient_id": 113428938,
   "doctor_id": 11470
 },
 {
   "diagnosis": "S11",
   "record_date": "2006-07-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b791",
   "patient_id": 278052903,
   "doctor_id": 11471
 },
 {
   "diagnosis": "S92325B",
   "record_date": "2006-07-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b792",
   "patient_id": 27219464,
   "doctor_id": 11472
 },
 {
   "diagnosis": "D55",
   "record_date": "2016-03-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b793",
   "patient_id": 629539270,
   "doctor_id": 11473
 },
 {
   "diagnosis": "Z91041",
   "record_date": "2006-11-28",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b794",
   "patient_id": 522766694,
   "doctor_id": 11474
 },
 {
   "diagnosis": "S93334",
   "record_date": "2020-01-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b795",
   "patient_id": 704278225,
   "doctor_id": 11475
 },
 {
   "diagnosis": "R47",
   "record_date": "2012-05-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b796",
   "patient_id": 809434019,
   "doctor_id": 11476
 },
 {
   "diagnosis": "S65311",
   "record_date": "2020-07-30",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b797",
   "patient_id": 285355146,
   "doctor_id": 11477
 },
 {
   "diagnosis": "Z903",
   "record_date": "2015-06-07",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b798",
   "patient_id": 448795592,
   "doctor_id": 11478
 },
 {
   "diagnosis": "T540X1A",
   "record_date": "2019-02-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b799",
   "patient_id": 330412646,
   "doctor_id": 11479
 },
 {
   "diagnosis": "O103",
   "record_date": "2021-04-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b79a",
   "patient_id": 936759440,
   "doctor_id": 11480
 },
 {
   "diagnosis": "S49112P",
   "record_date": "2013-01-31",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b79b",
   "patient_id": 617333642,
   "doctor_id": 11481
 },
 {
   "diagnosis": "S43083A",
   "record_date": "2022-12-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b79c",
   "patient_id": 149020403,
   "doctor_id": 11482
 },
 {
   "diagnosis": "H11143",
   "record_date": "2009-07-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b79d",
   "patient_id": 589910221,
   "doctor_id": 11483
 },
 {
   "diagnosis": "T461X4A",
   "record_date": "2021-11-06",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b79e",
   "patient_id": 518193599,
   "doctor_id": 11484
 },
 {
   "diagnosis": "S0003XS",
   "record_date": "2019-03-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b79f",
   "patient_id": 242159553,
   "doctor_id": 11485
 },
 {
   "diagnosis": "S82202C",
   "record_date": "2002-06-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7a0",
   "patient_id": 134715238,
   "doctor_id": 11486
 },
 {
   "diagnosis": "S13141S",
   "record_date": "2010-09-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7a1",
   "patient_id": 715650420,
   "doctor_id": 11487
 },
 {
   "diagnosis": "V405XXA",
   "record_date": "2014-09-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7a2",
   "patient_id": 914591828,
   "doctor_id": 11488
 },
 {
   "diagnosis": "S65209",
   "record_date": "2008-04-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7a3",
   "patient_id": 972153413,
   "doctor_id": 11489
 },
 {
   "diagnosis": "K264",
   "record_date": "2019-12-09",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7a4",
   "patient_id": 125269602,
   "doctor_id": 11490
 },
 {
   "diagnosis": "M84574D",
   "record_date": "2000-04-17",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7a5",
   "patient_id": 719924698,
   "doctor_id": 11491
 },
 {
   "diagnosis": "D0370",
   "record_date": "2015-09-09",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7a6",
   "patient_id": 886564882,
   "doctor_id": 11492
 },
 {
   "diagnosis": "O104",
   "record_date": "2006-03-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7a7",
   "patient_id": 91001578,
   "doctor_id": 11493
 },
 {
   "diagnosis": "S123",
   "record_date": "2019-01-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7a8",
   "patient_id": 772603404,
   "doctor_id": 11494
 },
 {
   "diagnosis": "T22212",
   "record_date": "2017-11-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7a9",
   "patient_id": 877066317,
   "doctor_id": 11495
 },
 {
   "diagnosis": "S92102",
   "record_date": "2002-10-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7aa",
   "patient_id": 898517197,
   "doctor_id": 11496
 },
 {
   "diagnosis": "O30092",
   "record_date": "2014-09-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7ab",
   "patient_id": 753891596,
   "doctor_id": 11497
 },
 {
   "diagnosis": "S06338S",
   "record_date": "2013-05-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7ac",
   "patient_id": 62856092,
   "doctor_id": 11498
 },
 {
   "diagnosis": "S3984",
   "record_date": "2018-12-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7ad",
   "patient_id": 986432212,
   "doctor_id": 11499
 },
 {
   "diagnosis": "S12091D",
   "record_date": "2012-12-06",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7ae",
   "patient_id": 525470834,
   "doctor_id": 11500
 },
 {
   "diagnosis": "S0180XD",
   "record_date": "2001-11-06",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7af",
   "patient_id": 700240328,
   "doctor_id": 11501
 },
 {
   "diagnosis": "Z319",
   "record_date": "2014-05-23",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7b0",
   "patient_id": 320432402,
   "doctor_id": 11502
 },
 {
   "diagnosis": "S52399R",
   "record_date": "2011-04-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7b1",
   "patient_id": 837749245,
   "doctor_id": 11503
 },
 {
   "diagnosis": "H353212",
   "record_date": "2007-12-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7b2",
   "patient_id": 559388733,
   "doctor_id": 11504
 },
 {
   "diagnosis": "S66409D",
   "record_date": "2012-05-16",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7b3",
   "patient_id": 231392472,
   "doctor_id": 11505
 },
 {
   "diagnosis": "S22078K",
   "record_date": "2011-04-28",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7b4",
   "patient_id": 821884164,
   "doctor_id": 11506
 },
 {
   "diagnosis": "H20042",
   "record_date": "2019-04-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7b5",
   "patient_id": 264174687,
   "doctor_id": 11507
 },
 {
   "diagnosis": "D71",
   "record_date": "2013-07-22",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7b6",
   "patient_id": 84704238,
   "doctor_id": 11508
 },
 {
   "diagnosis": "M4696",
   "record_date": "2020-11-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7b7",
   "patient_id": 666716175,
   "doctor_id": 11509
 },
 {
   "diagnosis": "T3166",
   "record_date": "2017-12-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7b8",
   "patient_id": 779941389,
   "doctor_id": 11510
 },
 {
   "diagnosis": "Y385X2",
   "record_date": "2020-04-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7b9",
   "patient_id": 316875241,
   "doctor_id": 11511
 },
 {
   "diagnosis": "T83020S",
   "record_date": "2017-07-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7ba",
   "patient_id": 145036888,
   "doctor_id": 11512
 },
 {
   "diagnosis": "M89629",
   "record_date": "2017-07-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7bb",
   "patient_id": 86604517,
   "doctor_id": 11513
 },
 {
   "diagnosis": "Z713",
   "record_date": "2015-05-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7bc",
   "patient_id": 848344783,
   "doctor_id": 11514
 },
 {
   "diagnosis": "W16112",
   "record_date": "2013-09-26",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7bd",
   "patient_id": 565377768,
   "doctor_id": 11515
 },
 {
   "diagnosis": "S72415M",
   "record_date": "2018-07-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7be",
   "patient_id": 816548704,
   "doctor_id": 11516
 },
 {
   "diagnosis": "O6981X1",
   "record_date": "2011-11-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7bf",
   "patient_id": 227010807,
   "doctor_id": 11517
 },
 {
   "diagnosis": "T4144",
   "record_date": "2004-07-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7c0",
   "patient_id": 742041410,
   "doctor_id": 11518
 },
 {
   "diagnosis": "S80859S",
   "record_date": "2015-11-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7c1",
   "patient_id": 354636790,
   "doctor_id": 11519
 },
 {
   "diagnosis": "S82201K",
   "record_date": "2006-11-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7c2",
   "patient_id": 364779149,
   "doctor_id": 11520
 },
 {
   "diagnosis": "Y92215",
   "record_date": "2003-02-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7c3",
   "patient_id": 967051114,
   "doctor_id": 11521
 },
 {
   "diagnosis": "I63523",
   "record_date": "2013-06-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7c4",
   "patient_id": 739531310,
   "doctor_id": 11522
 },
 {
   "diagnosis": "S42456S",
   "record_date": "2014-06-17",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7c5",
   "patient_id": 231170029,
   "doctor_id": 11523
 },
 {
   "diagnosis": "S97109A",
   "record_date": "2020-01-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7c6",
   "patient_id": 415092686,
   "doctor_id": 11524
 },
 {
   "diagnosis": "Z01411",
   "record_date": "2013-02-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7c7",
   "patient_id": 685766483,
   "doctor_id": 11525
 },
 {
   "diagnosis": "X58",
   "record_date": "2016-06-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7c8",
   "patient_id": 892466058,
   "doctor_id": 11526
 },
 {
   "diagnosis": "V50",
   "record_date": "2005-03-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7c9",
   "patient_id": 667805562,
   "doctor_id": 11527
 },
 {
   "diagnosis": "S82144C",
   "record_date": "2009-06-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7ca",
   "patient_id": 345421752,
   "doctor_id": 11528
 },
 {
   "diagnosis": "P0503",
   "record_date": "2004-12-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7cb",
   "patient_id": 197677169,
   "doctor_id": 11529
 },
 {
   "diagnosis": "F06",
   "record_date": "2011-07-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7cc",
   "patient_id": 530103186,
   "doctor_id": 11530
 },
 {
   "diagnosis": "S42454",
   "record_date": "2012-06-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7cd",
   "patient_id": 844561658,
   "doctor_id": 11531
 },
 {
   "diagnosis": "S52236S",
   "record_date": "2019-09-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7ce",
   "patient_id": 316841341,
   "doctor_id": 11532
 },
 {
   "diagnosis": "T79A",
   "record_date": "2005-05-15",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7cf",
   "patient_id": 322114020,
   "doctor_id": 11533
 },
 {
   "diagnosis": "M12112",
   "record_date": "2020-01-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7d0",
   "patient_id": 631285783,
   "doctor_id": 11534
 },
 {
   "diagnosis": "S76091A",
   "record_date": "2014-08-31",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7d1",
   "patient_id": 747193545,
   "doctor_id": 11535
 },
 {
   "diagnosis": "V479XXA",
   "record_date": "2008-03-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7d2",
   "patient_id": 857842158,
   "doctor_id": 11536
 },
 {
   "diagnosis": "S82112G",
   "record_date": "2008-07-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7d3",
   "patient_id": 847421326,
   "doctor_id": 11537
 },
 {
   "diagnosis": "V449XXS",
   "record_date": "2006-11-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7d4",
   "patient_id": 422046345,
   "doctor_id": 11538
 },
 {
   "diagnosis": "S66522D",
   "record_date": "2005-12-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7d5",
   "patient_id": 62674061,
   "doctor_id": 11539
 },
 {
   "diagnosis": "S65211S",
   "record_date": "2022-07-21",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7d6",
   "patient_id": 601918930,
   "doctor_id": 11540
 },
 {
   "diagnosis": "Y903",
   "record_date": "2014-01-16",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7d7",
   "patient_id": 173607718,
   "doctor_id": 11541
 },
 {
   "diagnosis": "S48922",
   "record_date": "2013-02-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7d8",
   "patient_id": 785973041,
   "doctor_id": 11542
 },
 {
   "diagnosis": "T391X2D",
   "record_date": "2010-11-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7d9",
   "patient_id": 291078712,
   "doctor_id": 11543
 },
 {
   "diagnosis": "S25191A",
   "record_date": "2002-09-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7da",
   "patient_id": 425269856,
   "doctor_id": 11544
 },
 {
   "diagnosis": "H18829",
   "record_date": "2014-11-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7db",
   "patient_id": 226934857,
   "doctor_id": 11545
 },
 {
   "diagnosis": "Z323",
   "record_date": "2013-08-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7dc",
   "patient_id": 120223760,
   "doctor_id": 11546
 },
 {
   "diagnosis": "G319",
   "record_date": "2001-11-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7dd",
   "patient_id": 448283482,
   "doctor_id": 11547
 },
 {
   "diagnosis": "R9431",
   "record_date": "2009-04-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7de",
   "patient_id": 170598357,
   "doctor_id": 11548
 },
 {
   "diagnosis": "O98111",
   "record_date": "2005-08-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7df",
   "patient_id": 421045209,
   "doctor_id": 11549
 },
 {
   "diagnosis": "M120",
   "record_date": "2021-03-02",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7e0",
   "patient_id": 607681595,
   "doctor_id": 11550
 },
 {
   "diagnosis": "H02869",
   "record_date": "2001-08-20",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7e1",
   "patient_id": 889722477,
   "doctor_id": 11551
 },
 {
   "diagnosis": "T23029A",
   "record_date": "2016-11-03",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7e2",
   "patient_id": 203000145,
   "doctor_id": 11302
 },
 {
   "diagnosis": "M08429",
   "record_date": "2019-02-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7e3",
   "patient_id": 62505395,
   "doctor_id": 11303
 },
 {
   "diagnosis": "M13131",
   "record_date": "2020-10-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7e4",
   "patient_id": 814755149,
   "doctor_id": 11304
 },
 {
   "diagnosis": "S52344C",
   "record_date": "2003-05-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7e5",
   "patient_id": 981089876,
   "doctor_id": 11305
 },
 {
   "diagnosis": "S06324A",
   "record_date": "2015-12-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7e6",
   "patient_id": 333845615,
   "doctor_id": 11306
 },
 {
   "diagnosis": "M86612",
   "record_date": "2015-08-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7e7",
   "patient_id": 553237679,
   "doctor_id": 11307
 },
 {
   "diagnosis": "T501X5S",
   "record_date": "2005-11-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7e8",
   "patient_id": 204913870,
   "doctor_id": 11308
 },
 {
   "diagnosis": "S52311K",
   "record_date": "2020-12-16",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7e9",
   "patient_id": 206636350,
   "doctor_id": 11309
 },
 {
   "diagnosis": "T79A",
   "record_date": "2007-01-29",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7ea",
   "patient_id": 790878684,
   "doctor_id": 11310
 },
 {
   "diagnosis": "S68619S",
   "record_date": "2021-12-31",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7eb",
   "patient_id": 975972568,
   "doctor_id": 11311
 },
 {
   "diagnosis": "Y36130",
   "record_date": "2020-01-06",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7ec",
   "patient_id": 225299968,
   "doctor_id": 11312
 },
 {
   "diagnosis": "S5292XH",
   "record_date": "2008-11-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7ed",
   "patient_id": 290533830,
   "doctor_id": 11313
 },
 {
   "diagnosis": "S15392",
   "record_date": "2012-09-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7ee",
   "patient_id": 426101339,
   "doctor_id": 11314
 },
 {
   "diagnosis": "H402234",
   "record_date": "2011-12-29",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7ef",
   "patient_id": 399388732,
   "doctor_id": 11315
 },
 {
   "diagnosis": "D531",
   "record_date": "2020-09-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7f0",
   "patient_id": 450658408,
   "doctor_id": 11316
 },
 {
   "diagnosis": "O4112",
   "record_date": "2013-04-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7f1",
   "patient_id": 225825384,
   "doctor_id": 11317
 },
 {
   "diagnosis": "S3659",
   "record_date": "2001-10-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7f2",
   "patient_id": 88420477,
   "doctor_id": 11318
 },
 {
   "diagnosis": "S42465K",
   "record_date": "2022-06-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7f3",
   "patient_id": 915669969,
   "doctor_id": 11319
 },
 {
   "diagnosis": "T2622",
   "record_date": "2006-04-10",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7f4",
   "patient_id": 298778071,
   "doctor_id": 11320
 },
 {
   "diagnosis": "H59019",
   "record_date": "2020-07-13",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7f5",
   "patient_id": 296897508,
   "doctor_id": 11321
 },
 {
   "diagnosis": "M0803",
   "record_date": "2016-08-12",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7f6",
   "patient_id": 669017571,
   "doctor_id": 11322
 },
 {
   "diagnosis": "S1235",
   "record_date": "2022-09-26",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7f7",
   "patient_id": 641421685,
   "doctor_id": 11323
 },
 {
   "diagnosis": "S62663",
   "record_date": "2014-06-01",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7f8",
   "patient_id": 952728246,
   "doctor_id": 11324
 },
 {
   "diagnosis": "S93522A",
   "record_date": "2009-05-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7f9",
   "patient_id": 73649927,
   "doctor_id": 11325
 },
 {
   "diagnosis": "S72346Q",
   "record_date": "2013-08-04",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7fa",
   "patient_id": 671507928,
   "doctor_id": 11326
 },
 {
   "diagnosis": "S67198",
   "record_date": "2005-10-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7fb",
   "patient_id": 286025845,
   "doctor_id": 11327
 },
 {
   "diagnosis": "M21832",
   "record_date": "2004-03-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b7fc",
   "patient_id": 304922871,
   "doctor_id": 11328
 },
 {
   "diagnosis": "T22521S",
   "record_date": "2006-08-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b7fd",
   "patient_id": 582980783,
   "doctor_id": 11329
 },
 {
   "diagnosis": "H44422",
   "record_date": "2020-09-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b7fe",
   "patient_id": 288518803,
   "doctor_id": 11330
 },
 {
   "diagnosis": "T45694D",
   "record_date": "2002-08-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b7ff",
   "patient_id": 484167075,
   "doctor_id": 11331
 },
 {
   "diagnosis": "W2119XD",
   "record_date": "2005-01-29",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b800",
   "patient_id": 772005956,
   "doctor_id": 11332
 },
 {
   "diagnosis": "V612XXS",
   "record_date": "2014-09-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b801",
   "patient_id": 264582659,
   "doctor_id": 11333
 },
 {
   "diagnosis": "S53112",
   "record_date": "2019-08-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b802",
   "patient_id": 592112447,
   "doctor_id": 11334
 },
 {
   "diagnosis": "M71439",
   "record_date": "2006-02-11",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b803",
   "patient_id": 894373636,
   "doctor_id": 11335
 },
 {
   "diagnosis": "I2579",
   "record_date": "2005-06-22",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b804",
   "patient_id": 497715155,
   "doctor_id": 11336
 },
 {
   "diagnosis": "S71101S",
   "record_date": "2019-04-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b805",
   "patient_id": 438624573,
   "doctor_id": 11337
 },
 {
   "diagnosis": "M9130",
   "record_date": "2011-02-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b806",
   "patient_id": 345715688,
   "doctor_id": 11338
 },
 {
   "diagnosis": "S5260",
   "record_date": "2006-08-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b807",
   "patient_id": 132559883,
   "doctor_id": 11339
 },
 {
   "diagnosis": "T24221D",
   "record_date": "2017-10-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b808",
   "patient_id": 967079673,
   "doctor_id": 11340
 },
 {
   "diagnosis": "S3803XS",
   "record_date": "2013-09-03",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b809",
   "patient_id": 477166121,
   "doctor_id": 11341
 },
 {
   "diagnosis": "S43024A",
   "record_date": "2016-02-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b80a",
   "patient_id": 182844422,
   "doctor_id": 11342
 },
 {
   "diagnosis": "T8384XA",
   "record_date": "2000-12-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b80b",
   "patient_id": 547880674,
   "doctor_id": 11343
 },
 {
   "diagnosis": "M93001",
   "record_date": "2010-06-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b80c",
   "patient_id": 995701962,
   "doctor_id": 11344
 },
 {
   "diagnosis": "E791",
   "record_date": "2021-10-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b80d",
   "patient_id": 741359872,
   "doctor_id": 11345
 },
 {
   "diagnosis": "H402234",
   "record_date": "2004-03-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b80e",
   "patient_id": 20314008,
   "doctor_id": 11346
 },
 {
   "diagnosis": "F554",
   "record_date": "2016-04-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b80f",
   "patient_id": 646819878,
   "doctor_id": 11347
 },
 {
   "diagnosis": "S728X9P",
   "record_date": "2022-03-23",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b810",
   "patient_id": 886992264,
   "doctor_id": 11348
 },
 {
   "diagnosis": "O360132",
   "record_date": "2001-09-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b811",
   "patient_id": 798580686,
   "doctor_id": 11349
 },
 {
   "diagnosis": "K900",
   "record_date": "2001-11-26",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b812",
   "patient_id": 137845579,
   "doctor_id": 11350
 },
 {
   "diagnosis": "S62619",
   "record_date": "2020-07-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b813",
   "patient_id": 844857052,
   "doctor_id": 11351
 },
 {
   "diagnosis": "H9483",
   "record_date": "2006-07-16",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b814",
   "patient_id": 561739729,
   "doctor_id": 11352
 },
 {
   "diagnosis": "M5402",
   "record_date": "2022-04-14",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b815",
   "patient_id": 589802751,
   "doctor_id": 11353
 },
 {
   "diagnosis": "S3183",
   "record_date": "2013-05-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b816",
   "patient_id": 938341356,
   "doctor_id": 11354
 },
 {
   "diagnosis": "J322",
   "record_date": "2014-04-12",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b817",
   "patient_id": 412252964,
   "doctor_id": 11355
 },
 {
   "diagnosis": "H402290",
   "record_date": "2007-02-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b818",
   "patient_id": 688954037,
   "doctor_id": 11356
 },
 {
   "diagnosis": "S65891",
   "record_date": "2020-08-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b819",
   "patient_id": 195133202,
   "doctor_id": 11357
 },
 {
   "diagnosis": "M70942",
   "record_date": "2017-08-17",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b81a",
   "patient_id": 993194584,
   "doctor_id": 11358
 },
 {
   "diagnosis": "W2210XS",
   "record_date": "2017-08-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b81b",
   "patient_id": 751677696,
   "doctor_id": 11359
 },
 {
   "diagnosis": "T450X1",
   "record_date": "2008-11-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b81c",
   "patient_id": 629097045,
   "doctor_id": 11360
 },
 {
   "diagnosis": "S52599E",
   "record_date": "2013-11-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b81d",
   "patient_id": 734762728,
   "doctor_id": 11361
 },
 {
   "diagnosis": "C84A",
   "record_date": "2022-07-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b81e",
   "patient_id": 184662655,
   "doctor_id": 11362
 },
 {
   "diagnosis": "T1590XD",
   "record_date": "2022-02-06",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b81f",
   "patient_id": 636811037,
   "doctor_id": 11363
 },
 {
   "diagnosis": "M6085",
   "record_date": "2000-06-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b820",
   "patient_id": 633502640,
   "doctor_id": 11364
 },
 {
   "diagnosis": "W300XXS",
   "record_date": "2018-03-29",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b821",
   "patient_id": 539492226,
   "doctor_id": 11365
 },
 {
   "diagnosis": "G40803",
   "record_date": "2019-11-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b822",
   "patient_id": 359353686,
   "doctor_id": 11366
 },
 {
   "diagnosis": "O718",
   "record_date": "2005-06-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b823",
   "patient_id": 804688279,
   "doctor_id": 11367
 },
 {
   "diagnosis": "T18190A",
   "record_date": "2006-06-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b824",
   "patient_id": 510708767,
   "doctor_id": 11368
 },
 {
   "diagnosis": "S82291H",
   "record_date": "2017-05-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b825",
   "patient_id": 667148888,
   "doctor_id": 11369
 },
 {
   "diagnosis": "S14132",
   "record_date": "2008-12-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b826",
   "patient_id": 439725005,
   "doctor_id": 11370
 },
 {
   "diagnosis": "H0430",
   "record_date": "2015-03-30",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b827",
   "patient_id": 366580016,
   "doctor_id": 11371
 },
 {
   "diagnosis": "D521",
   "record_date": "2004-07-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b828",
   "patient_id": 832436540,
   "doctor_id": 11372
 },
 {
   "diagnosis": "S31821S",
   "record_date": "2004-06-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b829",
   "patient_id": 118189821,
   "doctor_id": 11373
 },
 {
   "diagnosis": "M25341",
   "record_date": "2022-06-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b82a",
   "patient_id": 142386290,
   "doctor_id": 11374
 },
 {
   "diagnosis": "S53004A",
   "record_date": "2004-03-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b82b",
   "patient_id": 10890207,
   "doctor_id": 11375
 },
 {
   "diagnosis": "R453",
   "record_date": "2005-01-14",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b82c",
   "patient_id": 364075393,
   "doctor_id": 11376
 },
 {
   "diagnosis": "T486X5A",
   "record_date": "2018-12-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b82d",
   "patient_id": 841358317,
   "doctor_id": 11377
 },
 {
   "diagnosis": "S24149A",
   "record_date": "2003-06-11",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b82e",
   "patient_id": 830073825,
   "doctor_id": 11378
 },
 {
   "diagnosis": "V104",
   "record_date": "2015-07-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b82f",
   "patient_id": 616964315,
   "doctor_id": 11379
 },
 {
   "diagnosis": "E083529",
   "record_date": "2020-03-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b830",
   "patient_id": 289140264,
   "doctor_id": 11380
 },
 {
   "diagnosis": "F19232",
   "record_date": "2008-11-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b831",
   "patient_id": 564585080,
   "doctor_id": 11381
 },
 {
   "diagnosis": "S6732XD",
   "record_date": "2012-05-13",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b832",
   "patient_id": 425903349,
   "doctor_id": 11382
 },
 {
   "diagnosis": "T23012S",
   "record_date": "2001-07-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b833",
   "patient_id": 79773476,
   "doctor_id": 11383
 },
 {
   "diagnosis": "N062",
   "record_date": "2020-09-22",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b834",
   "patient_id": 177646991,
   "doctor_id": 11384
 },
 {
   "diagnosis": "W5809XS",
   "record_date": "2014-08-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b835",
   "patient_id": 846745304,
   "doctor_id": 11385
 },
 {
   "diagnosis": "S48021A",
   "record_date": "2013-01-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b836",
   "patient_id": 988770075,
   "doctor_id": 11386
 },
 {
   "diagnosis": "S42231D",
   "record_date": "2000-06-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b837",
   "patient_id": 791742898,
   "doctor_id": 11387
 },
 {
   "diagnosis": "S21031",
   "record_date": "2002-10-15",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b838",
   "patient_id": 529288405,
   "doctor_id": 11388
 },
 {
   "diagnosis": "O34532",
   "record_date": "2002-10-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b839",
   "patient_id": 314273459,
   "doctor_id": 11389
 },
 {
   "diagnosis": "G43B",
   "record_date": "2010-09-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b83a",
   "patient_id": 797445830,
   "doctor_id": 11390
 },
 {
   "diagnosis": "K261",
   "record_date": "2020-11-11",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b83b",
   "patient_id": 453787601,
   "doctor_id": 11391
 },
 {
   "diagnosis": "S2731",
   "record_date": "2008-10-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b83c",
   "patient_id": 388503082,
   "doctor_id": 11392
 },
 {
   "diagnosis": "S42015K",
   "record_date": "2004-04-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b83d",
   "patient_id": 640029536,
   "doctor_id": 11393
 },
 {
   "diagnosis": "S21352A",
   "record_date": "2011-09-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b83e",
   "patient_id": 735342884,
   "doctor_id": 11394
 },
 {
   "diagnosis": "M941",
   "record_date": "2012-05-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b83f",
   "patient_id": 585713445,
   "doctor_id": 11395
 },
 {
   "diagnosis": "S72362D",
   "record_date": "2003-03-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b840",
   "patient_id": 393558923,
   "doctor_id": 11396
 },
 {
   "diagnosis": "W16221S",
   "record_date": "2002-01-31",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b841",
   "patient_id": 757255325,
   "doctor_id": 11397
 },
 {
   "diagnosis": "S89229D",
   "record_date": "2005-08-09",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b842",
   "patient_id": 308646340,
   "doctor_id": 11398
 },
 {
   "diagnosis": "S72002",
   "record_date": "2003-09-13",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b843",
   "patient_id": 687945795,
   "doctor_id": 11399
 },
 {
   "diagnosis": "M2751",
   "record_date": "2004-04-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b844",
   "patient_id": 623031103,
   "doctor_id": 11400
 },
 {
   "diagnosis": "S85141A",
   "record_date": "2016-11-11",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b845",
   "patient_id": 876250646,
   "doctor_id": 11401
 },
 {
   "diagnosis": "O9851",
   "record_date": "2021-11-19",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b846",
   "patient_id": 344454710,
   "doctor_id": 11402
 },
 {
   "diagnosis": "F301",
   "record_date": "2021-07-31",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b847",
   "patient_id": 995352285,
   "doctor_id": 11403
 },
 {
   "diagnosis": "M84353G",
   "record_date": "2003-05-29",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b848",
   "patient_id": 973927366,
   "doctor_id": 11404
 },
 {
   "diagnosis": "F10220",
   "record_date": "2008-01-14",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b849",
   "patient_id": 218742481,
   "doctor_id": 11405
 },
 {
   "diagnosis": "V710XXD",
   "record_date": "2010-02-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b84a",
   "patient_id": 517790823,
   "doctor_id": 11406
 },
 {
   "diagnosis": "Y380X3",
   "record_date": "2013-04-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b84b",
   "patient_id": 964797340,
   "doctor_id": 11407
 },
 {
   "diagnosis": "T84218S",
   "record_date": "2002-11-09",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b84c",
   "patient_id": 575157065,
   "doctor_id": 11408
 },
 {
   "diagnosis": "Z8901",
   "record_date": "2010-03-13",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b84d",
   "patient_id": 468469624,
   "doctor_id": 11409
 },
 {
   "diagnosis": "S92333K",
   "record_date": "2021-05-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b84e",
   "patient_id": 883643157,
   "doctor_id": 11410
 },
 {
   "diagnosis": "T582X3S",
   "record_date": "2007-12-15",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b84f",
   "patient_id": 704435054,
   "doctor_id": 11411
 },
 {
   "diagnosis": "I70749",
   "record_date": "2017-09-23",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b850",
   "patient_id": 948301490,
   "doctor_id": 11412
 },
 {
   "diagnosis": "T22611S",
   "record_date": "2011-07-19",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b851",
   "patient_id": 992901019,
   "doctor_id": 11413
 },
 {
   "diagnosis": "T465X",
   "record_date": "2012-08-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b852",
   "patient_id": 462510418,
   "doctor_id": 11414
 },
 {
   "diagnosis": "S31605D",
   "record_date": "2021-06-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b853",
   "patient_id": 386514075,
   "doctor_id": 11415
 },
 {
   "diagnosis": "V971XXD",
   "record_date": "2020-06-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b854",
   "patient_id": 1590456,
   "doctor_id": 11416
 },
 {
   "diagnosis": "S12401B",
   "record_date": "2022-03-06",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b855",
   "patient_id": 54935676,
   "doctor_id": 11417
 },
 {
   "diagnosis": "S0931",
   "record_date": "2021-07-11",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b856",
   "patient_id": 161105413,
   "doctor_id": 11418
 },
 {
   "diagnosis": "S96291A",
   "record_date": "2015-01-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b857",
   "patient_id": 146106230,
   "doctor_id": 11419
 },
 {
   "diagnosis": "G409",
   "record_date": "2001-12-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b858",
   "patient_id": 681225657,
   "doctor_id": 11420
 },
 {
   "diagnosis": "S92416S",
   "record_date": "2014-04-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b859",
   "patient_id": 390007509,
   "doctor_id": 11421
 },
 {
   "diagnosis": "H4051X1",
   "record_date": "2017-08-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b85a",
   "patient_id": 648341355,
   "doctor_id": 11422
 },
 {
   "diagnosis": "H4021",
   "record_date": "2009-03-29",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b85b",
   "patient_id": 179766140,
   "doctor_id": 11423
 },
 {
   "diagnosis": "T22021A",
   "record_date": "2016-06-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b85c",
   "patient_id": 143586442,
   "doctor_id": 11424
 },
 {
   "diagnosis": "T8463XD",
   "record_date": "2005-02-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b85d",
   "patient_id": 976032998,
   "doctor_id": 11425
 },
 {
   "diagnosis": "T82199S",
   "record_date": "2004-03-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b85e",
   "patient_id": 118190694,
   "doctor_id": 11426
 },
 {
   "diagnosis": "S46912A",
   "record_date": "2009-01-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b85f",
   "patient_id": 576286948,
   "doctor_id": 11427
 },
 {
   "diagnosis": "R250",
   "record_date": "2005-12-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b860",
   "patient_id": 235592819,
   "doctor_id": 11428
 },
 {
   "diagnosis": "S0193XS",
   "record_date": "2003-11-25",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b861",
   "patient_id": 190580163,
   "doctor_id": 11429
 },
 {
   "diagnosis": "S82122C",
   "record_date": "2021-08-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b862",
   "patient_id": 595786856,
   "doctor_id": 11430
 },
 {
   "diagnosis": "T84090",
   "record_date": "2017-06-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b863",
   "patient_id": 604700309,
   "doctor_id": 11431
 },
 {
   "diagnosis": "K612",
   "record_date": "2016-09-03",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b864",
   "patient_id": 902219821,
   "doctor_id": 11432
 },
 {
   "diagnosis": "S73112A",
   "record_date": "2000-03-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b865",
   "patient_id": 188976169,
   "doctor_id": 11433
 },
 {
   "diagnosis": "S62637A",
   "record_date": "2013-04-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b866",
   "patient_id": 369442227,
   "doctor_id": 11434
 },
 {
   "diagnosis": "S33130",
   "record_date": "2002-04-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b867",
   "patient_id": 18906918,
   "doctor_id": 11435
 },
 {
   "diagnosis": "M62262",
   "record_date": "2014-08-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b868",
   "patient_id": 35693825,
   "doctor_id": 11436
 },
 {
   "diagnosis": "S52021H",
   "record_date": "2004-11-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b869",
   "patient_id": 362364938,
   "doctor_id": 11437
 },
 {
   "diagnosis": "H3011",
   "record_date": "2010-10-14",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b86a",
   "patient_id": 973178479,
   "doctor_id": 11438
 },
 {
   "diagnosis": "M05542",
   "record_date": "2016-10-13",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b86b",
   "patient_id": 421353640,
   "doctor_id": 11439
 },
 {
   "diagnosis": "S52699S",
   "record_date": "2000-12-07",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b86c",
   "patient_id": 665583477,
   "doctor_id": 11440
 },
 {
   "diagnosis": "G44041",
   "record_date": "2005-11-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b86d",
   "patient_id": 672042085,
   "doctor_id": 11441
 },
 {
   "diagnosis": "S32048S",
   "record_date": "2009-08-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b86e",
   "patient_id": 208512165,
   "doctor_id": 11442
 },
 {
   "diagnosis": "S98139S",
   "record_date": "2022-05-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b86f",
   "patient_id": 696254421,
   "doctor_id": 11443
 },
 {
   "diagnosis": "S52335R",
   "record_date": "2008-09-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b870",
   "patient_id": 785024059,
   "doctor_id": 11444
 },
 {
   "diagnosis": "M85022",
   "record_date": "2007-05-18",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b871",
   "patient_id": 104852602,
   "doctor_id": 11445
 },
 {
   "diagnosis": "V9323XD",
   "record_date": "2020-10-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b872",
   "patient_id": 169056437,
   "doctor_id": 11446
 },
 {
   "diagnosis": "M8658",
   "record_date": "2007-12-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b873",
   "patient_id": 353612846,
   "doctor_id": 11447
 },
 {
   "diagnosis": "O40",
   "record_date": "2015-06-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b874",
   "patient_id": 623874543,
   "doctor_id": 11448
 },
 {
   "diagnosis": "M8088XK",
   "record_date": "2017-05-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b875",
   "patient_id": 174674776,
   "doctor_id": 11449
 },
 {
   "diagnosis": "H7492",
   "record_date": "2006-05-30",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b876",
   "patient_id": 207832878,
   "doctor_id": 11450
 },
 {
   "diagnosis": "M84445K",
   "record_date": "2020-10-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b877",
   "patient_id": 248029357,
   "doctor_id": 11451
 },
 {
   "diagnosis": "D408",
   "record_date": "2021-08-20",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b878",
   "patient_id": 358243418,
   "doctor_id": 11452
 },
 {
   "diagnosis": "S65593D",
   "record_date": "2017-11-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b879",
   "patient_id": 90632849,
   "doctor_id": 11453
 },
 {
   "diagnosis": "M2753",
   "record_date": "2012-11-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b87a",
   "patient_id": 998686365,
   "doctor_id": 11454
 },
 {
   "diagnosis": "F101",
   "record_date": "2003-07-31",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b87b",
   "patient_id": 819078814,
   "doctor_id": 11455
 },
 {
   "diagnosis": "S61141A",
   "record_date": "2022-05-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b87c",
   "patient_id": 412893753,
   "doctor_id": 11456
 },
 {
   "diagnosis": "D294",
   "record_date": "2017-02-26",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b87d",
   "patient_id": 32778867,
   "doctor_id": 11457
 },
 {
   "diagnosis": "T2036",
   "record_date": "2012-08-14",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b87e",
   "patient_id": 930710192,
   "doctor_id": 11458
 },
 {
   "diagnosis": "D5701",
   "record_date": "2022-10-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b87f",
   "patient_id": 645199470,
   "doctor_id": 11459
 },
 {
   "diagnosis": "S7811",
   "record_date": "2009-03-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b880",
   "patient_id": 396282953,
   "doctor_id": 11460
 },
 {
   "diagnosis": "S61337A",
   "record_date": "2008-05-02",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b881",
   "patient_id": 537457424,
   "doctor_id": 11461
 },
 {
   "diagnosis": "F17209",
   "record_date": "2018-04-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b882",
   "patient_id": 202267689,
   "doctor_id": 11462
 },
 {
   "diagnosis": "S99812D",
   "record_date": "2000-08-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b883",
   "patient_id": 696593451,
   "doctor_id": 11463
 },
 {
   "diagnosis": "S0451XD",
   "record_date": "2015-05-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b884",
   "patient_id": 173354845,
   "doctor_id": 11464
 },
 {
   "diagnosis": "M84411",
   "record_date": "2019-03-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b885",
   "patient_id": 195955527,
   "doctor_id": 11465
 },
 {
   "diagnosis": "S069X4A",
   "record_date": "2009-01-31",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b886",
   "patient_id": 467823139,
   "doctor_id": 11466
 },
 {
   "diagnosis": "T22112D",
   "record_date": "2019-03-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b887",
   "patient_id": 446009214,
   "doctor_id": 11467
 },
 {
   "diagnosis": "O30022",
   "record_date": "2004-02-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b888",
   "patient_id": 404831768,
   "doctor_id": 11468
 },
 {
   "diagnosis": "S15301D",
   "record_date": "2021-12-02",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b889",
   "patient_id": 582248667,
   "doctor_id": 11469
 },
 {
   "diagnosis": "M0017",
   "record_date": "2015-11-25",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b88a",
   "patient_id": 362633029,
   "doctor_id": 11470
 },
 {
   "diagnosis": "S56921A",
   "record_date": "2019-03-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b88b",
   "patient_id": 260717309,
   "doctor_id": 11471
 },
 {
   "diagnosis": "T402X5D",
   "record_date": "2010-11-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b88c",
   "patient_id": 630281586,
   "doctor_id": 11472
 },
 {
   "diagnosis": "S423",
   "record_date": "2015-01-26",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b88d",
   "patient_id": 895975590,
   "doctor_id": 11473
 },
 {
   "diagnosis": "S90454S",
   "record_date": "2013-12-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b88e",
   "patient_id": 816280609,
   "doctor_id": 11474
 },
 {
   "diagnosis": "S90862S",
   "record_date": "2020-01-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b88f",
   "patient_id": 239527640,
   "doctor_id": 11475
 },
 {
   "diagnosis": "V0212XD",
   "record_date": "2005-09-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b890",
   "patient_id": 362959196,
   "doctor_id": 11476
 },
 {
   "diagnosis": "T22349D",
   "record_date": "2008-01-04",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b891",
   "patient_id": 524081774,
   "doctor_id": 11477
 },
 {
   "diagnosis": "H01116",
   "record_date": "2007-09-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b892",
   "patient_id": 982501745,
   "doctor_id": 11478
 },
 {
   "diagnosis": "S52046P",
   "record_date": "2018-03-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b893",
   "patient_id": 786322265,
   "doctor_id": 11479
 },
 {
   "diagnosis": "T464X1",
   "record_date": "2007-04-12",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b894",
   "patient_id": 469585889,
   "doctor_id": 11480
 },
 {
   "diagnosis": "J154",
   "record_date": "2011-12-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b895",
   "patient_id": 787573949,
   "doctor_id": 11481
 },
 {
   "diagnosis": "M70929",
   "record_date": "2017-01-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b896",
   "patient_id": 346855516,
   "doctor_id": 11482
 },
 {
   "diagnosis": "S92214",
   "record_date": "2012-12-27",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b897",
   "patient_id": 313267691,
   "doctor_id": 11483
 },
 {
   "diagnosis": "Y6552",
   "record_date": "2006-11-11",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b898",
   "patient_id": 621609609,
   "doctor_id": 11484
 },
 {
   "diagnosis": "Y38893A",
   "record_date": "2017-11-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b899",
   "patient_id": 650036716,
   "doctor_id": 11485
 },
 {
   "diagnosis": "Y213XXS",
   "record_date": "2014-01-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b89a",
   "patient_id": 85032150,
   "doctor_id": 11486
 },
 {
   "diagnosis": "S92212P",
   "record_date": "2007-12-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b89b",
   "patient_id": 749112003,
   "doctor_id": 11487
 },
 {
   "diagnosis": "S63104D",
   "record_date": "2018-04-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b89c",
   "patient_id": 667496237,
   "doctor_id": 11488
 },
 {
   "diagnosis": "T422X5S",
   "record_date": "2004-12-13",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b89d",
   "patient_id": 498148613,
   "doctor_id": 11489
 },
 {
   "diagnosis": "S52371S",
   "record_date": "2006-02-20",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b89e",
   "patient_id": 648972547,
   "doctor_id": 11490
 },
 {
   "diagnosis": "Z6828",
   "record_date": "2012-11-04",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b89f",
   "patient_id": 804337980,
   "doctor_id": 11491
 },
 {
   "diagnosis": "M25476",
   "record_date": "2008-11-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8a0",
   "patient_id": 509309578,
   "doctor_id": 11492
 },
 {
   "diagnosis": "M4313",
   "record_date": "2000-12-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8a1",
   "patient_id": 235463303,
   "doctor_id": 11493
 },
 {
   "diagnosis": "V355XXS",
   "record_date": "2011-05-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8a2",
   "patient_id": 27255569,
   "doctor_id": 11494
 },
 {
   "diagnosis": "S82243S",
   "record_date": "2006-04-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8a3",
   "patient_id": 532706040,
   "doctor_id": 11495
 },
 {
   "diagnosis": "K92",
   "record_date": "2010-01-22",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8a4",
   "patient_id": 692001184,
   "doctor_id": 11496
 },
 {
   "diagnosis": "S4226",
   "record_date": "2005-08-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8a5",
   "patient_id": 142758365,
   "doctor_id": 11497
 },
 {
   "diagnosis": "S72043D",
   "record_date": "2018-11-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8a6",
   "patient_id": 82048598,
   "doctor_id": 11498
 },
 {
   "diagnosis": "H353212",
   "record_date": "2002-12-26",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8a7",
   "patient_id": 174628396,
   "doctor_id": 11499
 },
 {
   "diagnosis": "V80710A",
   "record_date": "2007-10-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8a8",
   "patient_id": 560384589,
   "doctor_id": 11500
 },
 {
   "diagnosis": "S06376D",
   "record_date": "2003-08-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8a9",
   "patient_id": 624936117,
   "doctor_id": 11501
 },
 {
   "diagnosis": "V470XXS",
   "record_date": "2008-05-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8aa",
   "patient_id": 398885724,
   "doctor_id": 11502
 },
 {
   "diagnosis": "S32484S",
   "record_date": "2008-07-02",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8ab",
   "patient_id": 54328749,
   "doctor_id": 11503
 },
 {
   "diagnosis": "S52133M",
   "record_date": "2013-05-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ac",
   "patient_id": 992634308,
   "doctor_id": 11504
 },
 {
   "diagnosis": "S72444H",
   "record_date": "2015-10-26",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8ad",
   "patient_id": 793003815,
   "doctor_id": 11505
 },
 {
   "diagnosis": "S52023E",
   "record_date": "2005-10-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ae",
   "patient_id": 495787877,
   "doctor_id": 11506
 },
 {
   "diagnosis": "T63791S",
   "record_date": "2018-08-20",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8af",
   "patient_id": 267743189,
   "doctor_id": 11507
 },
 {
   "diagnosis": "S41112D",
   "record_date": "2008-11-29",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8b0",
   "patient_id": 55659397,
   "doctor_id": 11508
 },
 {
   "diagnosis": "H01019",
   "record_date": "2016-11-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8b1",
   "patient_id": 122404338,
   "doctor_id": 11509
 },
 {
   "diagnosis": "S32120D",
   "record_date": "2012-06-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8b2",
   "patient_id": 77165315,
   "doctor_id": 11510
 },
 {
   "diagnosis": "S43215D",
   "record_date": "2004-08-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8b3",
   "patient_id": 275412918,
   "doctor_id": 11511
 },
 {
   "diagnosis": "M14832",
   "record_date": "2021-04-08",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8b4",
   "patient_id": 828460468,
   "doctor_id": 11512
 },
 {
   "diagnosis": "T484X5",
   "record_date": "2009-01-17",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8b5",
   "patient_id": 556879037,
   "doctor_id": 11513
 },
 {
   "diagnosis": "T8059",
   "record_date": "2018-06-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8b6",
   "patient_id": 514125439,
   "doctor_id": 11514
 },
 {
   "diagnosis": "I6995",
   "record_date": "2015-11-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8b7",
   "patient_id": 727065332,
   "doctor_id": 11515
 },
 {
   "diagnosis": "M23612",
   "record_date": "2009-05-08",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8b8",
   "patient_id": 422709967,
   "doctor_id": 11516
 },
 {
   "diagnosis": "S9892",
   "record_date": "2002-07-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8b9",
   "patient_id": 355411103,
   "doctor_id": 11517
 },
 {
   "diagnosis": "S21002",
   "record_date": "2022-09-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8ba",
   "patient_id": 722061898,
   "doctor_id": 11518
 },
 {
   "diagnosis": "Z604",
   "record_date": "2015-01-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8bb",
   "patient_id": 834934164,
   "doctor_id": 11519
 },
 {
   "diagnosis": "M84673K",
   "record_date": "2021-09-18",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8bc",
   "patient_id": 399411276,
   "doctor_id": 11520
 },
 {
   "diagnosis": "S63259S",
   "record_date": "2022-02-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8bd",
   "patient_id": 711641592,
   "doctor_id": 11521
 },
 {
   "diagnosis": "S12451S",
   "record_date": "2008-09-22",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8be",
   "patient_id": 828018247,
   "doctor_id": 11522
 },
 {
   "diagnosis": "S6035",
   "record_date": "2012-07-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8bf",
   "patient_id": 220892804,
   "doctor_id": 11523
 },
 {
   "diagnosis": "S75991",
   "record_date": "2000-09-25",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8c0",
   "patient_id": 927887398,
   "doctor_id": 11524
 },
 {
   "diagnosis": "T443X3",
   "record_date": "2004-02-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8c1",
   "patient_id": 196667880,
   "doctor_id": 11525
 },
 {
   "diagnosis": "S56421A",
   "record_date": "2004-12-01",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8c2",
   "patient_id": 606450439,
   "doctor_id": 11526
 },
 {
   "diagnosis": "D0919",
   "record_date": "2022-09-04",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8c3",
   "patient_id": 425822956,
   "doctor_id": 11527
 },
 {
   "diagnosis": "T46901A",
   "record_date": "2001-09-25",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8c4",
   "patient_id": 204069482,
   "doctor_id": 11528
 },
 {
   "diagnosis": "S62660P",
   "record_date": "2004-05-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8c5",
   "patient_id": 783006925,
   "doctor_id": 11529
 },
 {
   "diagnosis": "D408",
   "record_date": "2017-05-28",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8c6",
   "patient_id": 663380934,
   "doctor_id": 11530
 },
 {
   "diagnosis": "T24602A",
   "record_date": "2005-03-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8c7",
   "patient_id": 370327248,
   "doctor_id": 11531
 },
 {
   "diagnosis": "Z2089",
   "record_date": "2002-09-04",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8c8",
   "patient_id": 751139588,
   "doctor_id": 11532
 },
 {
   "diagnosis": "S36428D",
   "record_date": "2005-05-08",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8c9",
   "patient_id": 71234680,
   "doctor_id": 11533
 },
 {
   "diagnosis": "T40996S",
   "record_date": "2011-07-15",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ca",
   "patient_id": 158221518,
   "doctor_id": 11534
 },
 {
   "diagnosis": "B079",
   "record_date": "2018-04-26",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8cb",
   "patient_id": 610043626,
   "doctor_id": 11535
 },
 {
   "diagnosis": "S25501",
   "record_date": "2004-07-10",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8cc",
   "patient_id": 302026565,
   "doctor_id": 11536
 },
 {
   "diagnosis": "S27332A",
   "record_date": "2011-05-09",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8cd",
   "patient_id": 614049323,
   "doctor_id": 11537
 },
 {
   "diagnosis": "S065X0D",
   "record_date": "2007-12-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ce",
   "patient_id": 146173247,
   "doctor_id": 11538
 },
 {
   "diagnosis": "H184",
   "record_date": "2016-07-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8cf",
   "patient_id": 447848844,
   "doctor_id": 11539
 },
 {
   "diagnosis": "S32042",
   "record_date": "2020-07-11",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8d0",
   "patient_id": 962204244,
   "doctor_id": 11540
 },
 {
   "diagnosis": "F19930",
   "record_date": "2021-08-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8d1",
   "patient_id": 58847187,
   "doctor_id": 11541
 },
 {
   "diagnosis": "T63332A",
   "record_date": "2006-04-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8d2",
   "patient_id": 727571485,
   "doctor_id": 11542
 },
 {
   "diagnosis": "T63622A",
   "record_date": "2014-07-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8d3",
   "patient_id": 387562934,
   "doctor_id": 11543
 },
 {
   "diagnosis": "S83231D",
   "record_date": "2004-04-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8d4",
   "patient_id": 578778803,
   "doctor_id": 11544
 },
 {
   "diagnosis": "S43034",
   "record_date": "2019-11-09",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8d5",
   "patient_id": 852057075,
   "doctor_id": 11545
 },
 {
   "diagnosis": "S61222A",
   "record_date": "2000-04-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8d6",
   "patient_id": 841305837,
   "doctor_id": 11546
 },
 {
   "diagnosis": "H5347",
   "record_date": "2015-07-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8d7",
   "patient_id": 163440809,
   "doctor_id": 11547
 },
 {
   "diagnosis": "T22199D",
   "record_date": "2012-09-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8d8",
   "patient_id": 234840191,
   "doctor_id": 11548
 },
 {
   "diagnosis": "M910",
   "record_date": "2020-10-04",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8d9",
   "patient_id": 628295878,
   "doctor_id": 11549
 },
 {
   "diagnosis": "S66829S",
   "record_date": "2022-07-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8da",
   "patient_id": 293277773,
   "doctor_id": 11550
 },
 {
   "diagnosis": "S3098XA",
   "record_date": "2007-05-06",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8db",
   "patient_id": 380391051,
   "doctor_id": 11551
 },
 {
   "diagnosis": "S52242R",
   "record_date": "2011-12-31",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8dc",
   "patient_id": 822119060,
   "doctor_id": 11302
 },
 {
   "diagnosis": "F1812",
   "record_date": "2000-06-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8dd",
   "patient_id": 216341589,
   "doctor_id": 11303
 },
 {
   "diagnosis": "S92225A",
   "record_date": "2006-10-02",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8de",
   "patient_id": 341005835,
   "doctor_id": 11304
 },
 {
   "diagnosis": "S32433B",
   "record_date": "2014-06-13",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8df",
   "patient_id": 723143458,
   "doctor_id": 11305
 },
 {
   "diagnosis": "S52246H",
   "record_date": "2021-09-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8e0",
   "patient_id": 871416790,
   "doctor_id": 11306
 },
 {
   "diagnosis": "S56114D",
   "record_date": "2012-08-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8e1",
   "patient_id": 975198286,
   "doctor_id": 11307
 },
 {
   "diagnosis": "S2223",
   "record_date": "2011-10-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8e2",
   "patient_id": 180585272,
   "doctor_id": 11308
 },
 {
   "diagnosis": "S62123B",
   "record_date": "2003-01-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8e3",
   "patient_id": 552127421,
   "doctor_id": 11309
 },
 {
   "diagnosis": "O3102",
   "record_date": "2019-07-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8e4",
   "patient_id": 53267561,
   "doctor_id": 11310
 },
 {
   "diagnosis": "L03222",
   "record_date": "2007-02-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8e5",
   "patient_id": 488000191,
   "doctor_id": 11311
 },
 {
   "diagnosis": "T23231D",
   "record_date": "2003-08-26",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8e6",
   "patient_id": 172196320,
   "doctor_id": 11312
 },
 {
   "diagnosis": "S72452N",
   "record_date": "2022-05-28",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8e7",
   "patient_id": 394991105,
   "doctor_id": 11313
 },
 {
   "diagnosis": "S61532S",
   "record_date": "2016-07-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8e8",
   "patient_id": 673388522,
   "doctor_id": 11314
 },
 {
   "diagnosis": "M84461D",
   "record_date": "2000-06-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8e9",
   "patient_id": 524560183,
   "doctor_id": 11315
 },
 {
   "diagnosis": "O898",
   "record_date": "2006-02-13",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8ea",
   "patient_id": 454773624,
   "doctor_id": 11316
 },
 {
   "diagnosis": "S82041P",
   "record_date": "2006-12-02",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8eb",
   "patient_id": 237338496,
   "doctor_id": 11317
 },
 {
   "diagnosis": "S42125D",
   "record_date": "2020-11-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ec",
   "patient_id": 558371102,
   "doctor_id": 11318
 },
 {
   "diagnosis": "Q678",
   "record_date": "2021-02-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8ed",
   "patient_id": 174952221,
   "doctor_id": 11319
 },
 {
   "diagnosis": "I34",
   "record_date": "2019-10-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ee",
   "patient_id": 958673895,
   "doctor_id": 11320
 },
 {
   "diagnosis": "C8464",
   "record_date": "2014-06-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8ef",
   "patient_id": 15872130,
   "doctor_id": 11321
 },
 {
   "diagnosis": "S9012",
   "record_date": "2012-01-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8f0",
   "patient_id": 100833952,
   "doctor_id": 11322
 },
 {
   "diagnosis": "V0212XS",
   "record_date": "2016-02-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8f1",
   "patient_id": 443049773,
   "doctor_id": 11323
 },
 {
   "diagnosis": "T470X3D",
   "record_date": "2016-06-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8f2",
   "patient_id": 373128023,
   "doctor_id": 11324
 },
 {
   "diagnosis": "S42442K",
   "record_date": "2011-01-25",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8f3",
   "patient_id": 583820076,
   "doctor_id": 11325
 },
 {
   "diagnosis": "H5054",
   "record_date": "2008-09-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8f4",
   "patient_id": 16645202,
   "doctor_id": 11326
 },
 {
   "diagnosis": "T45603S",
   "record_date": "2009-06-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8f5",
   "patient_id": 358659356,
   "doctor_id": 11327
 },
 {
   "diagnosis": "M6389",
   "record_date": "2006-10-30",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8f6",
   "patient_id": 767925392,
   "doctor_id": 11328
 },
 {
   "diagnosis": "Y93J3",
   "record_date": "2011-03-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8f7",
   "patient_id": 442239244,
   "doctor_id": 11329
 },
 {
   "diagnosis": "M84362K",
   "record_date": "2011-03-31",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8f8",
   "patient_id": 360962395,
   "doctor_id": 11330
 },
 {
   "diagnosis": "S52243P",
   "record_date": "2022-04-19",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b8f9",
   "patient_id": 969926022,
   "doctor_id": 11331
 },
 {
   "diagnosis": "S92352P",
   "record_date": "2012-11-29",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b8fa",
   "patient_id": 760783680,
   "doctor_id": 11332
 },
 {
   "diagnosis": "S46092S",
   "record_date": "2019-06-21",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8fb",
   "patient_id": 426150282,
   "doctor_id": 11333
 },
 {
   "diagnosis": "T2671",
   "record_date": "2013-08-26",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8fc",
   "patient_id": 245156077,
   "doctor_id": 11334
 },
 {
   "diagnosis": "M19141",
   "record_date": "2013-04-26",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8fd",
   "patient_id": 845135006,
   "doctor_id": 11335
 },
 {
   "diagnosis": "S72066N",
   "record_date": "2000-02-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b8fe",
   "patient_id": 95439846,
   "doctor_id": 11336
 },
 {
   "diagnosis": "H68022",
   "record_date": "2005-07-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b8ff",
   "patient_id": 491504279,
   "doctor_id": 11337
 },
 {
   "diagnosis": "S45991A",
   "record_date": "2002-12-15",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b900",
   "patient_id": 561522838,
   "doctor_id": 11338
 },
 {
   "diagnosis": "Z4501",
   "record_date": "2020-04-20",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b901",
   "patient_id": 63383900,
   "doctor_id": 11339
 },
 {
   "diagnosis": "S73192D",
   "record_date": "2009-06-14",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b902",
   "patient_id": 726967084,
   "doctor_id": 11340
 },
 {
   "diagnosis": "S62333S",
   "record_date": "2008-10-20",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b903",
   "patient_id": 951806645,
   "doctor_id": 11341
 },
 {
   "diagnosis": "S62175D",
   "record_date": "2016-11-20",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b904",
   "patient_id": 56796787,
   "doctor_id": 11342
 },
 {
   "diagnosis": "T567X2",
   "record_date": "2012-05-21",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b905",
   "patient_id": 592008114,
   "doctor_id": 11343
 },
 {
   "diagnosis": "H401123",
   "record_date": "2008-01-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b906",
   "patient_id": 737894934,
   "doctor_id": 11344
 },
 {
   "diagnosis": "S0531XS",
   "record_date": "2008-10-31",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b907",
   "patient_id": 642803844,
   "doctor_id": 11345
 },
 {
   "diagnosis": "M4835",
   "record_date": "2003-08-29",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b908",
   "patient_id": 750433834,
   "doctor_id": 11346
 },
 {
   "diagnosis": "S0134",
   "record_date": "2001-11-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b909",
   "patient_id": 627864350,
   "doctor_id": 11347
 },
 {
   "diagnosis": "S32811A",
   "record_date": "2015-03-24",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b90a",
   "patient_id": 222715264,
   "doctor_id": 11348
 },
 {
   "diagnosis": "S61041A",
   "record_date": "2012-08-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b90b",
   "patient_id": 649394034,
   "doctor_id": 11349
 },
 {
   "diagnosis": "S92044B",
   "record_date": "2020-12-22",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b90c",
   "patient_id": 591904943,
   "doctor_id": 11350
 },
 {
   "diagnosis": "S92421A",
   "record_date": "2022-03-26",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b90d",
   "patient_id": 810238921,
   "doctor_id": 11351
 },
 {
   "diagnosis": "T392X6",
   "record_date": "2014-09-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b90e",
   "patient_id": 666059384,
   "doctor_id": 11352
 },
 {
   "diagnosis": "A0102",
   "record_date": "2011-04-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b90f",
   "patient_id": 381282331,
   "doctor_id": 11353
 },
 {
   "diagnosis": "S63103S",
   "record_date": "2011-03-03",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b910",
   "patient_id": 924528870,
   "doctor_id": 11354
 },
 {
   "diagnosis": "V18",
   "record_date": "2017-01-02",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b911",
   "patient_id": 86059531,
   "doctor_id": 11355
 },
 {
   "diagnosis": "Z873",
   "record_date": "2012-10-25",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b912",
   "patient_id": 407769727,
   "doctor_id": 11356
 },
 {
   "diagnosis": "T506X1A",
   "record_date": "2003-09-05",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b913",
   "patient_id": 282326788,
   "doctor_id": 11357
 },
 {
   "diagnosis": "S43011A",
   "record_date": "2022-05-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b914",
   "patient_id": 186918018,
   "doctor_id": 11358
 },
 {
   "diagnosis": "S59809A",
   "record_date": "2021-06-26",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b915",
   "patient_id": 890414331,
   "doctor_id": 11359
 },
 {
   "diagnosis": "S62244K",
   "record_date": "2000-04-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b916",
   "patient_id": 708402744,
   "doctor_id": 11360
 },
 {
   "diagnosis": "S61029D",
   "record_date": "2011-10-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b917",
   "patient_id": 447124052,
   "doctor_id": 11361
 },
 {
   "diagnosis": "V8692",
   "record_date": "2006-08-26",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b918",
   "patient_id": 418087409,
   "doctor_id": 11362
 },
 {
   "diagnosis": "S53023S",
   "record_date": "2021-03-22",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b919",
   "patient_id": 196178628,
   "doctor_id": 11363
 },
 {
   "diagnosis": "S61542A",
   "record_date": "2017-05-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b91a",
   "patient_id": 627492498,
   "doctor_id": 11364
 },
 {
   "diagnosis": "H33043",
   "record_date": "2004-05-16",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b91b",
   "patient_id": 134474461,
   "doctor_id": 11365
 },
 {
   "diagnosis": "S82153",
   "record_date": "2006-09-16",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b91c",
   "patient_id": 853201296,
   "doctor_id": 11366
 },
 {
   "diagnosis": "H4611",
   "record_date": "2005-05-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b91d",
   "patient_id": 474252687,
   "doctor_id": 11367
 },
 {
   "diagnosis": "R54",
   "record_date": "2018-10-10",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b91e",
   "patient_id": 137137630,
   "doctor_id": 11368
 },
 {
   "diagnosis": "S92355D",
   "record_date": "2020-11-01",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b91f",
   "patient_id": 661910972,
   "doctor_id": 11369
 },
 {
   "diagnosis": "M24331",
   "record_date": "2022-10-09",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b920",
   "patient_id": 536786017,
   "doctor_id": 11370
 },
 {
   "diagnosis": "P8330",
   "record_date": "2014-02-17",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b921",
   "patient_id": 778253730,
   "doctor_id": 11371
 },
 {
   "diagnosis": "I071",
   "record_date": "2016-11-29",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b922",
   "patient_id": 518505968,
   "doctor_id": 11372
 },
 {
   "diagnosis": "T22021S",
   "record_date": "2010-01-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b923",
   "patient_id": 707411426,
   "doctor_id": 11373
 },
 {
   "diagnosis": "S00272A",
   "record_date": "2003-02-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b924",
   "patient_id": 249741020,
   "doctor_id": 11374
 },
 {
   "diagnosis": "M14631",
   "record_date": "2005-06-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b925",
   "patient_id": 783018434,
   "doctor_id": 11375
 },
 {
   "diagnosis": "S32391B",
   "record_date": "2014-04-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b926",
   "patient_id": 349597755,
   "doctor_id": 11376
 },
 {
   "diagnosis": "M00842",
   "record_date": "2001-09-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b927",
   "patient_id": 582503638,
   "doctor_id": 11377
 },
 {
   "diagnosis": "S62009D",
   "record_date": "2015-01-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b928",
   "patient_id": 759950584,
   "doctor_id": 11378
 },
 {
   "diagnosis": "S8332XA",
   "record_date": "2005-02-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b929",
   "patient_id": 625735054,
   "doctor_id": 11379
 },
 {
   "diagnosis": "S23140",
   "record_date": "2013-09-26",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b92a",
   "patient_id": 570818174,
   "doctor_id": 11380
 },
 {
   "diagnosis": "S82846P",
   "record_date": "2002-09-18",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b92b",
   "patient_id": 902124954,
   "doctor_id": 11381
 },
 {
   "diagnosis": "S21202A",
   "record_date": "2014-01-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b92c",
   "patient_id": 245274251,
   "doctor_id": 11382
 },
 {
   "diagnosis": "S25109S",
   "record_date": "2005-11-12",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b92d",
   "patient_id": 478632290,
   "doctor_id": 11383
 },
 {
   "diagnosis": "S49132A",
   "record_date": "2011-11-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b92e",
   "patient_id": 500039825,
   "doctor_id": 11384
 },
 {
   "diagnosis": "S82811D",
   "record_date": "2013-05-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b92f",
   "patient_id": 338587764,
   "doctor_id": 11385
 },
 {
   "diagnosis": "H70222",
   "record_date": "2009-09-09",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b930",
   "patient_id": 751396983,
   "doctor_id": 11386
 },
 {
   "diagnosis": "S73122S",
   "record_date": "2004-07-23",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b931",
   "patient_id": 50742910,
   "doctor_id": 11387
 },
 {
   "diagnosis": "S63219",
   "record_date": "2000-02-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b932",
   "patient_id": 165462262,
   "doctor_id": 11388
 },
 {
   "diagnosis": "C8587",
   "record_date": "2005-11-05",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b933",
   "patient_id": 863180058,
   "doctor_id": 11389
 },
 {
   "diagnosis": "T8132XS",
   "record_date": "2003-10-23",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b934",
   "patient_id": 102052438,
   "doctor_id": 11390
 },
 {
   "diagnosis": "S82141P",
   "record_date": "2007-10-14",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b935",
   "patient_id": 871619181,
   "doctor_id": 11391
 },
 {
   "diagnosis": "S22022G",
   "record_date": "2000-09-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b936",
   "patient_id": 423531147,
   "doctor_id": 11392
 },
 {
   "diagnosis": "M1203",
   "record_date": "2001-12-31",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b937",
   "patient_id": 187843865,
   "doctor_id": 11393
 },
 {
   "diagnosis": "R972",
   "record_date": "2018-05-04",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b938",
   "patient_id": 667342061,
   "doctor_id": 11394
 },
 {
   "diagnosis": "S82819P",
   "record_date": "2002-08-23",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b939",
   "patient_id": 140472123,
   "doctor_id": 11395
 },
 {
   "diagnosis": "S64495S",
   "record_date": "2002-07-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b93a",
   "patient_id": 966654090,
   "doctor_id": 11396
 },
 {
   "diagnosis": "S99221G",
   "record_date": "2016-09-19",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b93b",
   "patient_id": 196472497,
   "doctor_id": 11397
 },
 {
   "diagnosis": "M05142",
   "record_date": "2008-08-27",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b93c",
   "patient_id": 353386211,
   "doctor_id": 11398
 },
 {
   "diagnosis": "P150",
   "record_date": "2012-06-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b93d",
   "patient_id": 980884320,
   "doctor_id": 11399
 },
 {
   "diagnosis": "S06824",
   "record_date": "2003-09-26",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b93e",
   "patient_id": 846986230,
   "doctor_id": 11400
 },
 {
   "diagnosis": "W08",
   "record_date": "2021-07-03",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b93f",
   "patient_id": 376436306,
   "doctor_id": 11401
 },
 {
   "diagnosis": "S63131",
   "record_date": "2015-01-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b940",
   "patient_id": 942341893,
   "doctor_id": 11402
 },
 {
   "diagnosis": "S61204D",
   "record_date": "2015-06-24",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b941",
   "patient_id": 521982124,
   "doctor_id": 11403
 },
 {
   "diagnosis": "S13121A",
   "record_date": "2006-07-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b942",
   "patient_id": 927918713,
   "doctor_id": 11404
 },
 {
   "diagnosis": "E1335",
   "record_date": "2001-01-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b943",
   "patient_id": 781909731,
   "doctor_id": 11405
 },
 {
   "diagnosis": "S23110A",
   "record_date": "2016-12-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b944",
   "patient_id": 547279741,
   "doctor_id": 11406
 },
 {
   "diagnosis": "P102",
   "record_date": "2014-07-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b945",
   "patient_id": 215793399,
   "doctor_id": 11407
 },
 {
   "diagnosis": "T50B11",
   "record_date": "2013-05-29",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b946",
   "patient_id": 486924060,
   "doctor_id": 11408
 },
 {
   "diagnosis": "T83192A",
   "record_date": "2019-10-28",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b947",
   "patient_id": 148654152,
   "doctor_id": 11409
 },
 {
   "diagnosis": "S96109D",
   "record_date": "2019-07-15",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b948",
   "patient_id": 197898918,
   "doctor_id": 11410
 },
 {
   "diagnosis": "S72321D",
   "record_date": "2004-01-07",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b949",
   "patient_id": 160534729,
   "doctor_id": 11411
 },
 {
   "diagnosis": "S91256D",
   "record_date": "2008-08-07",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b94a",
   "patient_id": 653097176,
   "doctor_id": 11412
 },
 {
   "diagnosis": "Z9622",
   "record_date": "2020-02-27",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b94b",
   "patient_id": 121001453,
   "doctor_id": 11413
 },
 {
   "diagnosis": "S0266",
   "record_date": "2007-11-22",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b94c",
   "patient_id": 606965170,
   "doctor_id": 11414
 },
 {
   "diagnosis": "L080",
   "record_date": "2017-07-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b94d",
   "patient_id": 637796172,
   "doctor_id": 11415
 },
 {
   "diagnosis": "M4711",
   "record_date": "2011-12-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b94e",
   "patient_id": 435260700,
   "doctor_id": 11416
 },
 {
   "diagnosis": "T543X1D",
   "record_date": "2017-03-25",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b94f",
   "patient_id": 706180084,
   "doctor_id": 11417
 },
 {
   "diagnosis": "T81597A",
   "record_date": "2001-04-23",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b950",
   "patient_id": 623294770,
   "doctor_id": 11418
 },
 {
   "diagnosis": "S52399",
   "record_date": "2009-02-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b951",
   "patient_id": 660125232,
   "doctor_id": 11419
 },
 {
   "diagnosis": "I241",
   "record_date": "2008-07-13",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b952",
   "patient_id": 768934003,
   "doctor_id": 11420
 },
 {
   "diagnosis": "S52252B",
   "record_date": "2018-10-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b953",
   "patient_id": 350104204,
   "doctor_id": 11421
 },
 {
   "diagnosis": "M65061",
   "record_date": "2022-06-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b954",
   "patient_id": 484172695,
   "doctor_id": 11422
 },
 {
   "diagnosis": "Y92198",
   "record_date": "2013-01-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b955",
   "patient_id": 883839913,
   "doctor_id": 11423
 },
 {
   "diagnosis": "S96992S",
   "record_date": "2003-05-21",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b956",
   "patient_id": 488400609,
   "doctor_id": 11424
 },
 {
   "diagnosis": "T25719",
   "record_date": "2014-03-05",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b957",
   "patient_id": 625023306,
   "doctor_id": 11425
 },
 {
   "diagnosis": "S78912D",
   "record_date": "2018-10-02",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b958",
   "patient_id": 829378323,
   "doctor_id": 11426
 },
 {
   "diagnosis": "H35161",
   "record_date": "2009-05-06",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b959",
   "patient_id": 738299771,
   "doctor_id": 11427
 },
 {
   "diagnosis": "Y35091D",
   "record_date": "2003-02-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b95a",
   "patient_id": 76270626,
   "doctor_id": 11428
 },
 {
   "diagnosis": "M1A1311",
   "record_date": "2003-01-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b95b",
   "patient_id": 881194918,
   "doctor_id": 11429
 },
 {
   "diagnosis": "H15859",
   "record_date": "2001-05-02",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b95c",
   "patient_id": 890556032,
   "doctor_id": 11430
 },
 {
   "diagnosis": "S12331K",
   "record_date": "2012-10-09",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b95d",
   "patient_id": 655152320,
   "doctor_id": 11431
 },
 {
   "diagnosis": "T23362D",
   "record_date": "2010-12-29",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b95e",
   "patient_id": 734169746,
   "doctor_id": 11432
 },
 {
   "diagnosis": "S12430K",
   "record_date": "2010-08-29",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b95f",
   "patient_id": 37776151,
   "doctor_id": 11433
 },
 {
   "diagnosis": "T50902A",
   "record_date": "2008-12-07",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b960",
   "patient_id": 929970592,
   "doctor_id": 11434
 },
 {
   "diagnosis": "S72114D",
   "record_date": "2001-11-14",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b961",
   "patient_id": 946192834,
   "doctor_id": 11435
 },
 {
   "diagnosis": "S96091D",
   "record_date": "2009-10-27",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b962",
   "patient_id": 880451231,
   "doctor_id": 11436
 },
 {
   "diagnosis": "Z4789",
   "record_date": "2018-08-06",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b963",
   "patient_id": 415234328,
   "doctor_id": 11437
 },
 {
   "diagnosis": "S22072A",
   "record_date": "2010-05-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b964",
   "patient_id": 666654684,
   "doctor_id": 11438
 },
 {
   "diagnosis": "H40061",
   "record_date": "2009-03-19",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b965",
   "patient_id": 583467087,
   "doctor_id": 11439
 },
 {
   "diagnosis": "L974",
   "record_date": "2000-01-04",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b966",
   "patient_id": 527249909,
   "doctor_id": 11440
 },
 {
   "diagnosis": "S338XXA",
   "record_date": "2002-06-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b967",
   "patient_id": 14394039,
   "doctor_id": 11441
 },
 {
   "diagnosis": "M05471",
   "record_date": "2017-12-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b968",
   "patient_id": 218900712,
   "doctor_id": 11442
 },
 {
   "diagnosis": "Q701",
   "record_date": "2020-02-13",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b969",
   "patient_id": 300141645,
   "doctor_id": 11443
 },
 {
   "diagnosis": "S72122M",
   "record_date": "2001-04-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b96a",
   "patient_id": 630381666,
   "doctor_id": 11444
 },
 {
   "diagnosis": "S65592S",
   "record_date": "2001-11-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b96b",
   "patient_id": 786152038,
   "doctor_id": 11445
 },
 {
   "diagnosis": "T24729S",
   "record_date": "2022-05-16",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b96c",
   "patient_id": 858357322,
   "doctor_id": 11446
 },
 {
   "diagnosis": "S82032F",
   "record_date": "2013-02-21",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b96d",
   "patient_id": 22415356,
   "doctor_id": 11447
 },
 {
   "diagnosis": "S22009K",
   "record_date": "2021-07-07",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b96e",
   "patient_id": 366151155,
   "doctor_id": 11448
 },
 {
   "diagnosis": "S82864B",
   "record_date": "2017-09-08",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b96f",
   "patient_id": 954313360,
   "doctor_id": 11449
 },
 {
   "diagnosis": "S92503K",
   "record_date": "2004-02-15",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b970",
   "patient_id": 386026887,
   "doctor_id": 11450
 },
 {
   "diagnosis": "M84421D",
   "record_date": "2009-02-21",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b971",
   "patient_id": 324923515,
   "doctor_id": 11451
 },
 {
   "diagnosis": "S30877D",
   "record_date": "2011-09-30",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b972",
   "patient_id": 943575883,
   "doctor_id": 11452
 },
 {
   "diagnosis": "S83093A",
   "record_date": "2017-11-07",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b973",
   "patient_id": 883167311,
   "doctor_id": 11453
 },
 {
   "diagnosis": "S59292D",
   "record_date": "2015-08-01",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b974",
   "patient_id": 731826895,
   "doctor_id": 11454
 },
 {
   "diagnosis": "C4420",
   "record_date": "2011-08-18",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b975",
   "patient_id": 703959081,
   "doctor_id": 11455
 },
 {
   "diagnosis": "V140XXS",
   "record_date": "2020-02-11",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b976",
   "patient_id": 744223687,
   "doctor_id": 11456
 },
 {
   "diagnosis": "S52571F",
   "record_date": "2012-11-27",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b977",
   "patient_id": 612258223,
   "doctor_id": 11457
 },
 {
   "diagnosis": "Z289",
   "record_date": "2017-01-11",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b978",
   "patient_id": 709888692,
   "doctor_id": 11458
 },
 {
   "diagnosis": "N988",
   "record_date": "2010-05-31",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b979",
   "patient_id": 669229183,
   "doctor_id": 11459
 },
 {
   "diagnosis": "N2881",
   "record_date": "2017-08-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b97a",
   "patient_id": 858823891,
   "doctor_id": 11460
 },
 {
   "diagnosis": "V983",
   "record_date": "2021-08-12",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b97b",
   "patient_id": 654723307,
   "doctor_id": 11461
 },
 {
   "diagnosis": "Q336",
   "record_date": "2009-03-08",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b97c",
   "patient_id": 63960445,
   "doctor_id": 11462
 },
 {
   "diagnosis": "S5233",
   "record_date": "2017-01-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b97d",
   "patient_id": 42843440,
   "doctor_id": 11463
 },
 {
   "diagnosis": "W092",
   "record_date": "2010-08-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b97e",
   "patient_id": 819407643,
   "doctor_id": 11464
 },
 {
   "diagnosis": "S01129S",
   "record_date": "2007-06-29",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b97f",
   "patient_id": 25927147,
   "doctor_id": 11465
 },
 {
   "diagnosis": "S14114",
   "record_date": "2007-10-10",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b980",
   "patient_id": 353202695,
   "doctor_id": 11466
 },
 {
   "diagnosis": "S82101D",
   "record_date": "2017-07-03",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b981",
   "patient_id": 747592361,
   "doctor_id": 11467
 },
 {
   "diagnosis": "M93032",
   "record_date": "2001-01-20",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b982",
   "patient_id": 627415781,
   "doctor_id": 11468
 },
 {
   "diagnosis": "M0607",
   "record_date": "2018-06-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b983",
   "patient_id": 18573610,
   "doctor_id": 11469
 },
 {
   "diagnosis": "M1A4490",
   "record_date": "2005-06-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b984",
   "patient_id": 39917989,
   "doctor_id": 11470
 },
 {
   "diagnosis": "S50342",
   "record_date": "2001-11-30",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b985",
   "patient_id": 878378933,
   "doctor_id": 11471
 },
 {
   "diagnosis": "T543X1S",
   "record_date": "2016-02-07",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b986",
   "patient_id": 879106274,
   "doctor_id": 11472
 },
 {
   "diagnosis": "S58029",
   "record_date": "2006-08-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b987",
   "patient_id": 454491716,
   "doctor_id": 11473
 },
 {
   "diagnosis": "S72432",
   "record_date": "2001-09-24",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b988",
   "patient_id": 483478758,
   "doctor_id": 11474
 },
 {
   "diagnosis": "Z44",
   "record_date": "2018-05-27",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b989",
   "patient_id": 572319515,
   "doctor_id": 11475
 },
 {
   "diagnosis": "T478X5D",
   "record_date": "2012-05-16",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b98a",
   "patient_id": 366575206,
   "doctor_id": 11476
 },
 {
   "diagnosis": "G4311",
   "record_date": "2019-07-18",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b98b",
   "patient_id": 846657317,
   "doctor_id": 11477
 },
 {
   "diagnosis": "S92423G",
   "record_date": "2000-10-18",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b98c",
   "patient_id": 25021711,
   "doctor_id": 11478
 },
 {
   "diagnosis": "T475X",
   "record_date": "2018-05-05",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b98d",
   "patient_id": 74695298,
   "doctor_id": 11479
 },
 {
   "diagnosis": "T82848S",
   "record_date": "2021-12-15",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b98e",
   "patient_id": 147212329,
   "doctor_id": 11480
 },
 {
   "diagnosis": "S7909",
   "record_date": "2005-10-17",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b98f",
   "patient_id": 811639771,
   "doctor_id": 11481
 },
 {
   "diagnosis": "M84841",
   "record_date": "2007-02-17",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b990",
   "patient_id": 331010101,
   "doctor_id": 11482
 },
 {
   "diagnosis": "F640",
   "record_date": "2019-11-17",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b991",
   "patient_id": 2297959,
   "doctor_id": 11483
 },
 {
   "diagnosis": "S86909D",
   "record_date": "2010-03-03",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b992",
   "patient_id": 934262350,
   "doctor_id": 11484
 },
 {
   "diagnosis": "N398",
   "record_date": "2021-06-28",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b993",
   "patient_id": 290461967,
   "doctor_id": 11485
 },
 {
   "diagnosis": "S12500A",
   "record_date": "2013-05-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b994",
   "patient_id": 900240510,
   "doctor_id": 11486
 },
 {
   "diagnosis": "T4793XS",
   "record_date": "2010-12-24",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b995",
   "patient_id": 973387827,
   "doctor_id": 11487
 },
 {
   "diagnosis": "S96992",
   "record_date": "2007-07-14",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b996",
   "patient_id": 681948800,
   "doctor_id": 11488
 },
 {
   "diagnosis": "S62655K",
   "record_date": "2010-07-21",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b997",
   "patient_id": 178145847,
   "doctor_id": 11489
 },
 {
   "diagnosis": "S7034",
   "record_date": "2010-12-28",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b998",
   "patient_id": 187208422,
   "doctor_id": 11490
 },
 {
   "diagnosis": "X158",
   "record_date": "2007-05-31",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b999",
   "patient_id": 341300963,
   "doctor_id": 11491
 },
 {
   "diagnosis": "Q99",
   "record_date": "2004-01-11",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b99a",
   "patient_id": 56390042,
   "doctor_id": 11492
 },
 {
   "diagnosis": "S0462XS",
   "record_date": "2010-07-01",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b99b",
   "patient_id": 590508251,
   "doctor_id": 11493
 },
 {
   "diagnosis": "S62395",
   "record_date": "2007-08-06",
   "treatment": "medication",
   "record_id": "65541575fc13ae464c22b99c",
   "patient_id": 935388170,
   "doctor_id": 11494
 },
 {
   "diagnosis": "T48904A",
   "record_date": "2012-09-17",
   "treatment": "therapy",
   "record_id": "65541575fc13ae464c22b99d",
   "patient_id": 969405591,
   "doctor_id": 11495
 },
 {
   "diagnosis": "M62471",
   "record_date": "2007-02-26",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b99e",
   "patient_id": 381131738,
   "doctor_id": 11496
 },
 {
   "diagnosis": "B508",
   "record_date": "2011-04-10",
   "treatment": "radiation",
   "record_id": "65541575fc13ae464c22b99f",
   "patient_id": 592055135,
   "doctor_id": 11497
 },
 {
   "diagnosis": "M131",
   "record_date": "2005-11-10",
   "treatment": "surgery",
   "record_id": "65541575fc13ae464c22b9a0",
   "patient_id": 599939092,
   "doctor_id": 11498
 },
 {
   "diagnosis": "B73",
   "record_date": "2016-09-29",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9a1",
   "patient_id": 207667394,
   "doctor_id": 11499
 },
 {
   "diagnosis": "H9553",
   "record_date": "2011-03-27",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9a2",
   "patient_id": 447750689,
   "doctor_id": 11500
 },
 {
   "diagnosis": "T63691D",
   "record_date": "2007-10-30",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9a3",
   "patient_id": 429411258,
   "doctor_id": 11501
 },
 {
   "diagnosis": "Y9361",
   "record_date": "2020-09-23",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9a4",
   "patient_id": 797862327,
   "doctor_id": 11502
 },
 {
   "diagnosis": "M87161",
   "record_date": "2021-04-03",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9a5",
   "patient_id": 479407967,
   "doctor_id": 11503
 },
 {
   "diagnosis": "G900",
   "record_date": "2020-07-04",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9a6",
   "patient_id": 210876543,
   "doctor_id": 11504
 },
 {
   "diagnosis": "T23029",
   "record_date": "2017-10-14",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9a7",
   "patient_id": 604515794,
   "doctor_id": 11505
 },
 {
   "diagnosis": "C9432",
   "record_date": "2008-05-19",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9a8",
   "patient_id": 989879335,
   "doctor_id": 11506
 },
 {
   "diagnosis": "T528X4D",
   "record_date": "2004-08-24",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9a9",
   "patient_id": 220735964,
   "doctor_id": 11507
 },
 {
   "diagnosis": "O3021",
   "record_date": "2001-01-10",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9aa",
   "patient_id": 808413564,
   "doctor_id": 11508
 },
 {
   "diagnosis": "O418X15",
   "record_date": "2018-12-06",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ab",
   "patient_id": 829467866,
   "doctor_id": 11509
 },
 {
   "diagnosis": "S42494D",
   "record_date": "2000-11-18",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9ac",
   "patient_id": 188513616,
   "doctor_id": 11510
 },
 {
   "diagnosis": "S83271A",
   "record_date": "2018-12-31",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ad",
   "patient_id": 901854803,
   "doctor_id": 11511
 },
 {
   "diagnosis": "S0638",
   "record_date": "2003-05-01",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ae",
   "patient_id": 491919538,
   "doctor_id": 11512
 },
 {
   "diagnosis": "T621X1D",
   "record_date": "2010-01-05",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9af",
   "patient_id": 659724148,
   "doctor_id": 11513
 },
 {
   "diagnosis": "S92321G",
   "record_date": "2011-09-26",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9b0",
   "patient_id": 145389062,
   "doctor_id": 11514
 },
 {
   "diagnosis": "W01118S",
   "record_date": "2017-07-24",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9b1",
   "patient_id": 776243688,
   "doctor_id": 11515
 },
 {
   "diagnosis": "T441X2S",
   "record_date": "2009-11-01",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9b2",
   "patient_id": 184592138,
   "doctor_id": 11516
 },
 {
   "diagnosis": "S92312P",
   "record_date": "2000-02-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9b3",
   "patient_id": 621004408,
   "doctor_id": 11517
 },
 {
   "diagnosis": "T46991",
   "record_date": "2005-12-02",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9b4",
   "patient_id": 252815187,
   "doctor_id": 11518
 },
 {
   "diagnosis": "S01551D",
   "record_date": "2008-12-20",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9b5",
   "patient_id": 545455312,
   "doctor_id": 11519
 },
 {
   "diagnosis": "S66109S",
   "record_date": "2010-08-05",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9b6",
   "patient_id": 523320726,
   "doctor_id": 11520
 },
 {
   "diagnosis": "M80842A",
   "record_date": "2014-04-13",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9b7",
   "patient_id": 598563519,
   "doctor_id": 11521
 },
 {
   "diagnosis": "L03031",
   "record_date": "2014-10-06",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9b8",
   "patient_id": 937545077,
   "doctor_id": 11522
 },
 {
   "diagnosis": "V443XXD",
   "record_date": "2003-01-19",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9b9",
   "patient_id": 99096823,
   "doctor_id": 11523
 },
 {
   "diagnosis": "S68110A",
   "record_date": "2009-12-31",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9ba",
   "patient_id": 436995951,
   "doctor_id": 11524
 },
 {
   "diagnosis": "S90569S",
   "record_date": "2020-12-12",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9bb",
   "patient_id": 42423535,
   "doctor_id": 11525
 },
 {
   "diagnosis": "T17318A",
   "record_date": "2016-09-21",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9bc",
   "patient_id": 806821599,
   "doctor_id": 11526
 },
 {
   "diagnosis": "S91022A",
   "record_date": "2018-05-14",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9bd",
   "patient_id": 428044745,
   "doctor_id": 11527
 },
 {
   "diagnosis": "S53004",
   "record_date": "2011-10-01",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9be",
   "patient_id": 585156219,
   "doctor_id": 11528
 },
 {
   "diagnosis": "S61238D",
   "record_date": "2007-08-21",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9bf",
   "patient_id": 960806565,
   "doctor_id": 11529
 },
 {
   "diagnosis": "Q2733",
   "record_date": "2022-05-28",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9c0",
   "patient_id": 376111879,
   "doctor_id": 11530
 },
 {
   "diagnosis": "I603",
   "record_date": "2001-04-11",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9c1",
   "patient_id": 246164908,
   "doctor_id": 11531
 },
 {
   "diagnosis": "W3181XA",
   "record_date": "2008-05-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9c2",
   "patient_id": 208177476,
   "doctor_id": 11532
 },
 {
   "diagnosis": "S85301S",
   "record_date": "2000-12-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9c3",
   "patient_id": 35575624,
   "doctor_id": 11533
 },
 {
   "diagnosis": "S89142S",
   "record_date": "2020-11-13",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9c4",
   "patient_id": 255011495,
   "doctor_id": 11534
 },
 {
   "diagnosis": "D8181",
   "record_date": "2003-09-16",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9c5",
   "patient_id": 204613429,
   "doctor_id": 11535
 },
 {
   "diagnosis": "V543",
   "record_date": "2017-08-01",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9c6",
   "patient_id": 3920046,
   "doctor_id": 11536
 },
 {
   "diagnosis": "S56212D",
   "record_date": "2005-02-04",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9c7",
   "patient_id": 730244038,
   "doctor_id": 11537
 },
 {
   "diagnosis": "Y9342",
   "record_date": "2005-01-09",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9c8",
   "patient_id": 907809267,
   "doctor_id": 11538
 },
 {
   "diagnosis": "M1A219",
   "record_date": "2020-01-29",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9c9",
   "patient_id": 328484013,
   "doctor_id": 11539
 },
 {
   "diagnosis": "S32008B",
   "record_date": "2005-05-11",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9ca",
   "patient_id": 154597673,
   "doctor_id": 11540
 },
 {
   "diagnosis": "Z96692",
   "record_date": "2015-07-07",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9cb",
   "patient_id": 697094684,
   "doctor_id": 11541
 },
 {
   "diagnosis": "O713",
   "record_date": "2003-04-28",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9cc",
   "patient_id": 929063617,
   "doctor_id": 11542
 },
 {
   "diagnosis": "W21220A",
   "record_date": "2013-10-10",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9cd",
   "patient_id": 603095791,
   "doctor_id": 11543
 },
 {
   "diagnosis": "T2342",
   "record_date": "2007-11-08",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ce",
   "patient_id": 333820060,
   "doctor_id": 11544
 },
 {
   "diagnosis": "T2661",
   "record_date": "2022-05-25",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9cf",
   "patient_id": 682607507,
   "doctor_id": 11545
 },
 {
   "diagnosis": "D728",
   "record_date": "2002-09-29",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9d0",
   "patient_id": 994855858,
   "doctor_id": 11546
 },
 {
   "diagnosis": "S65219S",
   "record_date": "2013-09-16",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9d1",
   "patient_id": 592374001,
   "doctor_id": 11547
 },
 {
   "diagnosis": "F918",
   "record_date": "2016-03-11",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9d2",
   "patient_id": 273416192,
   "doctor_id": 11548
 },
 {
   "diagnosis": "C84A",
   "record_date": "2022-02-02",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9d3",
   "patient_id": 364249880,
   "doctor_id": 11549
 },
 {
   "diagnosis": "S51849A",
   "record_date": "2007-01-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9d4",
   "patient_id": 273661298,
   "doctor_id": 11550
 },
 {
   "diagnosis": "S82464M",
   "record_date": "2020-09-01",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9d5",
   "patient_id": 65371072,
   "doctor_id": 11551
 },
 {
   "diagnosis": "V214XXS",
   "record_date": "2003-10-06",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9d6",
   "patient_id": 180138867,
   "doctor_id": 11302
 },
 {
   "diagnosis": "S62012A",
   "record_date": "2005-01-02",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9d7",
   "patient_id": 155537626,
   "doctor_id": 11303
 },
 {
   "diagnosis": "S63254",
   "record_date": "2000-12-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9d8",
   "patient_id": 506688784,
   "doctor_id": 11304
 },
 {
   "diagnosis": "S92056",
   "record_date": "2013-08-21",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9d9",
   "patient_id": 71090443,
   "doctor_id": 11305
 },
 {
   "diagnosis": "O3483",
   "record_date": "2013-07-29",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9da",
   "patient_id": 394352457,
   "doctor_id": 11306
 },
 {
   "diagnosis": "S6980XD",
   "record_date": "2020-11-11",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9db",
   "patient_id": 581906070,
   "doctor_id": 11307
 },
 {
   "diagnosis": "S82035",
   "record_date": "2000-12-03",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9dc",
   "patient_id": 719019779,
   "doctor_id": 11308
 },
 {
   "diagnosis": "O10011",
   "record_date": "2003-09-24",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9dd",
   "patient_id": 649261849,
   "doctor_id": 11309
 },
 {
   "diagnosis": "T477X1S",
   "record_date": "2019-03-09",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9de",
   "patient_id": 333221560,
   "doctor_id": 11310
 },
 {
   "diagnosis": "T541",
   "record_date": "2007-04-03",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9df",
   "patient_id": 372813190,
   "doctor_id": 11311
 },
 {
   "diagnosis": "M80861G",
   "record_date": "2001-01-16",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9e0",
   "patient_id": 85007457,
   "doctor_id": 11312
 },
 {
   "diagnosis": "T23771S",
   "record_date": "2018-12-22",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9e1",
   "patient_id": 388072192,
   "doctor_id": 11313
 },
 {
   "diagnosis": "S53401",
   "record_date": "2022-03-11",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9e2",
   "patient_id": 502880069,
   "doctor_id": 11314
 },
 {
   "diagnosis": "J95821",
   "record_date": "2005-08-14",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9e3",
   "patient_id": 403168081,
   "doctor_id": 11315
 },
 {
   "diagnosis": "E103212",
   "record_date": "2020-12-10",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9e4",
   "patient_id": 444020272,
   "doctor_id": 11316
 },
 {
   "diagnosis": "K08421",
   "record_date": "2011-04-13",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9e5",
   "patient_id": 643925198,
   "doctor_id": 11317
 },
 {
   "diagnosis": "M10451",
   "record_date": "2008-02-09",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9e6",
   "patient_id": 395843428,
   "doctor_id": 11318
 },
 {
   "diagnosis": "M2304",
   "record_date": "2008-01-25",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9e7",
   "patient_id": 567334355,
   "doctor_id": 11319
 },
 {
   "diagnosis": "S21329A",
   "record_date": "2022-08-21",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9e8",
   "patient_id": 388051628,
   "doctor_id": 11320
 },
 {
   "diagnosis": "F0281",
   "record_date": "2020-12-07",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9e9",
   "patient_id": 390924633,
   "doctor_id": 11321
 },
 {
   "diagnosis": "S72064J",
   "record_date": "2021-12-21",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ea",
   "patient_id": 416720452,
   "doctor_id": 11322
 },
 {
   "diagnosis": "O690XX1",
   "record_date": "2016-08-15",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9eb",
   "patient_id": 797659316,
   "doctor_id": 11323
 },
 {
   "diagnosis": "S66422D",
   "record_date": "2022-06-19",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9ec",
   "patient_id": 752517319,
   "doctor_id": 11324
 },
 {
   "diagnosis": "S42332D",
   "record_date": "2009-02-21",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9ed",
   "patient_id": 47866943,
   "doctor_id": 11325
 },
 {
   "diagnosis": "R972",
   "record_date": "2011-03-19",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9ee",
   "patient_id": 877265404,
   "doctor_id": 11326
 },
 {
   "diagnosis": "V311XXA",
   "record_date": "2015-12-10",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9ef",
   "patient_id": 228493718,
   "doctor_id": 11327
 },
 {
   "diagnosis": "V00891",
   "record_date": "2000-03-05",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9f0",
   "patient_id": 806283022,
   "doctor_id": 11328
 },
 {
   "diagnosis": "S63634",
   "record_date": "2005-07-20",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9f1",
   "patient_id": 939205933,
   "doctor_id": 11329
 },
 {
   "diagnosis": "S26020A",
   "record_date": "2020-06-04",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9f2",
   "patient_id": 257708969,
   "doctor_id": 11330
 },
 {
   "diagnosis": "S89029",
   "record_date": "2005-04-22",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9f3",
   "patient_id": 883510909,
   "doctor_id": 11331
 },
 {
   "diagnosis": "H6991",
   "record_date": "2014-09-25",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9f4",
   "patient_id": 472481729,
   "doctor_id": 11332
 },
 {
   "diagnosis": "T445X1A",
   "record_date": "2004-03-02",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22b9f5",
   "patient_id": 780975441,
   "doctor_id": 11333
 },
 {
   "diagnosis": "S3402XS",
   "record_date": "2016-08-29",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9f6",
   "patient_id": 873684294,
   "doctor_id": 11334
 },
 {
   "diagnosis": "S92405A",
   "record_date": "2017-06-14",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9f7",
   "patient_id": 318485506,
   "doctor_id": 11335
 },
 {
   "diagnosis": "H7091",
   "record_date": "2003-04-23",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9f8",
   "patient_id": 970283344,
   "doctor_id": 11336
 },
 {
   "diagnosis": "W532",
   "record_date": "2008-12-28",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9f9",
   "patient_id": 813290433,
   "doctor_id": 11337
 },
 {
   "diagnosis": "S61237D",
   "record_date": "2003-06-25",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9fa",
   "patient_id": 684321934,
   "doctor_id": 11338
 },
 {
   "diagnosis": "S60121D",
   "record_date": "2017-12-06",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22b9fb",
   "patient_id": 396824525,
   "doctor_id": 11339
 },
 {
   "diagnosis": "T368X5D",
   "record_date": "2006-01-23",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9fc",
   "patient_id": 747195788,
   "doctor_id": 11340
 },
 {
   "diagnosis": "F121",
   "record_date": "2005-03-14",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22b9fd",
   "patient_id": 738184994,
   "doctor_id": 11341
 },
 {
   "diagnosis": "S52266",
   "record_date": "2006-06-15",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9fe",
   "patient_id": 306449774,
   "doctor_id": 11342
 },
 {
   "diagnosis": "Y38811S",
   "record_date": "2022-07-03",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22b9ff",
   "patient_id": 31093536,
   "doctor_id": 11343
 },
 {
   "diagnosis": "S11035D",
   "record_date": "2007-06-28",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba00",
   "patient_id": 443159557,
   "doctor_id": 11344
 },
 {
   "diagnosis": "S43432D",
   "record_date": "2005-11-21",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba01",
   "patient_id": 505834958,
   "doctor_id": 11345
 },
 {
   "diagnosis": "T50A11S",
   "record_date": "2015-10-16",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba02",
   "patient_id": 732127954,
   "doctor_id": 11346
 },
 {
   "diagnosis": "M301",
   "record_date": "2015-04-06",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba03",
   "patient_id": 203291276,
   "doctor_id": 11347
 },
 {
   "diagnosis": "T451X4D",
   "record_date": "2022-09-08",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba04",
   "patient_id": 699496459,
   "doctor_id": 11348
 },
 {
   "diagnosis": "S63041",
   "record_date": "2016-11-15",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba05",
   "patient_id": 384857728,
   "doctor_id": 11349
 },
 {
   "diagnosis": "S82873Q",
   "record_date": "2007-12-29",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba06",
   "patient_id": 820763212,
   "doctor_id": 11350
 },
 {
   "diagnosis": "S72416N",
   "record_date": "2019-11-30",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba07",
   "patient_id": 632031678,
   "doctor_id": 11351
 },
 {
   "diagnosis": "S1243",
   "record_date": "2015-08-07",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba08",
   "patient_id": 45145366,
   "doctor_id": 11352
 },
 {
   "diagnosis": "M86062",
   "record_date": "2017-07-18",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba09",
   "patient_id": 404231713,
   "doctor_id": 11353
 },
 {
   "diagnosis": "T43011",
   "record_date": "2001-05-20",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba0a",
   "patient_id": 769193118,
   "doctor_id": 11354
 },
 {
   "diagnosis": "T7807",
   "record_date": "2006-12-09",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba0b",
   "patient_id": 858031186,
   "doctor_id": 11355
 },
 {
   "diagnosis": "S1124",
   "record_date": "2004-06-08",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba0c",
   "patient_id": 666404959,
   "doctor_id": 11356
 },
 {
   "diagnosis": "S61256",
   "record_date": "2003-12-11",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba0d",
   "patient_id": 995167361,
   "doctor_id": 11357
 },
 {
   "diagnosis": "T63634S",
   "record_date": "2007-07-07",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba0e",
   "patient_id": 969806601,
   "doctor_id": 11358
 },
 {
   "diagnosis": "S32436B",
   "record_date": "2004-02-09",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba0f",
   "patient_id": 161179524,
   "doctor_id": 11359
 },
 {
   "diagnosis": "S72051G",
   "record_date": "2019-10-31",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba10",
   "patient_id": 587742970,
   "doctor_id": 11360
 },
 {
   "diagnosis": "I70639",
   "record_date": "2001-01-26",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba11",
   "patient_id": 312156718,
   "doctor_id": 11361
 },
 {
   "diagnosis": "C9421",
   "record_date": "2014-06-19",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba12",
   "patient_id": 800183744,
   "doctor_id": 11362
 },
 {
   "diagnosis": "V4909XS",
   "record_date": "2018-07-27",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba13",
   "patient_id": 582841888,
   "doctor_id": 11363
 },
 {
   "diagnosis": "S6420",
   "record_date": "2021-09-09",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba14",
   "patient_id": 5567131,
   "doctor_id": 11364
 },
 {
   "diagnosis": "S32302",
   "record_date": "2019-01-08",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba15",
   "patient_id": 505693890,
   "doctor_id": 11365
 },
 {
   "diagnosis": "S42201K",
   "record_date": "2005-09-25",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba16",
   "patient_id": 791250786,
   "doctor_id": 11366
 },
 {
   "diagnosis": "T24409D",
   "record_date": "2014-08-01",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba17",
   "patient_id": 130571109,
   "doctor_id": 11367
 },
 {
   "diagnosis": "S59902A",
   "record_date": "2015-10-07",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba18",
   "patient_id": 875417523,
   "doctor_id": 11368
 },
 {
   "diagnosis": "S2600XD",
   "record_date": "2014-04-03",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba19",
   "patient_id": 842734890,
   "doctor_id": 11369
 },
 {
   "diagnosis": "V8623XA",
   "record_date": "2014-07-19",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba1a",
   "patient_id": 533119949,
   "doctor_id": 11370
 },
 {
   "diagnosis": "T50A23A",
   "record_date": "2018-01-27",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba1b",
   "patient_id": 240344681,
   "doctor_id": 11371
 },
 {
   "diagnosis": "M86559",
   "record_date": "2003-09-27",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba1c",
   "patient_id": 966324907,
   "doctor_id": 11372
 },
 {
   "diagnosis": "S1181XS",
   "record_date": "2008-03-19",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba1d",
   "patient_id": 267175698,
   "doctor_id": 11373
 },
 {
   "diagnosis": "W22041D",
   "record_date": "2001-04-16",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba1e",
   "patient_id": 789751037,
   "doctor_id": 11374
 },
 {
   "diagnosis": "W2203XA",
   "record_date": "2014-12-31",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba1f",
   "patient_id": 864220310,
   "doctor_id": 11375
 },
 {
   "diagnosis": "S52522P",
   "record_date": "2018-10-02",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba20",
   "patient_id": 734341774,
   "doctor_id": 11376
 },
 {
   "diagnosis": "S59811A",
   "record_date": "2001-04-20",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba21",
   "patient_id": 864719756,
   "doctor_id": 11377
 },
 {
   "diagnosis": "M84443",
   "record_date": "2006-05-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba22",
   "patient_id": 697049992,
   "doctor_id": 11378
 },
 {
   "diagnosis": "H33033",
   "record_date": "2009-03-25",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba23",
   "patient_id": 187125560,
   "doctor_id": 11379
 },
 {
   "diagnosis": "X100",
   "record_date": "2008-06-21",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba24",
   "patient_id": 28045487,
   "doctor_id": 11380
 },
 {
   "diagnosis": "T2126XS",
   "record_date": "2021-06-15",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba25",
   "patient_id": 558447165,
   "doctor_id": 11381
 },
 {
   "diagnosis": "Y92411",
   "record_date": "2004-10-17",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba26",
   "patient_id": 908185378,
   "doctor_id": 11382
 },
 {
   "diagnosis": "S32131",
   "record_date": "2003-08-03",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba27",
   "patient_id": 495424841,
   "doctor_id": 11383
 },
 {
   "diagnosis": "V80",
   "record_date": "2004-12-31",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba28",
   "patient_id": 752047936,
   "doctor_id": 11384
 },
 {
   "diagnosis": "K8045",
   "record_date": "2015-03-29",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba29",
   "patient_id": 313519494,
   "doctor_id": 11385
 },
 {
   "diagnosis": "T22729S",
   "record_date": "2021-07-04",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba2a",
   "patient_id": 520593545,
   "doctor_id": 11386
 },
 {
   "diagnosis": "T56891",
   "record_date": "2014-04-03",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba2b",
   "patient_id": 110191095,
   "doctor_id": 11387
 },
 {
   "diagnosis": "S31629",
   "record_date": "2004-02-03",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba2c",
   "patient_id": 676935066,
   "doctor_id": 11388
 },
 {
   "diagnosis": "M4145",
   "record_date": "2016-06-05",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba2d",
   "patient_id": 61612635,
   "doctor_id": 11389
 },
 {
   "diagnosis": "S72126J",
   "record_date": "2020-10-18",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba2e",
   "patient_id": 760052236,
   "doctor_id": 11390
 },
 {
   "diagnosis": "M05142",
   "record_date": "2015-08-10",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba2f",
   "patient_id": 758646284,
   "doctor_id": 11391
 },
 {
   "diagnosis": "V260XXS",
   "record_date": "2006-07-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba30",
   "patient_id": 223365582,
   "doctor_id": 11392
 },
 {
   "diagnosis": "T17518A",
   "record_date": "2020-07-09",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba31",
   "patient_id": 715222613,
   "doctor_id": 11393
 },
 {
   "diagnosis": "T2151XD",
   "record_date": "2019-07-19",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba32",
   "patient_id": 974261172,
   "doctor_id": 11394
 },
 {
   "diagnosis": "K0389",
   "record_date": "2015-05-30",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba33",
   "patient_id": 455378373,
   "doctor_id": 11395
 },
 {
   "diagnosis": "S12631D",
   "record_date": "2003-12-22",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba34",
   "patient_id": 993573279,
   "doctor_id": 11396
 },
 {
   "diagnosis": "S081",
   "record_date": "2017-06-25",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba35",
   "patient_id": 429524030,
   "doctor_id": 11397
 },
 {
   "diagnosis": "H18711",
   "record_date": "2005-10-23",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba36",
   "patient_id": 503292829,
   "doctor_id": 11398
 },
 {
   "diagnosis": "M84375P",
   "record_date": "2008-10-15",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba37",
   "patient_id": 526234604,
   "doctor_id": 11399
 },
 {
   "diagnosis": "M05032",
   "record_date": "2002-05-14",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba38",
   "patient_id": 389263482,
   "doctor_id": 11400
 },
 {
   "diagnosis": "M87112",
   "record_date": "2002-09-03",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba39",
   "patient_id": 423750746,
   "doctor_id": 11401
 },
 {
   "diagnosis": "S60945D",
   "record_date": "2004-12-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba3a",
   "patient_id": 167149706,
   "doctor_id": 11402
 },
 {
   "diagnosis": "S92315G",
   "record_date": "2010-06-22",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba3b",
   "patient_id": 725148885,
   "doctor_id": 11403
 },
 {
   "diagnosis": "S99229D",
   "record_date": "2001-02-28",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba3c",
   "patient_id": 271367290,
   "doctor_id": 11404
 },
 {
   "diagnosis": "S12250S",
   "record_date": "2013-11-12",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba3d",
   "patient_id": 360920760,
   "doctor_id": 11405
 },
 {
   "diagnosis": "S06343D",
   "record_date": "2007-05-18",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba3e",
   "patient_id": 351155334,
   "doctor_id": 11406
 },
 {
   "diagnosis": "S89302P",
   "record_date": "2001-02-23",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba3f",
   "patient_id": 398053484,
   "doctor_id": 11407
 },
 {
   "diagnosis": "T17318A",
   "record_date": "2006-10-31",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba40",
   "patient_id": 446219873,
   "doctor_id": 11408
 },
 {
   "diagnosis": "S22001G",
   "record_date": "2021-05-17",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba41",
   "patient_id": 610671700,
   "doctor_id": 11409
 },
 {
   "diagnosis": "G733",
   "record_date": "2004-10-03",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba42",
   "patient_id": 62402667,
   "doctor_id": 11410
 },
 {
   "diagnosis": "S56112D",
   "record_date": "2010-09-11",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba43",
   "patient_id": 476321216,
   "doctor_id": 11411
 },
 {
   "diagnosis": "M84652K",
   "record_date": "2013-12-15",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba44",
   "patient_id": 680145556,
   "doctor_id": 11412
 },
 {
   "diagnosis": "C9292",
   "record_date": "2003-02-26",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba45",
   "patient_id": 636520697,
   "doctor_id": 11413
 },
 {
   "diagnosis": "M1003",
   "record_date": "2020-09-03",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba46",
   "patient_id": 829420116,
   "doctor_id": 11414
 },
 {
   "diagnosis": "T492X1A",
   "record_date": "2021-03-05",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba47",
   "patient_id": 505455481,
   "doctor_id": 11415
 },
 {
   "diagnosis": "S72134G",
   "record_date": "2011-06-27",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba48",
   "patient_id": 348420494,
   "doctor_id": 11416
 },
 {
   "diagnosis": "S644",
   "record_date": "2017-11-19",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba49",
   "patient_id": 677253395,
   "doctor_id": 11417
 },
 {
   "diagnosis": "T444X6",
   "record_date": "2003-12-22",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba4a",
   "patient_id": 835227317,
   "doctor_id": 11418
 },
 {
   "diagnosis": "S59241P",
   "record_date": "2022-07-08",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba4b",
   "patient_id": 338410930,
   "doctor_id": 11419
 },
 {
   "diagnosis": "O42919",
   "record_date": "2002-02-21",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba4c",
   "patient_id": 82516801,
   "doctor_id": 11420
 },
 {
   "diagnosis": "S82864N",
   "record_date": "2002-11-12",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba4d",
   "patient_id": 490636288,
   "doctor_id": 11421
 },
 {
   "diagnosis": "S42412D",
   "record_date": "2017-05-31",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba4e",
   "patient_id": 830911448,
   "doctor_id": 11422
 },
 {
   "diagnosis": "V0312XD",
   "record_date": "2018-11-29",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba4f",
   "patient_id": 307020250,
   "doctor_id": 11423
 },
 {
   "diagnosis": "S42264D",
   "record_date": "2004-11-27",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba50",
   "patient_id": 653344568,
   "doctor_id": 11424
 },
 {
   "diagnosis": "H47323",
   "record_date": "2003-09-25",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba51",
   "patient_id": 803974891,
   "doctor_id": 11425
 },
 {
   "diagnosis": "T84619S",
   "record_date": "2004-04-12",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba52",
   "patient_id": 319052571,
   "doctor_id": 11426
 },
 {
   "diagnosis": "S52361Q",
   "record_date": "2001-04-21",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba53",
   "patient_id": 456625759,
   "doctor_id": 11427
 },
 {
   "diagnosis": "B9681",
   "record_date": "2015-02-05",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba54",
   "patient_id": 286802785,
   "doctor_id": 11428
 },
 {
   "diagnosis": "M25374",
   "record_date": "2022-05-07",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba55",
   "patient_id": 160595895,
   "doctor_id": 11429
 },
 {
   "diagnosis": "Y383X",
   "record_date": "2020-03-07",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba56",
   "patient_id": 394950834,
   "doctor_id": 11430
 },
 {
   "diagnosis": "O032",
   "record_date": "2008-01-09",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba57",
   "patient_id": 664878310,
   "doctor_id": 11431
 },
 {
   "diagnosis": "M21122",
   "record_date": "2012-04-24",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba58",
   "patient_id": 411640905,
   "doctor_id": 11432
 },
 {
   "diagnosis": "S92141P",
   "record_date": "2017-05-21",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba59",
   "patient_id": 766949552,
   "doctor_id": 11433
 },
 {
   "diagnosis": "I96",
   "record_date": "2015-06-18",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba5a",
   "patient_id": 136525515,
   "doctor_id": 11434
 },
 {
   "diagnosis": "D211",
   "record_date": "2014-01-07",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba5b",
   "patient_id": 629360169,
   "doctor_id": 11435
 },
 {
   "diagnosis": "A772",
   "record_date": "2016-10-16",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba5c",
   "patient_id": 978079253,
   "doctor_id": 11436
 },
 {
   "diagnosis": "M84650D",
   "record_date": "2000-05-28",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba5d",
   "patient_id": 740012748,
   "doctor_id": 11437
 },
 {
   "diagnosis": "S14151D",
   "record_date": "2017-05-28",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba5e",
   "patient_id": 634565899,
   "doctor_id": 11438
 },
 {
   "diagnosis": "S2742",
   "record_date": "2016-07-18",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba5f",
   "patient_id": 170169666,
   "doctor_id": 11439
 },
 {
   "diagnosis": "V00181",
   "record_date": "2022-05-29",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba60",
   "patient_id": 575653879,
   "doctor_id": 11440
 },
 {
   "diagnosis": "R454",
   "record_date": "2010-06-09",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba61",
   "patient_id": 613797911,
   "doctor_id": 11441
 },
 {
   "diagnosis": "S61119D",
   "record_date": "2010-04-23",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba62",
   "patient_id": 805570965,
   "doctor_id": 11442
 },
 {
   "diagnosis": "S658",
   "record_date": "2020-06-29",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba63",
   "patient_id": 533980153,
   "doctor_id": 11443
 },
 {
   "diagnosis": "W55",
   "record_date": "2003-04-24",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba64",
   "patient_id": 410895481,
   "doctor_id": 11444
 },
 {
   "diagnosis": "S92919G",
   "record_date": "2014-08-12",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba65",
   "patient_id": 172199378,
   "doctor_id": 11445
 },
 {
   "diagnosis": "W4903",
   "record_date": "2022-11-12",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba66",
   "patient_id": 42603162,
   "doctor_id": 11446
 },
 {
   "diagnosis": "T85818S",
   "record_date": "2005-03-01",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba67",
   "patient_id": 457685546,
   "doctor_id": 11447
 },
 {
   "diagnosis": "S5400",
   "record_date": "2001-11-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba68",
   "patient_id": 737188999,
   "doctor_id": 11448
 },
 {
   "diagnosis": "S80811S",
   "record_date": "2001-07-24",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba69",
   "patient_id": 941996225,
   "doctor_id": 11449
 },
 {
   "diagnosis": "T17518D",
   "record_date": "2004-08-05",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba6a",
   "patient_id": 334830018,
   "doctor_id": 11450
 },
 {
   "diagnosis": "S90841",
   "record_date": "2022-10-13",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba6b",
   "patient_id": 827834808,
   "doctor_id": 11451
 },
 {
   "diagnosis": "I70702",
   "record_date": "2020-10-06",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba6c",
   "patient_id": 82428620,
   "doctor_id": 11452
 },
 {
   "diagnosis": "M60231",
   "record_date": "2009-01-27",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba6d",
   "patient_id": 920397895,
   "doctor_id": 11453
 },
 {
   "diagnosis": "S62399G",
   "record_date": "2004-04-14",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba6e",
   "patient_id": 598094261,
   "doctor_id": 11454
 },
 {
   "diagnosis": "T83032D",
   "record_date": "2021-07-08",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba6f",
   "patient_id": 710298268,
   "doctor_id": 11455
 },
 {
   "diagnosis": "T628X2",
   "record_date": "2006-11-18",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba70",
   "patient_id": 544336421,
   "doctor_id": 11456
 },
 {
   "diagnosis": "S59191K",
   "record_date": "2006-09-14",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba71",
   "patient_id": 701693862,
   "doctor_id": 11457
 },
 {
   "diagnosis": "M9057",
   "record_date": "2003-09-18",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba72",
   "patient_id": 617236500,
   "doctor_id": 11458
 },
 {
   "diagnosis": "V8633XA",
   "record_date": "2019-09-18",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba73",
   "patient_id": 426606480,
   "doctor_id": 11459
 },
 {
   "diagnosis": "M675",
   "record_date": "2015-01-14",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba74",
   "patient_id": 954134662,
   "doctor_id": 11460
 },
 {
   "diagnosis": "N4889",
   "record_date": "2017-06-06",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba75",
   "patient_id": 970865766,
   "doctor_id": 11461
 },
 {
   "diagnosis": "V610",
   "record_date": "2018-11-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba76",
   "patient_id": 483638406,
   "doctor_id": 11462
 },
 {
   "diagnosis": "T85510A",
   "record_date": "2000-01-01",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba77",
   "patient_id": 705580317,
   "doctor_id": 11463
 },
 {
   "diagnosis": "Y36011S",
   "record_date": "2022-07-05",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba78",
   "patient_id": 799059055,
   "doctor_id": 11464
 },
 {
   "diagnosis": "X18XXXA",
   "record_date": "2010-02-22",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba79",
   "patient_id": 17338453,
   "doctor_id": 11465
 },
 {
   "diagnosis": "S7221XH",
   "record_date": "2007-11-19",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba7a",
   "patient_id": 377306027,
   "doctor_id": 11466
 },
 {
   "diagnosis": "T461X6A",
   "record_date": "2001-11-21",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba7b",
   "patient_id": 588625438,
   "doctor_id": 11467
 },
 {
   "diagnosis": "H70001",
   "record_date": "2016-11-24",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba7c",
   "patient_id": 858545236,
   "doctor_id": 11468
 },
 {
   "diagnosis": "T48291D",
   "record_date": "2003-08-27",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba7d",
   "patient_id": 207627194,
   "doctor_id": 11469
 },
 {
   "diagnosis": "L97403",
   "record_date": "2020-06-30",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba7e",
   "patient_id": 886836391,
   "doctor_id": 11470
 },
 {
   "diagnosis": "T323",
   "record_date": "2007-02-05",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba7f",
   "patient_id": 357098270,
   "doctor_id": 11471
 },
 {
   "diagnosis": "O99113",
   "record_date": "2022-09-26",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba80",
   "patient_id": 749114152,
   "doctor_id": 11472
 },
 {
   "diagnosis": "E7404",
   "record_date": "2006-05-04",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba81",
   "patient_id": 642128006,
   "doctor_id": 11473
 },
 {
   "diagnosis": "S42493S",
   "record_date": "2003-07-18",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba82",
   "patient_id": 54104016,
   "doctor_id": 11474
 },
 {
   "diagnosis": "S6103",
   "record_date": "2000-11-13",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba83",
   "patient_id": 65340054,
   "doctor_id": 11475
 },
 {
   "diagnosis": "S32059D",
   "record_date": "2004-01-31",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba84",
   "patient_id": 127514732,
   "doctor_id": 11476
 },
 {
   "diagnosis": "S55809",
   "record_date": "2022-03-19",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba85",
   "patient_id": 603227507,
   "doctor_id": 11477
 },
 {
   "diagnosis": "T82531",
   "record_date": "2011-06-30",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba86",
   "patient_id": 793312476,
   "doctor_id": 11478
 },
 {
   "diagnosis": "E70329",
   "record_date": "2018-12-16",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba87",
   "patient_id": 926837897,
   "doctor_id": 11479
 },
 {
   "diagnosis": "M13",
   "record_date": "2014-11-20",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba88",
   "patient_id": 651066349,
   "doctor_id": 11480
 },
 {
   "diagnosis": "S72421H",
   "record_date": "2007-11-01",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba89",
   "patient_id": 738850041,
   "doctor_id": 11481
 },
 {
   "diagnosis": "O693XX9",
   "record_date": "2022-10-10",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba8a",
   "patient_id": 905531458,
   "doctor_id": 11482
 },
 {
   "diagnosis": "S73046",
   "record_date": "2017-03-28",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba8b",
   "patient_id": 202945400,
   "doctor_id": 11483
 },
 {
   "diagnosis": "E13354",
   "record_date": "2013-06-26",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba8c",
   "patient_id": 948692529,
   "doctor_id": 11484
 },
 {
   "diagnosis": "S090XXS",
   "record_date": "2001-04-21",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba8d",
   "patient_id": 954112687,
   "doctor_id": 11485
 },
 {
   "diagnosis": "X771XXA",
   "record_date": "2012-05-05",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba8e",
   "patient_id": 353318290,
   "doctor_id": 11486
 },
 {
   "diagnosis": "R8569",
   "record_date": "2018-09-29",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba8f",
   "patient_id": 38612144,
   "doctor_id": 11487
 },
 {
   "diagnosis": "S62313B",
   "record_date": "2001-06-27",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba90",
   "patient_id": 878198207,
   "doctor_id": 11488
 },
 {
   "diagnosis": "I06",
   "record_date": "2021-05-10",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba91",
   "patient_id": 30260222,
   "doctor_id": 11489
 },
 {
   "diagnosis": "S92135S",
   "record_date": "2017-04-04",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba92",
   "patient_id": 416034690,
   "doctor_id": 11490
 },
 {
   "diagnosis": "F4529",
   "record_date": "2008-02-08",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba93",
   "patient_id": 865213684,
   "doctor_id": 11491
 },
 {
   "diagnosis": "L410",
   "record_date": "2014-11-27",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba94",
   "patient_id": 693441454,
   "doctor_id": 11492
 },
 {
   "diagnosis": "R000",
   "record_date": "2018-03-25",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba95",
   "patient_id": 595184482,
   "doctor_id": 11493
 },
 {
   "diagnosis": "S62365B",
   "record_date": "2001-01-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba96",
   "patient_id": 36541113,
   "doctor_id": 11494
 },
 {
   "diagnosis": "S72025E",
   "record_date": "2007-04-16",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba97",
   "patient_id": 267413981,
   "doctor_id": 11495
 },
 {
   "diagnosis": "V9338",
   "record_date": "2003-04-08",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22ba98",
   "patient_id": 118145479,
   "doctor_id": 11496
 },
 {
   "diagnosis": "S82012P",
   "record_date": "2012-11-07",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba99",
   "patient_id": 56538788,
   "doctor_id": 11497
 },
 {
   "diagnosis": "C780",
   "record_date": "2015-03-29",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba9a",
   "patient_id": 631870869,
   "doctor_id": 11498
 },
 {
   "diagnosis": "S62647A",
   "record_date": "2022-08-28",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba9b",
   "patient_id": 627832947,
   "doctor_id": 11499
 },
 {
   "diagnosis": "M21831",
   "record_date": "2004-11-15",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22ba9c",
   "patient_id": 963998441,
   "doctor_id": 11500
 },
 {
   "diagnosis": "S72425F",
   "record_date": "2018-01-31",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba9d",
   "patient_id": 783858327,
   "doctor_id": 11501
 },
 {
   "diagnosis": "T2680XA",
   "record_date": "2000-09-15",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22ba9e",
   "patient_id": 787822005,
   "doctor_id": 11502
 },
 {
   "diagnosis": "R29707",
   "record_date": "2009-06-27",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22ba9f",
   "patient_id": 751031194,
   "doctor_id": 11503
 },
 {
   "diagnosis": "S52124H",
   "record_date": "2019-05-26",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baa0",
   "patient_id": 655100135,
   "doctor_id": 11504
 },
 {
   "diagnosis": "T84622S",
   "record_date": "2009-09-29",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baa1",
   "patient_id": 668110119,
   "doctor_id": 11505
 },
 {
   "diagnosis": "T63334S",
   "record_date": "2000-06-12",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baa2",
   "patient_id": 686409607,
   "doctor_id": 11506
 },
 {
   "diagnosis": "S99012D",
   "record_date": "2017-12-14",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baa3",
   "patient_id": 759161476,
   "doctor_id": 11507
 },
 {
   "diagnosis": "S83096D",
   "record_date": "2008-04-20",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baa4",
   "patient_id": 569000498,
   "doctor_id": 11508
 },
 {
   "diagnosis": "T570X2D",
   "record_date": "2002-03-21",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22baa5",
   "patient_id": 53392125,
   "doctor_id": 11509
 },
 {
   "diagnosis": "M830",
   "record_date": "2005-01-21",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baa6",
   "patient_id": 355821067,
   "doctor_id": 11510
 },
 {
   "diagnosis": "I012",
   "record_date": "2010-10-24",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22baa7",
   "patient_id": 190058585,
   "doctor_id": 11511
 },
 {
   "diagnosis": "T63623S",
   "record_date": "2016-10-08",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baa8",
   "patient_id": 795916875,
   "doctor_id": 11512
 },
 {
   "diagnosis": "S82142",
   "record_date": "2004-01-07",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baa9",
   "patient_id": 904946044,
   "doctor_id": 11513
 },
 {
   "diagnosis": "W5329XD",
   "record_date": "2011-10-29",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baaa",
   "patient_id": 750457543,
   "doctor_id": 11514
 },
 {
   "diagnosis": "V8603XD",
   "record_date": "2002-08-14",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22baab",
   "patient_id": 911206717,
   "doctor_id": 11515
 },
 {
   "diagnosis": "T59812D",
   "record_date": "2018-08-16",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22baac",
   "patient_id": 978085718,
   "doctor_id": 11516
 },
 {
   "diagnosis": "S82002Q",
   "record_date": "2005-10-06",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baad",
   "patient_id": 772647129,
   "doctor_id": 11517
 },
 {
   "diagnosis": "S35311A",
   "record_date": "2013-04-29",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22baae",
   "patient_id": 644204092,
   "doctor_id": 11518
 },
 {
   "diagnosis": "T50992D",
   "record_date": "2022-07-01",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22baaf",
   "patient_id": 927165195,
   "doctor_id": 11519
 },
 {
   "diagnosis": "T85121S",
   "record_date": "2006-05-16",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab0",
   "patient_id": 418668646,
   "doctor_id": 11520
 },
 {
   "diagnosis": "S82141H",
   "record_date": "2017-01-27",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab1",
   "patient_id": 400366873,
   "doctor_id": 11521
 },
 {
   "diagnosis": "S42202S",
   "record_date": "2011-12-19",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab2",
   "patient_id": 604383105,
   "doctor_id": 11522
 },
 {
   "diagnosis": "O3132X3",
   "record_date": "2016-02-18",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bab3",
   "patient_id": 786646728,
   "doctor_id": 11523
 },
 {
   "diagnosis": "M61211",
   "record_date": "2008-06-24",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab4",
   "patient_id": 747988027,
   "doctor_id": 11524
 },
 {
   "diagnosis": "S86209",
   "record_date": "2012-09-25",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab5",
   "patient_id": 515946802,
   "doctor_id": 11525
 },
 {
   "diagnosis": "S82875M",
   "record_date": "2015-07-27",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bab6",
   "patient_id": 421660732,
   "doctor_id": 11526
 },
 {
   "diagnosis": "S82812G",
   "record_date": "2008-09-14",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bab7",
   "patient_id": 123224346,
   "doctor_id": 11527
 },
 {
   "diagnosis": "T63691S",
   "record_date": "2014-07-31",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab8",
   "patient_id": 298641329,
   "doctor_id": 11528
 },
 {
   "diagnosis": "Y0889XA",
   "record_date": "2006-02-05",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bab9",
   "patient_id": 544608506,
   "doctor_id": 11529
 },
 {
   "diagnosis": "S30853D",
   "record_date": "2008-05-09",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baba",
   "patient_id": 305845556,
   "doctor_id": 11530
 },
 {
   "diagnosis": "O46012",
   "record_date": "2019-07-21",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22babb",
   "patient_id": 635180616,
   "doctor_id": 11531
 },
 {
   "diagnosis": "S31119S",
   "record_date": "2001-11-21",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22babc",
   "patient_id": 254289496,
   "doctor_id": 11532
 },
 {
   "diagnosis": "W3312XS",
   "record_date": "2015-01-29",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22babd",
   "patient_id": 744132499,
   "doctor_id": 11533
 },
 {
   "diagnosis": "F1328",
   "record_date": "2001-11-11",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22babe",
   "patient_id": 838486941,
   "doctor_id": 11534
 },
 {
   "diagnosis": "S72344R",
   "record_date": "2011-05-31",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22babf",
   "patient_id": 14003406,
   "doctor_id": 11535
 },
 {
   "diagnosis": "S32001K",
   "record_date": "2015-01-04",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bac0",
   "patient_id": 2232128,
   "doctor_id": 11536
 },
 {
   "diagnosis": "S82091E",
   "record_date": "2014-02-17",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bac1",
   "patient_id": 937385430,
   "doctor_id": 11537
 },
 {
   "diagnosis": "S62650B",
   "record_date": "2009-09-18",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bac2",
   "patient_id": 568706422,
   "doctor_id": 11538
 },
 {
   "diagnosis": "S66409A",
   "record_date": "2011-06-05",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bac3",
   "patient_id": 872187881,
   "doctor_id": 11539
 },
 {
   "diagnosis": "V110XXA",
   "record_date": "2009-03-13",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bac4",
   "patient_id": 216523313,
   "doctor_id": 11540
 },
 {
   "diagnosis": "Z331",
   "record_date": "2014-12-20",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bac5",
   "patient_id": 84624609,
   "doctor_id": 11541
 },
 {
   "diagnosis": "S67191A",
   "record_date": "2000-09-10",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22bac6",
   "patient_id": 335106388,
   "doctor_id": 11542
 },
 {
   "diagnosis": "H47032",
   "record_date": "2014-10-13",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22bac7",
   "patient_id": 878716595,
   "doctor_id": 11543
 },
 {
   "diagnosis": "T17320S",
   "record_date": "2010-05-13",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22bac8",
   "patient_id": 666832461,
   "doctor_id": 11544
 },
 {
   "diagnosis": "I70393",
   "record_date": "2021-04-13",
   "treatment": "radiation",
   "record_id": "65541576fc13ae464c22bac9",
   "patient_id": 710642619,
   "doctor_id": 11545
 },
 {
   "diagnosis": "T2009XS",
   "record_date": "2001-09-11",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22baca",
   "patient_id": 831776062,
   "doctor_id": 11546
 },
 {
   "diagnosis": "S010",
   "record_date": "2020-09-22",
   "treatment": "therapy",
   "record_id": "65541576fc13ae464c22bacb",
   "patient_id": 786222900,
   "doctor_id": 11547
 },
 {
   "diagnosis": "S63417S",
   "record_date": "2005-12-09",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22bacc",
   "patient_id": 515400834,
   "doctor_id": 11548
 },
 {
   "diagnosis": "Y9313",
   "record_date": "2017-11-03",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22bacd",
   "patient_id": 952690846,
   "doctor_id": 11549
 },
 {
   "diagnosis": "H0202",
   "record_date": "2019-06-17",
   "treatment": "surgery",
   "record_id": "65541576fc13ae464c22bace",
   "patient_id": 841533027,
   "doctor_id": 11550
 },
 {
   "diagnosis": "S62162D",
   "record_date": "2000-04-20",
   "treatment": "medication",
   "record_id": "65541576fc13ae464c22bacf",
   "patient_id": 654504908,
   "doctor_id": 11551
 }
]);

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for insertion: " + timeTaken + " milliseconds");