


// Record the start time
var startTime = new Date();

// Run the query and capture the results
var queryResults = db.Doctor.distinct("specialty");

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the query results
print("Query Results:");
printjson(queryResults);

// Print the time taken
print("Query time: " + timeTaken + " milliseconds");
