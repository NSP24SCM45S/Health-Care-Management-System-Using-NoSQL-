

var startTime = new Date();

db.Patient.update(
   { },
   { $set: { new_field: "default_value" } },
   { multi: true }
);

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for adding a new column: " + timeTaken + " milliseconds");