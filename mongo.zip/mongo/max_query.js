// Record the start time
var startTime = new Date();

// Run the aggregate query and capture the results
var aggregationPipeline = [
  {
    $group: {
      _id: null,
      Maxcoverage: { $max: "$coverage_limit" }
    }
  }
];

var aggregateResults = db.Insurance.aggregate(aggregationPipeline).toArray();

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print only the max coverage limit
if (aggregateResults.length > 0) {
  print("Max Coverage Limit: " + aggregateResults[0].Maxcoverage);
} else {
  print("No results found.");
}

// Print the time taken
print("Query time: " + timeTaken + " milliseconds");
