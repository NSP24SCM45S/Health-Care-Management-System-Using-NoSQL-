


// Record the start time
var startTime = new Date();

// Run the query and capture the results
var queryResults = db.Billing_information.find({ insurance_provider: 'Cigna' }).toArray();

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the query results
print("Query Results:");
printjson(queryResults);

// Print the time taken
print("Query time: " + timeTaken + " milliseconds");
