

var startTime = new Date();

var patient_id = 619486079 ;

db.Patient.updateOne(
  { "patient_id": patient_id },
  { $set: { "last_name": "Keppler" } }
);


// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for single record updation: " + timeTaken + " milliseconds");