// Record the start time
var startTime = new Date();

// Your insertion operation with the current date as admissionDate
db.Prescription.insertMany([
 {
   "prescription_id": 700430481,
   "prescription_date": "2023-03-15",
   "medication": "Western Juniper",
   "drug_brand": "Western Juniper",
   "patient_id": 619486079,
   "doctor_id": 11302
 },
 {
   "prescription_id": 36469498,
   "prescription_date": "2023-06-17",
   "medication": "GLIPIZIDE",
   "drug_brand": "GLIPIZIDE",
   "patient_id": 892708688,
   "doctor_id": 11303
 },
 {
   "prescription_id": 436361209,
   "prescription_date": "2023-01-03",
   "medication": "Promethazine Hydrochloride",
   "drug_brand": "Promethazine Hydrochloride",
   "patient_id": 22195242,
   "doctor_id": 11304
 },
 {
   "prescription_id": 953406535,
   "prescription_date": "2022-11-17",
   "medication": "Dermatophagoides pteronyssinus",
   "drug_brand": "STANDARDIZED MITE D PTERONYSSINUS",
   "patient_id": 668808523,
   "doctor_id": 11305
 },
 {
   "prescription_id": 849581498,
   "prescription_date": "2023-03-17",
   "medication": "Mirtazapine",
   "drug_brand": "Mirtazapine",
   "patient_id": 467612663,
   "doctor_id": 11306
 },
 {
   "prescription_id": 372505088,
   "prescription_date": "2023-09-01",
   "medication": "avobenzone and homosalate and octisalate and octocrylene and oxybenzone",
   "drug_brand": "Hope In A Jar SPF 25",
   "patient_id": 61715603,
   "doctor_id": 11307
 },
 {
   "prescription_id": 288929556,
   "prescription_date": "2023-10-14",
   "medication": "Octinoxate 7.5%",
   "drug_brand": "Sei Bella Age-Defying Liquid Foundation",
   "patient_id": 412618858,
   "doctor_id": 11308
 },
 {
   "prescription_id": 22901179,
   "prescription_date": "2022-11-17",
   "medication": "Avobenzone, Octisalate, and Octocrylene",
   "drug_brand": "SolMate",
   "patient_id": 947226484,
   "doctor_id": 11309
 },
 {
   "prescription_id": 913043778,
   "prescription_date": "2023-01-06",
   "medication": "ZINC OXIDE",
   "drug_brand": "Sheer Cover Mineral Foundation",
   "patient_id": 801335117,
   "doctor_id": 11310
 },
 {
   "prescription_id": 857479652,
   "prescription_date": "2023-09-09",
   "medication": "OCTINOXATE, OCTOCRYLENE, and TITANIUM DIOXIDE",
   "drug_brand": "SHISEIDO SHEER AND PERFECT COMPACT (REFILL)",
   "patient_id": 737229538,
   "doctor_id": 11311
 },
 {
   "prescription_id": 378187559,
   "prescription_date": "2023-06-11",
   "medication": "TITANIUM DIOXIDE, ZINC OXIDE and OCTINOXATE",
   "drug_brand": "SENSAI TRIPLE TOUCH COMPACT TC02",
   "patient_id": 636959196,
   "doctor_id": 11312
 },
 {
   "prescription_id": 380802288,
   "prescription_date": "2023-06-23",
   "medication": "Amlodipine Besylate",
   "drug_brand": "Amlodipine Besylate",
   "patient_id": 299616270,
   "doctor_id": 11313
 },
 {
   "prescription_id": 863016178,
   "prescription_date": "2023-05-24",
   "medication": "Alianthus, Ana barbariae, Arsenicum album, Byronia, Eucalyptus, Eupatorium perfoliatum, Gelsemium, Glycerinum, Influenzinum, Mercurius vivus, Phytolacca, Sticta pulmonaria",
   "drug_brand": "Triple Flu Defense",
   "patient_id": 998132204,
   "doctor_id": 11314
 },
 {
   "prescription_id": 25323128,
   "prescription_date": "2023-10-13",
   "medication": "Pseudoephedrine Hydrochloride",
   "drug_brand": "Pseudoephedrine Hydrochloride",
   "patient_id": 676991253,
   "doctor_id": 11315
 },
 {
   "prescription_id": 111072633,
   "prescription_date": "2022-12-26",
   "medication": "OCTINOXATE",
   "drug_brand": "Rouge Dior 640 Soft Pink Serum",
   "patient_id": 535659829,
   "doctor_id": 11316
 },
 {
   "prescription_id": 152569926,
   "prescription_date": "2023-08-22",
   "medication": "Allantoin",
   "drug_brand": "Herbal Skin Toner",
   "patient_id": 997566304,
   "doctor_id": 11317
 },
 {
   "prescription_id": 854709833,
   "prescription_date": "2023-04-30",
   "medication": "hyoscyamine sulfate",
   "drug_brand": "Levsin",
   "patient_id": 518353983,
   "doctor_id": 11318
 },
 {
   "prescription_id": 218003660,
   "prescription_date": "2022-11-23",
   "medication": "Sodium Chloride, Sodium Lactate, Potassium Chloride, Calcium Chloride",
   "drug_brand": "Lactated Ringers",
   "patient_id": 973884491,
   "doctor_id": 11319
 },
 {
   "prescription_id": 199312587,
   "prescription_date": "2022-11-23",
   "medication": "Betamethasone Dipropionate",
   "drug_brand": "Betamethasone Dipropionate",
   "patient_id": 19218704,
   "doctor_id": 11320
 },
 {
   "prescription_id": 398692227,
   "prescription_date": "2023-09-24",
   "medication": "Permethrin",
   "drug_brand": "Permethrin",
   "patient_id": 270549175,
   "doctor_id": 11321
 },
 {
   "prescription_id": 735561382,
   "prescription_date": "2023-05-27",
   "medication": "Phenol",
   "drug_brand": "Sore Throat Cherry",
   "patient_id": 209923864,
   "doctor_id": 11322
 },
 {
   "prescription_id": 120812665,
   "prescription_date": "2023-04-02",
   "medication": "maraviroc",
   "drug_brand": "SELZENTRY",
   "patient_id": 137555123,
   "doctor_id": 11323
 },
 {
   "prescription_id": 575113760,
   "prescription_date": "2023-05-16",
   "medication": "ERYTHROMYCIN ETHYLSUCCINATE AND SULFISOXAZOLE ACETYL",
   "drug_brand": "ERYTHROMYCIN ETHYLSUCCINATE AND SULFISOXAZOLE ACETYL",
   "patient_id": 140977191,
   "doctor_id": 11324
 },
 {
   "prescription_id": 832502047,
   "prescription_date": "2023-10-23",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 636359507,
   "doctor_id": 11325
 },
 {
   "prescription_id": 31013766,
   "prescription_date": "2023-09-18",
   "medication": "Iodixanol",
   "drug_brand": "Visipaque",
   "patient_id": 70148713,
   "doctor_id": 11326
 },
 {
   "prescription_id": 255098148,
   "prescription_date": "2023-08-18",
   "medication": "Fosinopril Sodium",
   "drug_brand": "Fosinopril Sodium",
   "patient_id": 383354783,
   "doctor_id": 11327
 },
 {
   "prescription_id": 773196251,
   "prescription_date": "2023-09-19",
   "medication": "BENZALKONIUM CHLORIDE,BACITRACIN ZINC,NEOMYCIN SULFATE,POLYMYXIN B SULFATE, ETHYL ALCOHOL",
   "drug_brand": "Emergency Preparedness",
   "patient_id": 704120718,
   "doctor_id": 11328
 },
 {
   "prescription_id": 851655971,
   "prescription_date": "2023-08-03",
   "medication": "Aluminum Zirconium Tetrachlorohydrex GLY",
   "drug_brand": "Dove",
   "patient_id": 268909923,
   "doctor_id": 11329
 },
 {
   "prescription_id": 504001913,
   "prescription_date": "2022-11-17",
   "medication": "Hydrocortisone",
   "drug_brand": "TrueLipids Anti-Itch Barrier",
   "patient_id": 451085417,
   "doctor_id": 11330
 },
 {
   "prescription_id": 156529748,
   "prescription_date": "2023-01-25",
   "medication": "KETOROLAC TROMETHAMINE",
   "drug_brand": "Ketorolac Tromethamine",
   "patient_id": 175968229,
   "doctor_id": 11331
 },
 {
   "prescription_id": 178645187,
   "prescription_date": "2023-11-12",
   "medication": "ANILINUM",
   "drug_brand": "ANILINUM",
   "patient_id": 610584136,
   "doctor_id": 11332
 },
 {
   "prescription_id": 544641188,
   "prescription_date": "2023-04-09",
   "medication": "Hydrocodone Bitartrate and Acetaminophen",
   "drug_brand": "Hydrocodone Bitartrate and Acetaminophen",
   "patient_id": 561344897,
   "doctor_id": 11333
 },
 {
   "prescription_id": 95471346,
   "prescription_date": "2023-04-15",
   "medication": "Minoxidil",
   "drug_brand": "leader hair regrowth treatment",
   "patient_id": 998726632,
   "doctor_id": 11334
 },
 {
   "prescription_id": 382971576,
   "prescription_date": "2023-08-19",
   "medication": "MENTHOL CAMPHOR",
   "drug_brand": "DEEP REMEDY",
   "patient_id": 337089339,
   "doctor_id": 11335
 },
 {
   "prescription_id": 796060657,
   "prescription_date": "2023-03-08",
   "medication": "Anacardium Orientale, Belladonna, Hyoscyamus Niger, Kali Bromatum, Veratrum Album, Baryta Carbonica, Lachesis Mutus",
   "drug_brand": "ALZ HP",
   "patient_id": 706231568,
   "doctor_id": 11336
 },
 {
   "prescription_id": 28497302,
   "prescription_date": "2022-12-17",
   "medication": "Oxygen, Refrigerated Liquid",
   "drug_brand": "Oxygen, Refrigerated Liquid",
   "patient_id": 918665870,
   "doctor_id": 11337
 },
 {
   "prescription_id": 406354073,
   "prescription_date": "2023-05-30",
   "medication": "CAMPHOR, CAPSAICIN AND MENTHOL",
   "drug_brand": "TIANHE ZHUIFENG GAO",
   "patient_id": 705611321,
   "doctor_id": 11338
 },
 {
   "prescription_id": 279088554,
   "prescription_date": "2023-10-13",
   "medication": "phytonadione",
   "drug_brand": "Mephyton",
   "patient_id": 270932787,
   "doctor_id": 11339
 },
 {
   "prescription_id": 108122920,
   "prescription_date": "2023-02-17",
   "medication": "darifenacin",
   "drug_brand": "Enablex",
   "patient_id": 223978219,
   "doctor_id": 11340
 },
 {
   "prescription_id": 236138728,
   "prescription_date": "2023-04-10",
   "medication": "Wart Remover Gel Pen",
   "drug_brand": "Salicylic Acid",
   "patient_id": 149248170,
   "doctor_id": 11341
 },
 {
   "prescription_id": 974829716,
   "prescription_date": "2023-02-24",
   "medication": "Treatment Set TS332678",
   "drug_brand": "Treatment Set TS332678",
   "patient_id": 265070821,
   "doctor_id": 11342
 },
 {
   "prescription_id": 997374556,
   "prescription_date": "2022-11-16",
   "medication": "Hydrocortisone / Chloroxylenol / Pramoxine HCl",
   "drug_brand": "Pramoxine-HC",
   "patient_id": 545441107,
   "doctor_id": 11343
 },
 {
   "prescription_id": 960193888,
   "prescription_date": "2023-09-11",
   "medication": "Ethylhexyl methoxycinnamate, Ethylhexy Salicate, Butyl Methoxydibezoylmethane",
   "drug_brand": "UV Capture Vita Sun Gel",
   "patient_id": 485141889,
   "doctor_id": 11344
 },
 {
   "prescription_id": 114179409,
   "prescription_date": "2023-05-08",
   "medication": "norethindrone and ethinyl estradiol",
   "drug_brand": "Vyfemla",
   "patient_id": 763165452,
   "doctor_id": 11345
 },
 {
   "prescription_id": 35701719,
   "prescription_date": "2023-10-25",
   "medication": "Benzoyl Peroxide",
   "drug_brand": "Anti-Bacterial Wash with Exfoliating Beads for Blemish skin",
   "patient_id": 685725493,
   "doctor_id": 11346
 },
 {
   "prescription_id": 672442807,
   "prescription_date": "2023-09-20",
   "medication": "Povidone-iodine",
   "drug_brand": "Aplicare Povidone-iodine Scrub",
   "patient_id": 182844664,
   "doctor_id": 11347
 },
 {
   "prescription_id": 517536648,
   "prescription_date": "2023-03-10",
   "medication": "Arnica montana, Arsenicum album, Baptisia tinctoria, Cinchona officinalis, Galium aparine, Hepar suis, Korean ginseng, Mercurius corrosivus, Phosphoricum acidum, Radium bromatum, Sulphur iodatum, Thuja occidentalis, X-ray,",
   "drug_brand": "EMF",
   "patient_id": 916677356,
   "doctor_id": 11348
 },
 {
   "prescription_id": 577444297,
   "prescription_date": "2022-11-15",
   "medication": "isotretinoin",
   "drug_brand": "Myorisan",
   "patient_id": 357367853,
   "doctor_id": 11349
 },
 {
   "prescription_id": 950855630,
   "prescription_date": "2023-10-17",
   "medication": "certolizumab pegol",
   "drug_brand": "Cimzia",
   "patient_id": 622392191,
   "doctor_id": 11350
 },
 {
   "prescription_id": 274104607,
   "prescription_date": "2023-01-28",
   "medication": "Invisible Stick Antiperspirant and Deodorant",
   "drug_brand": "Degree Men",
   "patient_id": 43273828,
   "doctor_id": 11351
 },
 {
   "prescription_id": 645719332,
   "prescription_date": "2022-12-18",
   "medication": "metaxalone",
   "drug_brand": "SKELAXIN",
   "patient_id": 86155929,
   "doctor_id": 11352
 },
 {
   "prescription_id": 24381604,
   "prescription_date": "2023-07-07",
   "medication": "Avobenzone, Homosalate, Octisalate, Octocrylene and Oxybenzone",
   "drug_brand": "LOreal Paris Advanced Suncare Invisible Protect Dry 50 Plus Broad Spectrum SPF 50 Plus Sunscreen",
   "patient_id": 507055576,
   "doctor_id": 11353
 },
 {
   "prescription_id": 80759865,
   "prescription_date": "2023-07-28",
   "medication": "Treatment Set TS347115",
   "drug_brand": "Treatment Set TS347115",
   "patient_id": 307893801,
   "doctor_id": 11354
 },
 {
   "prescription_id": 451016097,
   "prescription_date": "2022-11-25",
   "medication": "Fomepizole",
   "drug_brand": "Fomepizole",
   "patient_id": 663957156,
   "doctor_id": 11355
 },
 {
   "prescription_id": 164134589,
   "prescription_date": "2023-08-20",
   "medication": "Acetaminophen, Aspirin, Caffeine",
   "drug_brand": "good neighbor pharmacy migraine relief",
   "patient_id": 714333176,
   "doctor_id": 11356
 },
 {
   "prescription_id": 189032880,
   "prescription_date": "2023-10-23",
   "medication": "DEXTROSE",
   "drug_brand": "Dextrose",
   "patient_id": 400106479,
   "doctor_id": 11357
 },
 {
   "prescription_id": 367169120,
   "prescription_date": "2023-10-02",
   "medication": "Acetaminophen, Dextromethorphan Hydrobromide, Guaifenesin, and Phenylephrine Hydrochloride",
   "drug_brand": "SohMed Cold Relief",
   "patient_id": 995096308,
   "doctor_id": 11358
 },
 {
   "prescription_id": 371020749,
   "prescription_date": "2023-11-07",
   "medication": "benztropine mesylate",
   "drug_brand": "Benztropine Mesylate",
   "patient_id": 798502775,
   "doctor_id": 11359
 },
 {
   "prescription_id": 347285009,
   "prescription_date": "2022-12-14",
   "medication": "Griseofulvin",
   "drug_brand": "Griseofulvin",
   "patient_id": 419853502,
   "doctor_id": 11360
 },
 {
   "prescription_id": 563360230,
   "prescription_date": "2023-10-22",
   "medication": "Oxazepam",
   "drug_brand": "Oxazepam",
   "patient_id": 451414638,
   "doctor_id": 11361
 },
 {
   "prescription_id": 552208332,
   "prescription_date": "2023-08-18",
   "medication": "Benzocaine 20%",
   "drug_brand": "Leader Oral Pain Relief",
   "patient_id": 568952270,
   "doctor_id": 11362
 },
 {
   "prescription_id": 639213328,
   "prescription_date": "2023-03-24",
   "medication": "Bupropion Hydrochloride",
   "drug_brand": "Bupropion Hydrochloride",
   "patient_id": 493466447,
   "doctor_id": 11363
 },
 {
   "prescription_id": 199845004,
   "prescription_date": "2023-08-30",
   "medication": "TRICLOSAN",
   "drug_brand": "ANTIBACTERIAL FOAMING",
   "patient_id": 141915822,
   "doctor_id": 11364
 },
 {
   "prescription_id": 40417455,
   "prescription_date": "2023-09-24",
   "medication": "LETROZOLE",
   "drug_brand": "LETROZOLE",
   "patient_id": 244505818,
   "doctor_id": 11365
 },
 {
   "prescription_id": 993439297,
   "prescription_date": "2023-03-03",
   "medication": "Cefdinir",
   "drug_brand": "Cefdinir",
   "patient_id": 497746884,
   "doctor_id": 11366
 },
 {
   "prescription_id": 240841323,
   "prescription_date": "2023-01-11",
   "medication": "aluminum hydroxide, magnesium hydroxide, simethicone",
   "drug_brand": "Leader Antacid",
   "patient_id": 602220202,
   "doctor_id": 11367
 },
 {
   "prescription_id": 397354788,
   "prescription_date": "2023-06-02",
   "medication": "Losartan Potassium and Hydrochlorothiazide",
   "drug_brand": "Losartan Potassium and Hydrochlorothiazide",
   "patient_id": 428589723,
   "doctor_id": 11368
 },
 {
   "prescription_id": 358882705,
   "prescription_date": "2022-12-17",
   "medication": "Olanzapine and Fluoxetine",
   "drug_brand": "Olanzapine and Fluoxetine",
   "patient_id": 281852462,
   "doctor_id": 11369
 },
 {
   "prescription_id": 513249021,
   "prescription_date": "2023-08-03",
   "medication": "hydrocodone bitartrate, ibuprofen",
   "drug_brand": "Reprexain",
   "patient_id": 819361042,
   "doctor_id": 11370
 },
 {
   "prescription_id": 532090150,
   "prescription_date": "2023-08-02",
   "medication": "Bisoprolol Fumarate and Hydrochlorothiazide",
   "drug_brand": "Bisoprolol Fumarate and Hydrochlorothiazide",
   "patient_id": 893389209,
   "doctor_id": 11371
 },
 {
   "prescription_id": 632705205,
   "prescription_date": "2023-05-10",
   "medication": "Amiodarone Hydrochloride",
   "drug_brand": "Amiodarone Hydrochloride",
   "patient_id": 84494254,
   "doctor_id": 11372
 },
 {
   "prescription_id": 772032369,
   "prescription_date": "2023-06-07",
   "medication": "Chlordiazepoxide Hydrochloride and Clidinium Bromide",
   "drug_brand": "Chlordiazepoxide Hydrochloride and Clidinium Bromide",
   "patient_id": 533454936,
   "doctor_id": 11373
 },
 {
   "prescription_id": 20955820,
   "prescription_date": "2023-10-18",
   "medication": "Sodium Fluoride",
   "drug_brand": "koala pals",
   "patient_id": 819542153,
   "doctor_id": 11374
 },
 {
   "prescription_id": 671309563,
   "prescription_date": "2023-02-23",
   "medication": "Ketotifen Fumarate",
   "drug_brand": "allergy eye",
   "patient_id": 428101685,
   "doctor_id": 11375
 },
 {
   "prescription_id": 315657206,
   "prescription_date": "2023-02-10",
   "medication": "Sodium fluoride",
   "drug_brand": "Crest Wild Expressions",
   "patient_id": 237724864,
   "doctor_id": 11376
 },
 {
   "prescription_id": 93092671,
   "prescription_date": "2023-08-03",
   "medication": "EUCALYPTOL, MENTHOL, METHYLSALICYLATE, THYMOL",
   "drug_brand": "Mouth Rinse",
   "patient_id": 807574651,
   "doctor_id": 11377
 },
 {
   "prescription_id": 292369984,
   "prescription_date": "2023-05-17",
   "medication": "Avobenzone, Homosalate, Octisalate, and Octocrylene",
   "drug_brand": "Coppertone Tanning Sunscreen",
   "patient_id": 356217138,
   "doctor_id": 11378
 },
 {
   "prescription_id": 593125990,
   "prescription_date": "2023-02-22",
   "medication": "Titanium Dioxide",
   "drug_brand": "Purminerals 4 in 1 Makeup SPF 15 Golden Medium",
   "patient_id": 264503896,
   "doctor_id": 11379
 },
 {
   "prescription_id": 942471120,
   "prescription_date": "2023-01-13",
   "medication": "Promethazine Hydrochloride",
   "drug_brand": "Promethazine Hydrochloride",
   "patient_id": 332749365,
   "doctor_id": 11380
 },
 {
   "prescription_id": 314068793,
   "prescription_date": "2023-10-10",
   "medication": "Pramoxine HCl, Zinc acetate",
   "drug_brand": "Clear Anti Itch",
   "patient_id": 110885783,
   "doctor_id": 11381
 },
 {
   "prescription_id": 383362199,
   "prescription_date": "2022-12-29",
   "medication": "Morphine Sulfate",
   "drug_brand": "Morphine Sulfate",
   "patient_id": 435852138,
   "doctor_id": 11382
 },
 {
   "prescription_id": 576308466,
   "prescription_date": "2023-08-19",
   "medication": "Ribavirin",
   "drug_brand": "Copegus",
   "patient_id": 23289163,
   "doctor_id": 11383
 },
 {
   "prescription_id": 737442149,
   "prescription_date": "2023-09-29",
   "medication": "Skin Protectant",
   "drug_brand": "Gentle Eczema Balm",
   "patient_id": 210758845,
   "doctor_id": 11384
 },
 {
   "prescription_id": 676179813,
   "prescription_date": "2023-09-22",
   "medication": "Black Birch",
   "drug_brand": "Black Birch",
   "patient_id": 420377926,
   "doctor_id": 11385
 },
 {
   "prescription_id": 430665829,
   "prescription_date": "2022-12-29",
   "medication": "Buspirone Hydrochloride",
   "drug_brand": "Buspirone Hydrochloride",
   "patient_id": 71883115,
   "doctor_id": 11386
 },
 {
   "prescription_id": 932681041,
   "prescription_date": "2023-02-05",
   "medication": "ATORVASTATIN CALCIUM",
   "drug_brand": "ATORVASTATIN CALCIUM",
   "patient_id": 519021437,
   "doctor_id": 11387
 },
 {
   "prescription_id": 93356356,
   "prescription_date": "2023-06-13",
   "medication": "telmisartan/amlodipine",
   "drug_brand": "Twynsta",
   "patient_id": 819499806,
   "doctor_id": 11388
 },
 {
   "prescription_id": 400932194,
   "prescription_date": "2023-03-08",
   "medication": "Liothyronine Sodium",
   "drug_brand": "Liothyronine Sodium",
   "patient_id": 357174398,
   "doctor_id": 11389
 },
 {
   "prescription_id": 350060895,
   "prescription_date": "2023-04-16",
   "medication": "GLIMEPIRIDE",
   "drug_brand": "GLIMEPIRIDE",
   "patient_id": 118718403,
   "doctor_id": 11390
 },
 {
   "prescription_id": 821492089,
   "prescription_date": "2023-02-17",
   "medication": "Alprazolam",
   "drug_brand": "Alprazolam",
   "patient_id": 682730119,
   "doctor_id": 11391
 },
 {
   "prescription_id": 882155753,
   "prescription_date": "2022-12-24",
   "medication": "Salicylic Acid",
   "drug_brand": "Clearasil",
   "patient_id": 779692843,
   "doctor_id": 11392
 },
 {
   "prescription_id": 314723432,
   "prescription_date": "2023-01-14",
   "medication": "enoxaparin sodium",
   "drug_brand": "Lovenox",
   "patient_id": 966561466,
   "doctor_id": 11393
 },
 {
   "prescription_id": 752771882,
   "prescription_date": "2023-02-16",
   "medication": "hydrochlorothiazide",
   "drug_brand": "hydrochlorothiazide",
   "patient_id": 428639568,
   "doctor_id": 11394
 },
 {
   "prescription_id": 80877304,
   "prescription_date": "2022-12-11",
   "medication": "SALICYLIC ACID",
   "drug_brand": "FACIAL CLEANSER",
   "patient_id": 872993792,
   "doctor_id": 11395
 },
 {
   "prescription_id": 879475860,
   "prescription_date": "2023-05-02",
   "medication": "Bismuth Subsalicylate",
   "drug_brand": "Pepto-Bismol and Pepto-Bismol",
   "patient_id": 211820509,
   "doctor_id": 11396
 },
 {
   "prescription_id": 795698269,
   "prescription_date": "2023-05-12",
   "medication": "SERTRALINE HYDROCHLORIDE",
   "drug_brand": "SERTRALINE HYDROCHLORIDE",
   "patient_id": 973051723,
   "doctor_id": 11397
 },
 {
   "prescription_id": 190418390,
   "prescription_date": "2023-06-03",
   "medication": "Sodium Fluoride",
   "drug_brand": "Anticavity Fluoride Rinse",
   "patient_id": 402541488,
   "doctor_id": 11398
 },
 {
   "prescription_id": 147564792,
   "prescription_date": "2023-02-24",
   "medication": "PREGABALIN",
   "drug_brand": "Lyrica",
   "patient_id": 812263271,
   "doctor_id": 11399
 },
 {
   "prescription_id": 966685675,
   "prescription_date": "2023-07-16",
   "medication": "Gnaphalium Polycephalum, Berberis Vulgaris, Cimicifuga Racemosa, Cinchona Officinalis, Colocynthis, Ledum Palustre, Ranunculus Bulbosus",
   "drug_brand": "Arthritis Joints",
   "patient_id": 486519720,
   "doctor_id": 11400
 },
 {
   "prescription_id": 536667823,
   "prescription_date": "2023-06-21",
   "medication": "Carbidopa and levodopa",
   "drug_brand": "Carbidopa and levodopa",
   "patient_id": 263114127,
   "doctor_id": 11401
 },
 {
   "prescription_id": 836008016,
   "prescription_date": "2023-08-15",
   "medication": "Trimethobenzamide Hydrochloride",
   "drug_brand": "Trimethobenzamide Hydrochloride",
   "patient_id": 363429428,
   "doctor_id": 11402
 },
 {
   "prescription_id": 414386849,
   "prescription_date": "2023-01-31",
   "medication": "Isosorbide Dinitrate",
   "drug_brand": "Isosorbide Dinitrate",
   "patient_id": 980267652,
   "doctor_id": 11403
 },
 {
   "prescription_id": 965520812,
   "prescription_date": "2023-03-19",
   "medication": "Levetiracetam",
   "drug_brand": "Levetiracetam",
   "patient_id": 625704501,
   "doctor_id": 11404
 },
 {
   "prescription_id": 296554024,
   "prescription_date": "2023-10-13",
   "medication": "CHAMOMILE PLANT",
   "drug_brand": "CHAMOMILLA",
   "patient_id": 27052530,
   "doctor_id": 11405
 },
 {
   "prescription_id": 245487986,
   "prescription_date": "2023-02-02",
   "medication": "tapentadol hydrochloride",
   "drug_brand": "NUCYNTA",
   "patient_id": 580152369,
   "doctor_id": 11406
 },
 {
   "prescription_id": 42665508,
   "prescription_date": "2022-12-20",
   "medication": "Benzalkonium chloride",
   "drug_brand": "Reliance Hand Saniziter",
   "patient_id": 665158476,
   "doctor_id": 11407
 },
 {
   "prescription_id": 16849755,
   "prescription_date": "2023-04-28",
   "medication": "Ranitidine",
   "drug_brand": "Ranitidine",
   "patient_id": 868965426,
   "doctor_id": 11408
 },
 {
   "prescription_id": 690433544,
   "prescription_date": "2022-11-24",
   "medication": "TAMSULOSIN HYDROCHLORIDE",
   "drug_brand": "TAMSULOSIN HYDROCHLORIDE",
   "patient_id": 170168746,
   "doctor_id": 11409
 },
 {
   "prescription_id": 957654536,
   "prescription_date": "2023-03-11",
   "medication": "CITRULLUS COLOCYNTHIS FRUIT PULP,GRATIOLA OFFICINALIS,LYCOPODIUM CLAVATUM SPORE,SODIUM CARBONATE,STRYCHNOS NUX-VOMICA SEED,SULFUR,TAXUS BACCATA FRUIT,PODOPHYLLUM.",
   "drug_brand": "IBS Irritable Bowel Syndrome Relief",
   "patient_id": 850786317,
   "doctor_id": 11410
 },
 {
   "prescription_id": 507647786,
   "prescription_date": "2023-08-07",
   "medication": "Allergenic Extracts Alum Precipitated",
   "drug_brand": "CENTER-AL - POA PRATENSIS POLLEN",
   "patient_id": 986935235,
   "doctor_id": 11411
 },
 {
   "prescription_id": 907062501,
   "prescription_date": "2023-02-05",
   "medication": "SALICYLIC ACID",
   "drug_brand": "VIPER ACNE BODY WASH",
   "patient_id": 330037848,
   "doctor_id": 11412
 },
 {
   "prescription_id": 936224545,
   "prescription_date": "2023-06-12",
   "medication": "ETHYL ALCOHOL",
   "drug_brand": "Instant Hand Sanitizer Twisted Peppermint",
   "patient_id": 863907370,
   "doctor_id": 11413
 },
 {
   "prescription_id": 827500978,
   "prescription_date": "2023-08-30",
   "medication": "Lidocaine Hydrochloride",
   "drug_brand": "IWK-5",
   "patient_id": 637676207,
   "doctor_id": 11414
 },
 {
   "prescription_id": 773335485,
   "prescription_date": "2023-04-17",
   "medication": "fenofibrate",
   "drug_brand": "Fenofibrate",
   "patient_id": 355755490,
   "doctor_id": 11415
 },
 {
   "prescription_id": 608309228,
   "prescription_date": "2022-12-11",
   "medication": "Aconitum napellus, Aurum bromatum, Calcarea carbonica, Chamomilla, Cina, Ignatia amara, Kali bromatum, Lycopodium clavatum, Paeonia officinalis, Phosphorus, Stramonium, Sulphur",
   "drug_brand": "Fears and Nightmares",
   "patient_id": 758980115,
   "doctor_id": 11416
 },
 {
   "prescription_id": 942041437,
   "prescription_date": "2023-03-02",
   "medication": "benzocaine, tetracaine hydrochloride",
   "drug_brand": "Denti-Care Denti-Freeze",
   "patient_id": 927568245,
   "doctor_id": 11417
 },
 {
   "prescription_id": 338819066,
   "prescription_date": "2023-10-25",
   "medication": "Dexamethasone",
   "drug_brand": "Dexamethsone",
   "patient_id": 556553122,
   "doctor_id": 11418
 },
 {
   "prescription_id": 327816718,
   "prescription_date": "2023-07-16",
   "medication": "Brevibacterium stationis",
   "drug_brand": "Pleo Art U",
   "patient_id": 265104769,
   "doctor_id": 11419
 },
 {
   "prescription_id": 668890383,
   "prescription_date": "2023-10-12",
   "medication": "Chlorhexidine Gluconate",
   "drug_brand": "Chlorhexidine Gluconate",
   "patient_id": 495145350,
   "doctor_id": 11420
 },
 {
   "prescription_id": 463420701,
   "prescription_date": "2023-07-18",
   "medication": "Glimepiride",
   "drug_brand": "Glimepiride",
   "patient_id": 542987340,
   "doctor_id": 11421
 },
 {
   "prescription_id": 369429746,
   "prescription_date": "2023-08-02",
   "medication": "diphenhydramine hydrochloride and zinc acetate",
   "drug_brand": "Shopko Anti-Itch",
   "patient_id": 343416509,
   "doctor_id": 11422
 },
 {
   "prescription_id": 559693794,
   "prescription_date": "2023-03-15",
   "medication": "KETOCONAZOLE",
   "drug_brand": "KETOCONAZOLE",
   "patient_id": 879419974,
   "doctor_id": 11423
 },
 {
   "prescription_id": 434421873,
   "prescription_date": "2023-04-21",
   "medication": "venlafaxine",
   "drug_brand": "venlafaxine",
   "patient_id": 465471842,
   "doctor_id": 11424
 },
 {
   "prescription_id": 191707847,
   "prescription_date": "2023-08-19",
   "medication": "PENICILLIUM CHRYSOGENUM",
   "drug_brand": "PENICILLIUM CHRYSOGENUM VAR CHRYSOGENUM",
   "patient_id": 394561574,
   "doctor_id": 11425
 },
 {
   "prescription_id": 377754217,
   "prescription_date": "2023-04-02",
   "medication": "Meloxicam",
   "drug_brand": "Meloxicam",
   "patient_id": 678980314,
   "doctor_id": 11426
 },
 {
   "prescription_id": 264599373,
   "prescription_date": "2023-09-26",
   "medication": "Metoclopramide",
   "drug_brand": "Metoclopramide",
   "patient_id": 628975390,
   "doctor_id": 11427
 },
 {
   "prescription_id": 857381762,
   "prescription_date": "2023-06-10",
   "medication": "ALCOHOL",
   "drug_brand": "Vanilla Bean Antibacterial Hand",
   "patient_id": 786632343,
   "doctor_id": 11428
 },
 {
   "prescription_id": 11481879,
   "prescription_date": "2023-09-11",
   "medication": ".BETA.-CAROTENE, ASCORBIC ACID, CHOLECALCIFEROL, .ALPHA.-TOCOPHEROL ACETATE, D-, THIAMINE MONONITRATE, RIBOFLAVIN, NIACINAMIDE, PYRIDOXINE HYDROCHLORIDE, FOLIC ACID, CYANOCOBALAMIN, CALCIUM CARBONATE, IRON, MAGNESIUM OXIDE, ZINC OXIDE, CUPRIC OXIDE, IODINE, OMEGA-3 FATTY ACIDS",
   "drug_brand": "Duet DHA",
   "patient_id": 780389679,
   "doctor_id": 11429
 },
 {
   "prescription_id": 589708565,
   "prescription_date": "2023-10-08",
   "medication": "Aspirin",
   "drug_brand": "Aspirin",
   "patient_id": 894988093,
   "doctor_id": 11430
 },
 {
   "prescription_id": 198418398,
   "prescription_date": "2023-10-14",
   "medication": "Methocarbamol",
   "drug_brand": "Methocarbamol",
   "patient_id": 85912857,
   "doctor_id": 11431
 },
 {
   "prescription_id": 980891535,
   "prescription_date": "2023-03-20",
   "medication": "Esomeprazole magnesium",
   "drug_brand": "NEXIUM",
   "patient_id": 464105653,
   "doctor_id": 11432
 },
 {
   "prescription_id": 435499888,
   "prescription_date": "2023-10-30",
   "medication": "Octinoxate, Octisalate, Zinc Oxide, Titanium Dioxide",
   "drug_brand": "Atomy Sunscreen White",
   "patient_id": 501240471,
   "doctor_id": 11433
 },
 {
   "prescription_id": 323194271,
   "prescription_date": "2022-12-14",
   "medication": "GEMCITABINE HYDROCHLORIDE",
   "drug_brand": "GEMCITABINE HYDROCHLORIDE",
   "patient_id": 736976614,
   "doctor_id": 11434
 },
 {
   "prescription_id": 778951680,
   "prescription_date": "2023-07-15",
   "medication": "Gemfibrozil",
   "drug_brand": "Gemfibrozil",
   "patient_id": 189195112,
   "doctor_id": 11435
 },
 {
   "prescription_id": 864948699,
   "prescription_date": "2023-09-01",
   "medication": "Clonazepam",
   "drug_brand": "Clonazepam",
   "patient_id": 970400818,
   "doctor_id": 11436
 },
 {
   "prescription_id": 292351060,
   "prescription_date": "2023-02-21",
   "medication": "Testosterone Cypionate",
   "drug_brand": "Testosterone Cypionate",
   "patient_id": 328916208,
   "doctor_id": 11437
 },
 {
   "prescription_id": 778154660,
   "prescription_date": "2023-04-01",
   "medication": "Valacyclovir Hydrochloride",
   "drug_brand": "Valacyclovir Hydrochloride",
   "patient_id": 725137844,
   "doctor_id": 11438
 },
 {
   "prescription_id": 266036183,
   "prescription_date": "2023-05-12",
   "medication": "rivastigmine",
   "drug_brand": "Exelon",
   "patient_id": 878816364,
   "doctor_id": 11439
 },
 {
   "prescription_id": 625659352,
   "prescription_date": "2023-07-29",
   "medication": "Carbidopa and Levodopa",
   "drug_brand": "Carbidopa and Levodopa",
   "patient_id": 645873334,
   "doctor_id": 11440
 },
 {
   "prescription_id": 158193986,
   "prescription_date": "2023-03-20",
   "medication": "diphenhydramine hydrochloride and zinc acetate",
   "drug_brand": "Anti-Itch Extra Strength",
   "patient_id": 647910025,
   "doctor_id": 11441
 },
 {
   "prescription_id": 265300242,
   "prescription_date": "2023-10-12",
   "medication": "Butalbital, Aspirin, and Caffeine",
   "drug_brand": "Fiorinal",
   "patient_id": 807001272,
   "doctor_id": 11442
 },
 {
   "prescription_id": 691099883,
   "prescription_date": "2023-04-10",
   "medication": "perphenazine",
   "drug_brand": "Perphenazine",
   "patient_id": 345537363,
   "doctor_id": 11443
 },
 {
   "prescription_id": 497574838,
   "prescription_date": "2023-09-04",
   "medication": "Acetaminophen",
   "drug_brand": "Equate Acetaminophen",
   "patient_id": 972176057,
   "doctor_id": 11444
 },
 {
   "prescription_id": 280897514,
   "prescription_date": "2023-07-05",
   "medication": "Furosemide",
   "drug_brand": "Furosemide",
   "patient_id": 923473238,
   "doctor_id": 11445
 },
 {
   "prescription_id": 848871330,
   "prescription_date": "2023-07-13",
   "medication": "Lanolin",
   "drug_brand": "Lanolin",
   "patient_id": 923137516,
   "doctor_id": 11446
 },
 {
   "prescription_id": 487822015,
   "prescription_date": "2023-11-02",
   "medication": "Benzocaine",
   "drug_brand": "Sally Hansen Microwavable Eybrow, Face and Lip Wax Kit",
   "patient_id": 297181670,
   "doctor_id": 11447
 },
 {
   "prescription_id": 965069903,
   "prescription_date": "2023-10-10",
   "medication": "Mirtazapine",
   "drug_brand": "Mirtazapine",
   "patient_id": 830274531,
   "doctor_id": 11448
 },
 {
   "prescription_id": 484409753,
   "prescription_date": "2023-03-28",
   "medication": "Aconitum nap., Allium cepa, Arsenicum alb., Bryonia, Calendula, Chelidonium majus, Cineraria, Euphrasia, Graphites, Lycopodium, Merc. corros., Nux vom., Phosphorus, Phytolacca, Picricum ac., Pulsatilla, Rhus toxicodendron, Sulphur, Echinacea",
   "drug_brand": "Eye Care",
   "patient_id": 967019844,
   "doctor_id": 11449
 },
 {
   "prescription_id": 851141742,
   "prescription_date": "2022-11-20",
   "medication": "Benztropine Mesylate",
   "drug_brand": "Benztropine Mesylate",
   "patient_id": 454949492,
   "doctor_id": 11450
 },
 {
   "prescription_id": 910430721,
   "prescription_date": "2023-05-06",
   "medication": "TRIPROLIDINE HYDROCHLORIDE",
   "drug_brand": "VANAHIST PD",
   "patient_id": 317356374,
   "doctor_id": 11451
 },
 {
   "prescription_id": 245803116,
   "prescription_date": "2023-02-19",
   "medication": "Brompheniramine Maleate, Codeine Phosphate, Phenylephrine Hydrochloride",
   "drug_brand": "Poly-Tussin AC",
   "patient_id": 98693118,
   "doctor_id": 11452
 },
 {
   "prescription_id": 584035535,
   "prescription_date": "2023-10-18",
   "medication": "Red Snapper",
   "drug_brand": "Red Snapper",
   "patient_id": 859007943,
   "doctor_id": 11453
 },
 {
   "prescription_id": 649656392,
   "prescription_date": "2023-02-06",
   "medication": "Sulfamethoxazole and Trimethoprim",
   "drug_brand": "Sulfamethoxazole and Trimethoprim",
   "patient_id": 936928571,
   "doctor_id": 11454
 },
 {
   "prescription_id": 164526240,
   "prescription_date": "2023-06-18",
   "medication": "Sodium Monofluorophospate",
   "drug_brand": "NewYork-Presbyterian Amenity",
   "patient_id": 205802252,
   "doctor_id": 11455
 },
 {
   "prescription_id": 515936009,
   "prescription_date": "2023-05-03",
   "medication": "Treatment Set TS340054",
   "drug_brand": "Treatment Set TS340054",
   "patient_id": 491186752,
   "doctor_id": 11456
 },
 {
   "prescription_id": 793854049,
   "prescription_date": "2023-03-07",
   "medication": "Armodafinil",
   "drug_brand": "Nuvigil",
   "patient_id": 223671959,
   "doctor_id": 11457
 },
 {
   "prescription_id": 991539788,
   "prescription_date": "2023-06-01",
   "medication": "Phenylephrine hydrochloride",
   "drug_brand": "Nasal Four",
   "patient_id": 574472765,
   "doctor_id": 11458
 },
 {
   "prescription_id": 352809546,
   "prescription_date": "2022-12-01",
   "medication": "Aluminum hydroxide, Magnesium hydroxide, Simethicone",
   "drug_brand": "Almacone",
   "patient_id": 952307752,
   "doctor_id": 11459
 },
 {
   "prescription_id": 328302421,
   "prescription_date": "2023-02-27",
   "medication": "Naratriptan",
   "drug_brand": "Naratriptan",
   "patient_id": 147194170,
   "doctor_id": 11460
 },
 {
   "prescription_id": 14084943,
   "prescription_date": "2023-02-17",
   "medication": "Atomoxetine hydrochloride",
   "drug_brand": "Atomoxetine hydrochloride",
   "patient_id": 854815299,
   "doctor_id": 11461
 },
 {
   "prescription_id": 458987120,
   "prescription_date": "2023-10-12",
   "medication": "Miconazole",
   "drug_brand": "MakeSense",
   "patient_id": 440602340,
   "doctor_id": 11462
 },
 {
   "prescription_id": 522311535,
   "prescription_date": "2023-07-27",
   "medication": "HYDROCODONE BITARTRATE AND ACETAMINOPHEN",
   "drug_brand": "HYDROCODONE BITARTRATE AND ACETAMINOPHEN",
   "patient_id": 442514024,
   "doctor_id": 11463
 },
 {
   "prescription_id": 487669009,
   "prescription_date": "2023-08-03",
   "medication": "Cefadroxil",
   "drug_brand": "Cefadroxil",
   "patient_id": 367039032,
   "doctor_id": 11464
 },
 {
   "prescription_id": 269336171,
   "prescription_date": "2023-04-07",
   "medication": "Chloroquine phosphate",
   "drug_brand": "Chloroquine phosphate",
   "patient_id": 221469783,
   "doctor_id": 11465
 },
 {
   "prescription_id": 79654592,
   "prescription_date": "2023-10-17",
   "medication": "Amoxicillin",
   "drug_brand": "Amoxicillin",
   "patient_id": 984167189,
   "doctor_id": 11466
 },
 {
   "prescription_id": 800131858,
   "prescription_date": "2022-12-11",
   "medication": "clonidine",
   "drug_brand": "Clonidine",
   "patient_id": 787798578,
   "doctor_id": 11467
 },
 {
   "prescription_id": 488254904,
   "prescription_date": "2023-06-08",
   "medication": "Warfarin Sodium",
   "drug_brand": "Jantoven",
   "patient_id": 142845775,
   "doctor_id": 11468
 },
 {
   "prescription_id": 642084229,
   "prescription_date": "2022-11-30",
   "medication": "Green Pea",
   "drug_brand": "Green Pea",
   "patient_id": 821563403,
   "doctor_id": 11469
 },
 {
   "prescription_id": 516232803,
   "prescription_date": "2023-09-14",
   "medication": "Octinoxate and Titanium dioxide",
   "drug_brand": "PURE SHEER",
   "patient_id": 113428938,
   "doctor_id": 11470
 },
 {
   "prescription_id": 793995263,
   "prescription_date": "2022-12-06",
   "medication": "nifedipine",
   "drug_brand": "Nifedipine",
   "patient_id": 278052903,
   "doctor_id": 11471
 },
 {
   "prescription_id": 862893865,
   "prescription_date": "2023-10-19",
   "medication": "Povidone Iodine",
   "drug_brand": "Povidone-Iodine Prep",
   "patient_id": 27219464,
   "doctor_id": 11472
 },
 {
   "prescription_id": 996342014,
   "prescription_date": "2023-07-20",
   "medication": "Carvedilol",
   "drug_brand": "Carvedilol",
   "patient_id": 629539270,
   "doctor_id": 11473
 },
 {
   "prescription_id": 73898366,
   "prescription_date": "2023-10-02",
   "medication": "benzphetamine hydrochloride",
   "drug_brand": "BENZPHETAMINE HYDROCHLORIDE",
   "patient_id": 522766694,
   "doctor_id": 11474
 },
 {
   "prescription_id": 100343690,
   "prescription_date": "2023-01-02",
   "medication": "ALCOHOL",
   "drug_brand": "Germ Bullet",
   "patient_id": 704278225,
   "doctor_id": 11475
 },
 {
   "prescription_id": 310620720,
   "prescription_date": "2023-01-04",
   "medication": "Lisinopril",
   "drug_brand": "Lisinopril",
   "patient_id": 809434019,
   "doctor_id": 11476
 },
 {
   "prescription_id": 216575810,
   "prescription_date": "2023-11-01",
   "medication": "Acetaminophen",
   "drug_brand": "Childrens Acetaminophen",
   "patient_id": 285355146,
   "doctor_id": 11477
 },
 {
   "prescription_id": 120964955,
   "prescription_date": "2023-03-29",
   "medication": "BENZETHONIUM CHLORIDE",
   "drug_brand": "Magnolia Blossom Scented Hand Sanitizer Anti-Bacterial",
   "patient_id": 448795592,
   "doctor_id": 11478
 },
 {
   "prescription_id": 405261428,
   "prescription_date": "2023-02-27",
   "medication": "CHIONANTHUS VIRGINICUS BARK",
   "drug_brand": "Headache",
   "patient_id": 330412646,
   "doctor_id": 11479
 },
 {
   "prescription_id": 845764435,
   "prescription_date": "2022-11-21",
   "medication": "Cetirizine Hydrochloride",
   "drug_brand": "Childrens",
   "patient_id": 936759440,
   "doctor_id": 11480
 },
 {
   "prescription_id": 912563003,
   "prescription_date": "2023-09-27",
   "medication": "BENZALKONIUM CHLORIDE",
   "drug_brand": "first depHense Alcohol-Free Antiseptic Foam Hand Sanitizer",
   "patient_id": 617333642,
   "doctor_id": 11481
 },
 {
   "prescription_id": 838041939,
   "prescription_date": "2022-12-13",
   "medication": "Benzoyl Peroxide",
   "drug_brand": "Oxy Face Wash",
   "patient_id": 149020403,
   "doctor_id": 11482
 },
 {
   "prescription_id": 363412328,
   "prescription_date": "2023-08-31",
   "medication": "zolmitriptan",
   "drug_brand": "Zolmitriptan",
   "patient_id": 589910221,
   "doctor_id": 11483
 },
 {
   "prescription_id": 398899008,
   "prescription_date": "2023-05-13",
   "medication": "Antipyrine and Benzocaine",
   "drug_brand": "Antipyrine and Benzocaine",
   "patient_id": 518193599,
   "doctor_id": 11484
 },
 {
   "prescription_id": 821111009,
   "prescription_date": "2022-11-18",
   "medication": "Piperacillin and Tazobactam",
   "drug_brand": "Piperacillin and Tazobactam",
   "patient_id": 242159553,
   "doctor_id": 11485
 },
 {
   "prescription_id": 545745411,
   "prescription_date": "2023-02-06",
   "medication": "Mexican Tea",
   "drug_brand": "CHENOPODIUM AMBROSIOIDES POLLEN",
   "patient_id": 134715238,
   "doctor_id": 11486
 },
 {
   "prescription_id": 247067306,
   "prescription_date": "2023-02-05",
   "medication": "Diclofenac Potassium",
   "drug_brand": "CAMBIA",
   "patient_id": 715650420,
   "doctor_id": 11487
 },
 {
   "prescription_id": 146709245,
   "prescription_date": "2023-07-24",
   "medication": "zaleplon",
   "drug_brand": "zaleplon",
   "patient_id": 914591828,
   "doctor_id": 11488
 },
 {
   "prescription_id": 306696701,
   "prescription_date": "2023-10-02",
   "medication": "methotrexate sodium",
   "drug_brand": "METHOTREXATE",
   "patient_id": 972153413,
   "doctor_id": 11489
 },
 {
   "prescription_id": 211960980,
   "prescription_date": "2023-02-27",
   "medication": "RIVASTIGMINE TARTRATE",
   "drug_brand": "RIVASTIGMINE TARTRATE",
   "patient_id": 125269602,
   "doctor_id": 11490
 },
 {
   "prescription_id": 79027243,
   "prescription_date": "2023-05-31",
   "medication": "Escitalopram",
   "drug_brand": "Escitalopram",
   "patient_id": 719924698,
   "doctor_id": 11491
 },
 {
   "prescription_id": 695359939,
   "prescription_date": "2023-11-05",
   "medication": "Acetaminophen, Chlorpheniramine Maleate, Dextromethorphan HBr, Phenylephrine HCl",
   "drug_brand": "Topcare Cold",
   "patient_id": 886564882,
   "doctor_id": 11492
 },
 {
   "prescription_id": 869727766,
   "prescription_date": "2023-03-24",
   "medication": "Zolmitriptan",
   "drug_brand": "Zolmitriptan",
   "patient_id": 91001578,
   "doctor_id": 11493
 },
 {
   "prescription_id": 476794509,
   "prescription_date": "2022-12-26",
   "medication": "OCTINOXATE, OXYBENZONE, TITANIUM DIOXIDE",
   "drug_brand": "DIORSNOW BB Creme 010 White Reveal UV Protection Sunscreen Broad Spectrum SPF 50",
   "patient_id": 772603404,
   "doctor_id": 11494
 },
 {
   "prescription_id": 872684207,
   "prescription_date": "2023-08-03",
   "medication": "Octinoxate and Oxybenzone",
   "drug_brand": "LBEL HYDRATESS",
   "patient_id": 877066317,
   "doctor_id": 11495
 },
 {
   "prescription_id": 240714408,
   "prescription_date": "2022-12-24",
   "medication": "Titanium Dioxide and Zinc Oxide",
   "drug_brand": "Amazonian Clay 12-Hour Full Coverage Foundation Broad Spectrum SPF 15 Sunscreen",
   "patient_id": 898517197,
   "doctor_id": 11496
 },
 {
   "prescription_id": 667905186,
   "prescription_date": "2023-11-04",
   "medication": "AIR",
   "drug_brand": "MEDICAL AIR",
   "patient_id": 753891596,
   "doctor_id": 11497
 },
 {
   "prescription_id": 936759554,
   "prescription_date": "2022-11-17",
   "medication": "Loratadine",
   "drug_brand": "Allergy Relief",
   "patient_id": 62856092,
   "doctor_id": 11498
 },
 {
   "prescription_id": 179049531,
   "prescription_date": "2023-08-22",
   "medication": "OXYGEN",
   "drug_brand": "OXYGEN",
   "patient_id": 986432212,
   "doctor_id": 11499
 },
 {
   "prescription_id": 929495993,
   "prescription_date": "2023-01-24",
   "medication": "Quetiapine fumarate",
   "drug_brand": "SEROQUEL",
   "patient_id": 525470834,
   "doctor_id": 11500
 },
 {
   "prescription_id": 131226744,
   "prescription_date": "2023-02-23",
   "medication": "Tacrolimus",
   "drug_brand": "Tacrolimus",
   "patient_id": 700240328,
   "doctor_id": 11501
 },
 {
   "prescription_id": 355684843,
   "prescription_date": "2022-11-26",
   "medication": "Phendimetrazine Tartrate",
   "drug_brand": "Phendimetrazine Tartrate",
   "patient_id": 320432402,
   "doctor_id": 11502
 },
 {
   "prescription_id": 446766303,
   "prescription_date": "2023-05-31",
   "medication": "Levofloxacin",
   "drug_brand": "Levofloxacin",
   "patient_id": 837749245,
   "doctor_id": 11503
 },
 {
   "prescription_id": 162619125,
   "prescription_date": "2023-04-29",
   "medication": "AVOBENZONE, OCTISALATE, OCTINOXATE, OXYBENZONE",
   "drug_brand": "Total Suncare Sunscreen SPF 15",
   "patient_id": 559388733,
   "doctor_id": 11504
 },
 {
   "prescription_id": 430090804,
   "prescription_date": "2023-07-28",
   "medication": "Dextromethorphan Hydrobromide, Guaifenesin, Phenylephrine Hydrochloride",
   "drug_brand": "Wal Tussin",
   "patient_id": 231392472,
   "doctor_id": 11505
 },
 {
   "prescription_id": 929852202,
   "prescription_date": "2023-04-03",
   "medication": "Apis 30c, Anacardium 30c, Belladonna 30c, Borax 30c, Calc Phos 30c, Chamomilla 30c, Cina 30c, Ipecac 30c, Kali Carb, Lac Can 30c, Stramoniumn 30c",
   "drug_brand": "Kicking and Screaming",
   "patient_id": 821884164,
   "doctor_id": 11506
 },
 {
   "prescription_id": 259414321,
   "prescription_date": "2023-09-19",
   "medication": "Avobenzone, Homosalate,Octisalate, Octocrylene, Oxybenzone",
   "drug_brand": "Ships Ahoy Seashore Sunscreen Broad Spectrum SPF 30",
   "patient_id": 264174687,
   "doctor_id": 11507
 },
 {
   "prescription_id": 612353430,
   "prescription_date": "2022-12-16",
   "medication": "Avobenzone, Homosalate, Octisalate, and Oxybenzone",
   "drug_brand": "Coppertone Sport AccuSpray",
   "patient_id": 84704238,
   "doctor_id": 11508
 },
 {
   "prescription_id": 683718115,
   "prescription_date": "2023-06-22",
   "medication": "Milrinone Lactate",
   "drug_brand": "Milrinone Lactate",
   "patient_id": 666716175,
   "doctor_id": 11509
 },
 {
   "prescription_id": 492633903,
   "prescription_date": "2023-04-25",
   "medication": "Homeopathic Liquid",
   "drug_brand": "Metal-Chord",
   "patient_id": 779941389,
   "doctor_id": 11510
 },
 {
   "prescription_id": 524144042,
   "prescription_date": "2023-10-05",
   "medication": "American Beech",
   "drug_brand": "American Beech",
   "patient_id": 316875241,
   "doctor_id": 11511
 },
 {
   "prescription_id": 413048255,
   "prescription_date": "2023-01-28",
   "medication": "Simvastatin",
   "drug_brand": "Simvastatin",
   "patient_id": 145036888,
   "doctor_id": 11512
 },
 {
   "prescription_id": 83064117,
   "prescription_date": "2023-02-13",
   "medication": "TRICLOSAN",
   "drug_brand": "DG BODY",
   "patient_id": 86604517,
   "doctor_id": 11513
 },
 {
   "prescription_id": 923435345,
   "prescription_date": "2023-10-30",
   "medication": "DOCUSATE SODIUM -SENNOSIDES",
   "drug_brand": "SENEXON-S",
   "patient_id": 848344783,
   "doctor_id": 11514
 },
 {
   "prescription_id": 425070747,
   "prescription_date": "2023-01-17",
   "medication": "Benzocaine, Menthol",
   "drug_brand": "Double Prawn Brand Herbal Oil",
   "patient_id": 565377768,
   "doctor_id": 11515
 },
 {
   "prescription_id": 889020261,
   "prescription_date": "2023-06-27",
   "medication": "White petrolatum",
   "drug_brand": "Creamy Petroleum",
   "patient_id": 816548704,
   "doctor_id": 11516
 },
 {
   "prescription_id": 684268227,
   "prescription_date": "2023-08-16",
   "medication": "Octocrylene and Octinoxate",
   "drug_brand": "Urban Defense",
   "patient_id": 227010807,
   "doctor_id": 11517
 },
 {
   "prescription_id": 606810008,
   "prescription_date": "2022-12-04",
   "medication": "Triamcinolone Acetonide",
   "drug_brand": "Triamcinolone Acetonide",
   "patient_id": 742041410,
   "doctor_id": 11518
 },
 {
   "prescription_id": 426460444,
   "prescription_date": "2023-07-08",
   "medication": "Octinoxate and Titanium dioxide",
   "drug_brand": "SHISEIDO THE MAKEUP PERFECT SMOOTHING COMPACT FOUNDATION (Refill)",
   "patient_id": 354636790,
   "doctor_id": 11519
 },
 {
   "prescription_id": 280721554,
   "prescription_date": "2023-01-12",
   "medication": "meloxicam",
   "drug_brand": "Meloxicam",
   "patient_id": 364779149,
   "doctor_id": 11520
 },
 {
   "prescription_id": 541280529,
   "prescription_date": "2023-02-18",
   "medication": "Alcohol",
   "drug_brand": "Avant Foaming Hand Sanitizer",
   "patient_id": 967051114,
   "doctor_id": 11521
 },
 {
   "prescription_id": 954171943,
   "prescription_date": "2022-12-31",
   "medication": "Rosuvastatin calcium",
   "drug_brand": "CRESTOR",
   "patient_id": 739531310,
   "doctor_id": 11522
 },
 {
   "prescription_id": 977546713,
   "prescription_date": "2022-12-06",
   "medication": "OXYBUTYNIN CHLORIDE",
   "drug_brand": "Oxybutynin Chloride",
   "patient_id": 231170029,
   "doctor_id": 11523
 },
 {
   "prescription_id": 45579951,
   "prescription_date": "2022-12-17",
   "medication": "Paroxetine Hydrochloride",
   "drug_brand": "Paroxetine",
   "patient_id": 415092686,
   "doctor_id": 11524
 },
 {
   "prescription_id": 407376071,
   "prescription_date": "2023-03-11",
   "medication": "Paroxetine Hydrochloride",
   "drug_brand": "Paroxetine",
   "patient_id": 685766483,
   "doctor_id": 11525
 },
 {
   "prescription_id": 332573127,
   "prescription_date": "2023-07-30",
   "medication": "LIDOCAINE HYDROCHLORIDE",
   "drug_brand": "Rite Aid Burn Relief",
   "patient_id": 892466058,
   "doctor_id": 11526
 },
 {
   "prescription_id": 890567543,
   "prescription_date": "2023-02-16",
   "medication": "nafcillin sodium",
   "drug_brand": "Nafcillin",
   "patient_id": 667805562,
   "doctor_id": 11527
 },
 {
   "prescription_id": 574562559,
   "prescription_date": "2023-08-02",
   "medication": "Furosemide",
   "drug_brand": "Furosemide",
   "patient_id": 345421752,
   "doctor_id": 11528
 },
 {
   "prescription_id": 181179485,
   "prescription_date": "2023-08-17",
   "medication": "hypromellose, tetrahydrozoline HCl, zinc sulfate",
   "drug_brand": "Rohto Relief",
   "patient_id": 197677169,
   "doctor_id": 11529
 },
 {
   "prescription_id": 269342070,
   "prescription_date": "2023-03-29",
   "medication": "Acetaminophen, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride",
   "drug_brand": "equate daytime",
   "patient_id": 530103186,
   "doctor_id": 11530
 },
 {
   "prescription_id": 771339834,
   "prescription_date": "2023-07-01",
   "medication": "Multi Vitamin with Fluoride",
   "drug_brand": "Multi Vitamin with Fluoride",
   "patient_id": 844561658,
   "doctor_id": 11531
 },
 {
   "prescription_id": 680925510,
   "prescription_date": "2023-06-13",
   "medication": "salicylic acid",
   "drug_brand": "G.M. Collin Complex Acne",
   "patient_id": 316841341,
   "doctor_id": 11532
 },
 {
   "prescription_id": 754915735,
   "prescription_date": "2023-08-30",
   "medication": "Chlorpheniramine Maleate",
   "drug_brand": "Allergy",
   "patient_id": 322114020,
   "doctor_id": 11533
 },
 {
   "prescription_id": 670374437,
   "prescription_date": "2022-12-25",
   "medication": "Homeopathic Liquid",
   "drug_brand": "Dental-Chord",
   "patient_id": 631285783,
   "doctor_id": 11534
 },
 {
   "prescription_id": 316045058,
   "prescription_date": "2023-04-02",
   "medication": "OCTINOXATE",
   "drug_brand": "flormar REBORN DOUBLE RADIANCE PRIMER HIGHLIGHTER SUNSCREEN BROAD SPECTRUM SPF 10",
   "patient_id": 747193545,
   "doctor_id": 11535
 },
 {
   "prescription_id": 349413147,
   "prescription_date": "2023-09-27",
   "medication": "Ibrutinib",
   "drug_brand": "IMBRUVICA",
   "patient_id": 857842158,
   "doctor_id": 11536
 },
 {
   "prescription_id": 493458121,
   "prescription_date": "2023-09-01",
   "medication": "Aspirin",
   "drug_brand": "Pain Relief Aspirin",
   "patient_id": 847421326,
   "doctor_id": 11537
 },
 {
   "prescription_id": 459877212,
   "prescription_date": "2023-02-04",
   "medication": "Esomeprazole magnesium",
   "drug_brand": "NEXIUM",
   "patient_id": 422046345,
   "doctor_id": 11538
 },
 {
   "prescription_id": 199982835,
   "prescription_date": "2023-08-11",
   "medication": "DEXTRAN 70, POLYETHYLENE GLYCOL 400, POVIDONE, TETRAHYDROZOLINE HCL",
   "drug_brand": "OPTICAL ADVANCED EYE",
   "patient_id": 62674061,
   "doctor_id": 11539
 },
 {
   "prescription_id": 417958880,
   "prescription_date": "2023-10-07",
   "medication": "Loratadine",
   "drug_brand": "Claritin",
   "patient_id": 601918930,
   "doctor_id": 11540
 },
 {
   "prescription_id": 295523732,
   "prescription_date": "2023-06-02",
   "medication": "Formicum acidum, Gambogia, Natrum bicarbonicum, Natrum nitricum, Natrum Nitrosum, Natrum sulphuricum, Nux vomica, Phosphoricum acidum, Phytolacca decandra, Rosa canina, Saccharinum",
   "drug_brand": "Aller-Detox Food Additives and Preservatives",
   "patient_id": 173607718,
   "doctor_id": 11541
 },
 {
   "prescription_id": 781111203,
   "prescription_date": "2023-02-19",
   "medication": "atorvastatin calcium",
   "drug_brand": "Atorvastatin Calcium",
   "patient_id": 785973041,
   "doctor_id": 11542
 },
 {
   "prescription_id": 299287501,
   "prescription_date": "2023-06-12",
   "medication": "Phenazopyridine Hydrochloride",
   "drug_brand": "Phenazopyridine Hydrochloride",
   "patient_id": 291078712,
   "doctor_id": 11543
 },
 {
   "prescription_id": 372645975,
   "prescription_date": "2023-08-07",
   "medication": "Absinthium, Adenosinum cyclophosphoricum, Adrenalinum, Adrenocorticotrophin, Allium cepa, Ambrosia artemissfolia, Caulophyllum thalictroides, Conium maculatum, Cortisone aceticum, Euphrasia officinalis, Fagopyrum esculentum, Galphimia glauca, Histaminum hydrochloricum, Kali muriaticum, Melilotus officinalis, Mucosa nasalis suis, Natrum muriaticum, RNA, Rumex crispus, Sabadilla, Secale cornutum",
   "drug_brand": "AllergyEase Plains",
   "patient_id": 425269856,
   "doctor_id": 11544
 },
 {
   "prescription_id": 695761727,
   "prescription_date": "2023-10-23",
   "medication": "Aletris farinosa, Apis mellifica, Arnica montana, Belladonna, Caulophyllum thalictroides, Chamomilla, Cimicifuga racemosa, Ferrum metallicum, Kali carbonicum, Sabina, Secale cornutum, Viburnum opulus",
   "drug_brand": "Birth Ease",
   "patient_id": 226934857,
   "doctor_id": 11545
 },
 {
   "prescription_id": 903522810,
   "prescription_date": "2023-02-14",
   "medication": "Sodium Fluoride",
   "drug_brand": "Rembrandt Canker Sore",
   "patient_id": 120223760,
   "doctor_id": 11546
 },
 {
   "prescription_id": 64649834,
   "prescription_date": "2023-01-17",
   "medication": "ETHYL ALCOHOL",
   "drug_brand": "ORCHID BY H E B",
   "patient_id": 448283482,
   "doctor_id": 11547
 },
 {
   "prescription_id": 286813280,
   "prescription_date": "2023-11-13",
   "medication": "Fucus vesiculosus, Lycopodium clavatum, Natrum muriaticum, Spongia tosta, Thyroidinum",
   "drug_brand": "Homeopathic Thyroid Formula",
   "patient_id": 170598357,
   "doctor_id": 11548
 },
 {
   "prescription_id": 622007997,
   "prescription_date": "2022-12-08",
   "medication": "Vasopressin",
   "drug_brand": "Vasopressin",
   "patient_id": 421045209,
   "doctor_id": 11549
 },
 {
   "prescription_id": 794956730,
   "prescription_date": "2022-12-31",
   "medication": "Simvastatin",
   "drug_brand": "Simvastatin",
   "patient_id": 607681595,
   "doctor_id": 11550
 },
 {
   "prescription_id": 501887693,
   "prescription_date": "2023-06-28",
   "medication": "Baptisia tinctoria, Echinacea, Hydrastis canadensis, Lym D Nosode, Arsenicum album, Bryonia, Chelidonium majus, Colchicum autumnale, Kalmia latifolia, Ledum palustre, Lycopodium clavatum, Phosphorus, Rhus toxicodendron,",
   "drug_brand": "Lyme",
   "patient_id": 889722477,
   "doctor_id": 11551
 },
 {
   "prescription_id": 842039415,
   "prescription_date": "2023-01-21",
   "medication": "TOPIRAMATE",
   "drug_brand": "TOPIRAMATE",
   "patient_id": 203000145,
   "doctor_id": 11302
 },
 {
   "prescription_id": 3656310,
   "prescription_date": "2023-07-28",
   "medication": "House Dust",
   "drug_brand": "House Dust",
   "patient_id": 62505395,
   "doctor_id": 11303
 },
 {
   "prescription_id": 122892748,
   "prescription_date": "2023-09-12",
   "medication": "Acetaminophen",
   "drug_brand": "childrens fever reducer and pain reliever",
   "patient_id": 814755149,
   "doctor_id": 11304
 },
 {
   "prescription_id": 540737015,
   "prescription_date": "2023-02-04",
   "medication": "not applicable",
   "drug_brand": "Acne",
   "patient_id": 981089876,
   "doctor_id": 11305
 },
 {
   "prescription_id": 837517493,
   "prescription_date": "2023-03-13",
   "medication": "Simvastatin",
   "drug_brand": "Simvastatin",
   "patient_id": 333845615,
   "doctor_id": 11306
 },
 {
   "prescription_id": 246977070,
   "prescription_date": "2023-06-09",
   "medication": "Felbamate",
   "drug_brand": "Felbamate",
   "patient_id": 553237679,
   "doctor_id": 11307
 },
 {
   "prescription_id": 963696580,
   "prescription_date": "2023-03-27",
   "medication": "Dimethicone",
   "drug_brand": "Kendall Moisture Barrier",
   "patient_id": 204913870,
   "doctor_id": 11308
 },
 {
   "prescription_id": 681378859,
   "prescription_date": "2022-12-02",
   "medication": "ALCOHOL",
   "drug_brand": "Fast",
   "patient_id": 206636350,
   "doctor_id": 11309
 },
 {
   "prescription_id": 371971711,
   "prescription_date": "2023-06-01",
   "medication": "Caffeine",
   "drug_brand": "Stay Awake",
   "patient_id": 790878684,
   "doctor_id": 11310
 },
 {
   "prescription_id": 312559297,
   "prescription_date": "2022-11-21",
   "medication": "haloperidol",
   "drug_brand": "Haloperidol",
   "patient_id": 975972568,
   "doctor_id": 11311
 },
 {
   "prescription_id": 989089405,
   "prescription_date": "2022-12-28",
   "medication": "SODIUM PHOSPHATE, MONOBASIC, MONOHYDRATE, AND SODIUM PHOSPHATE, DIBASIC ANHYDROUS",
   "drug_brand": "Visicol",
   "patient_id": 225299968,
   "doctor_id": 11312
 },
 {
   "prescription_id": 444582180,
   "prescription_date": "2022-12-09",
   "medication": "Clonidine Hydrochloride",
   "drug_brand": "Clonidine Hydrochloride",
   "patient_id": 290533830,
   "doctor_id": 11313
 },
 {
   "prescription_id": 13895437,
   "prescription_date": "2023-06-18",
   "medication": "Acetaminophen",
   "drug_brand": "Extra Strength Acetaminophen",
   "patient_id": 426101339,
   "doctor_id": 11314
 },
 {
   "prescription_id": 736170966,
   "prescription_date": "2023-05-31",
   "medication": "Naproxen Sodium",
   "drug_brand": "rx act all day pain relief",
   "patient_id": 399388732,
   "doctor_id": 11315
 },
 {
   "prescription_id": 964754686,
   "prescription_date": "2023-02-16",
   "medication": "Hydroxyzine Hydrochloride",
   "drug_brand": "Hydroxyzine Hydrochloride",
   "patient_id": 450658408,
   "doctor_id": 11316
 },
 {
   "prescription_id": 560727429,
   "prescription_date": "2023-09-02",
   "medication": "Levetiracetam",
   "drug_brand": "Levetiracetam",
   "patient_id": 225825384,
   "doctor_id": 11317
 },
 {
   "prescription_id": 79888423,
   "prescription_date": "2022-12-29",
   "medication": "Benzethonium chloride",
   "drug_brand": "Lysol",
   "patient_id": 88420477,
   "doctor_id": 11318
 },
 {
   "prescription_id": 647038014,
   "prescription_date": "2023-07-05",
   "medication": "methylphenidate hydrochloride",
   "drug_brand": "METHYLIN",
   "patient_id": 915669969,
   "doctor_id": 11319
 },
 {
   "prescription_id": 570869097,
   "prescription_date": "2023-07-11",
   "medication": "ondansetron hydrochloride",
   "drug_brand": "ondansetron hydrochloride",
   "patient_id": 298778071,
   "doctor_id": 11320
 },
 {
   "prescription_id": 397618396,
   "prescription_date": "2023-02-25",
   "medication": "Octinoxate and Titanium Dioxide",
   "drug_brand": "No7 Beautifully Matte Foundation Sunscreen Broad Spectrum SPF 15 Wheat",
   "patient_id": 296897508,
   "doctor_id": 11321
 },
 {
   "prescription_id": 378029901,
   "prescription_date": "2023-10-25",
   "medication": "Doxycycline",
   "drug_brand": "Doxycycline",
   "patient_id": 669017571,
   "doctor_id": 11322
 },
 {
   "prescription_id": 242634818,
   "prescription_date": "2023-09-15",
   "medication": "ALETRIS FARINOSA ROOT - ALDESLEUKIN - ALPHA LIPOIC ACID - ATOSIBAN - CHASTE TREE - COBALAMIN - COPPER - CORTICOTROPIN - COTTON - CYCLAMEN PURPURASCENS TUBER - DOPAMINE - FOLIC ACID - FOLLICLE STIMULAT",
   "drug_brand": "GUNA-VENUS",
   "patient_id": 641421685,
   "doctor_id": 11323
 },
 {
   "prescription_id": 616854067,
   "prescription_date": "2023-09-14",
   "medication": "Crab",
   "drug_brand": "CRAB",
   "patient_id": 952728246,
   "doctor_id": 11324
 },
 {
   "prescription_id": 691093364,
   "prescription_date": "2023-10-08",
   "medication": "ENALAPRIL MALEATE",
   "drug_brand": "ENALAPRIL MALEATE",
   "patient_id": 73649927,
   "doctor_id": 11325
 },
 {
   "prescription_id": 641951885,
   "prescription_date": "2023-08-25",
   "medication": "Etodolac",
   "drug_brand": "Etodolac",
   "patient_id": 671507928,
   "doctor_id": 11326
 },
 {
   "prescription_id": 442323821,
   "prescription_date": "2022-12-29",
   "medication": "Argentum Bryophyllum",
   "drug_brand": "Argentum Bryophyllum",
   "patient_id": 286025845,
   "doctor_id": 11327
 },
 {
   "prescription_id": 180107638,
   "prescription_date": "2023-03-30",
   "medication": "FOSAPREPITANT DIMEGLUMINE",
   "drug_brand": "EMEND",
   "patient_id": 304922871,
   "doctor_id": 11328
 },
 {
   "prescription_id": 160863979,
   "prescription_date": "2023-02-02",
   "medication": "Carvedilol",
   "drug_brand": "Carvedilol",
   "patient_id": 582980783,
   "doctor_id": 11329
 },
 {
   "prescription_id": 789795825,
   "prescription_date": "2023-01-29",
   "medication": "Fentanyl Citrate",
   "drug_brand": "Fentanyl Citrate",
   "patient_id": 288518803,
   "doctor_id": 11330
 },
 {
   "prescription_id": 981240503,
   "prescription_date": "2023-03-10",
   "medication": "BENZOCAINE, ISOPROPYL ALCOHOL",
   "drug_brand": "MK Sting Relief Pads",
   "patient_id": 484167075,
   "doctor_id": 11331
 },
 {
   "prescription_id": 834924429,
   "prescription_date": "2023-03-03",
   "medication": "ESCITALOPRAM OXALATE",
   "drug_brand": "Lexapro",
   "patient_id": 772005956,
   "doctor_id": 11332
 },
 {
   "prescription_id": 842438631,
   "prescription_date": "2023-07-12",
   "medication": "White Oak",
   "drug_brand": "White Oak",
   "patient_id": 264582659,
   "doctor_id": 11333
 },
 {
   "prescription_id": 367060004,
   "prescription_date": "2023-05-13",
   "medication": "Gabapentin",
   "drug_brand": "Gabapentin",
   "patient_id": 592112447,
   "doctor_id": 11334
 },
 {
   "prescription_id": 175439459,
   "prescription_date": "2023-04-16",
   "medication": "Calendula officinalis",
   "drug_brand": "Calendula",
   "patient_id": 894373636,
   "doctor_id": 11335
 },
 {
   "prescription_id": 227729402,
   "prescription_date": "2023-08-30",
   "medication": "Salt Grass",
   "drug_brand": "DISTICHLIS SPICATA POLLEN",
   "patient_id": 497715155,
   "doctor_id": 11336
 },
 {
   "prescription_id": 25416013,
   "prescription_date": "2023-07-03",
   "medication": "Sulfamethoxazole and Trimethoprim",
   "drug_brand": "Bactrim",
   "patient_id": 438624573,
   "doctor_id": 11337
 },
 {
   "prescription_id": 102289362,
   "prescription_date": "2023-03-27",
   "medication": "Mercurialis Calendula Healing",
   "drug_brand": "Mercurialis Calendula Healing",
   "patient_id": 345715688,
   "doctor_id": 11338
 },
 {
   "prescription_id": 161635100,
   "prescription_date": "2023-03-04",
   "medication": "TITANIUM DIOXIDE",
   "drug_brand": "SHISEIDO THE MAKEUP FOUNDATION",
   "patient_id": 132559883,
   "doctor_id": 11339
 },
 {
   "prescription_id": 846513872,
   "prescription_date": "2023-02-20",
   "medication": "Hydrocortisone Acetate Pramoxine Hcl",
   "drug_brand": "Hydrocortisone Acetate Pramoxine Hcl",
   "patient_id": 967079673,
   "doctor_id": 11340
 },
 {
   "prescription_id": 328911711,
   "prescription_date": "2023-06-11",
   "medication": "ESLICARBAZEPINE ACETATE",
   "drug_brand": "Aptiom",
   "patient_id": 477166121,
   "doctor_id": 11341
 },
 {
   "prescription_id": 489527006,
   "prescription_date": "2023-09-27",
   "medication": "False Ragweed Bur",
   "drug_brand": "AMBROSIA ACANTHICARPA POLLEN",
   "patient_id": 182844422,
   "doctor_id": 11342
 },
 {
   "prescription_id": 270526393,
   "prescription_date": "2023-01-21",
   "medication": "GABAPENTIN",
   "drug_brand": "GABAPENTIN",
   "patient_id": 547880674,
   "doctor_id": 11343
 },
 {
   "prescription_id": 120571533,
   "prescription_date": "2023-10-12",
   "medication": "Zinc Oxide, Titanium Dioxide",
   "drug_brand": "Josie Maran Argan Daily Moisturizer SPF47 Protect and Perfect",
   "patient_id": 995701962,
   "doctor_id": 11344
 },
 {
   "prescription_id": 508805346,
   "prescription_date": "2023-07-21",
   "medication": "Isopropyl Alcohol",
   "drug_brand": "Alcohol Prep Pad",
   "patient_id": 741359872,
   "doctor_id": 11345
 },
 {
   "prescription_id": 154448411,
   "prescription_date": "2023-10-17",
   "medication": "Sennosides",
   "drug_brand": "Laxative pills",
   "patient_id": 20314008,
   "doctor_id": 11346
 },
 {
   "prescription_id": 238702139,
   "prescription_date": "2023-01-23",
   "medication": "Aspirin",
   "drug_brand": "Low Dose Aspirin",
   "patient_id": 646819878,
   "doctor_id": 11347
 },
 {
   "prescription_id": 610113393,
   "prescription_date": "2023-02-24",
   "medication": "Salicylic Acid",
   "drug_brand": "Salicylic Acid",
   "patient_id": 886992264,
   "doctor_id": 11348
 },
 {
   "prescription_id": 872161015,
   "prescription_date": "2023-03-23",
   "medication": "captopril and hydrochlorothiazide",
   "drug_brand": "Captopril and Hydrochlorothiazide",
   "patient_id": 798580686,
   "doctor_id": 11349
 },
 {
   "prescription_id": 242980924,
   "prescription_date": "2023-06-24",
   "medication": "Loratadine",
   "drug_brand": "kirkland signature allerclear",
   "patient_id": 137845579,
   "doctor_id": 11350
 },
 {
   "prescription_id": 532120877,
   "prescription_date": "2023-01-13",
   "medication": "HYDROGEN PEROXIDE",
   "drug_brand": "Hydrogen Peroxide",
   "patient_id": 844857052,
   "doctor_id": 11351
 },
 {
   "prescription_id": 32655613,
   "prescription_date": "2023-09-03",
   "medication": "EUCALYPTOL, MENTHOL, METHYL SALICYLATE, THYMOL",
   "drug_brand": "Royal Mouthwash Fresh and Clean Original Mint",
   "patient_id": 561739729,
   "doctor_id": 11352
 },
 {
   "prescription_id": 404040600,
   "prescription_date": "2022-11-15",
   "medication": "Hydrocodone Bitartrate and Acetaminophen",
   "drug_brand": "Hydrocodone Bitartrate and Acetaminophen",
   "patient_id": 589802751,
   "doctor_id": 11353
 },
 {
   "prescription_id": 463972829,
   "prescription_date": "2023-02-19",
   "medication": "Aurum 6",
   "drug_brand": "Aurum 6",
   "patient_id": 938341356,
   "doctor_id": 11354
 },
 {
   "prescription_id": 812284032,
   "prescription_date": "2023-11-08",
   "medication": "Torsemide",
   "drug_brand": "Torsemide",
   "patient_id": 412252964,
   "doctor_id": 11355
 },
 {
   "prescription_id": 696316096,
   "prescription_date": "2022-11-17",
   "medication": "Acetaminophen and DIPHENHYDRAMINE HYDROCHLORIDE",
   "drug_brand": "Acetaminophen PM Rapid Release",
   "patient_id": 688954037,
   "doctor_id": 11356
 },
 {
   "prescription_id": 639734238,
   "prescription_date": "2023-07-14",
   "medication": "Glycerin",
   "drug_brand": "Aqua Rush Cover Cushion",
   "patient_id": 195133202,
   "doctor_id": 11357
 },
 {
   "prescription_id": 986623950,
   "prescription_date": "2023-04-27",
   "medication": "Methylphenidate hydrochloride",
   "drug_brand": "Concerta",
   "patient_id": 993194584,
   "doctor_id": 11358
 },
 {
   "prescription_id": 583157990,
   "prescription_date": "2023-06-03",
   "medication": "light mineral oil and mineral oil",
   "drug_brand": "Soothe XP",
   "patient_id": 751677696,
   "doctor_id": 11359
 },
 {
   "prescription_id": 632221002,
   "prescription_date": "2023-09-16",
   "medication": "Ibuprofen",
   "drug_brand": "ibuprofen",
   "patient_id": 629097045,
   "doctor_id": 11360
 },
 {
   "prescription_id": 736175321,
   "prescription_date": "2023-05-28",
   "medication": "Brome Grass",
   "drug_brand": "Brome Grass",
   "patient_id": 734762728,
   "doctor_id": 11361
 },
 {
   "prescription_id": 287976736,
   "prescription_date": "2023-08-18",
   "medication": "Morphine Sulfate",
   "drug_brand": "Morphine Sulfate",
   "patient_id": 184662655,
   "doctor_id": 11362
 },
 {
   "prescription_id": 597236130,
   "prescription_date": "2023-11-10",
   "medication": "Titanium Dioxide",
   "drug_brand": "ESIKA",
   "patient_id": 636811037,
   "doctor_id": 11363
 },
 {
   "prescription_id": 775433990,
   "prescription_date": "2022-11-29",
   "medication": "Diltiazem Hydrochloride",
   "drug_brand": "Diltiazem Hydrochloride",
   "patient_id": 633502640,
   "doctor_id": 11364
 },
 {
   "prescription_id": 654347166,
   "prescription_date": "2023-01-06",
   "medication": "Polyvinyl Alcohol, Povidone",
   "drug_brand": "REFRESH Classic",
   "patient_id": 539492226,
   "doctor_id": 11365
 },
 {
   "prescription_id": 747024555,
   "prescription_date": "2022-11-23",
   "medication": "Bismuth subsalicylate",
   "drug_brand": "Stomach Relief",
   "patient_id": 359353686,
   "doctor_id": 11366
 },
 {
   "prescription_id": 734621422,
   "prescription_date": "2023-04-13",
   "medication": "Pantoprazole Sodium",
   "drug_brand": "Pantoprazole Sodium",
   "patient_id": 804688279,
   "doctor_id": 11367
 },
 {
   "prescription_id": 708816922,
   "prescription_date": "2023-08-01",
   "medication": "Hydrogen Peroxide",
   "drug_brand": "Hydrogen Peroxide",
   "patient_id": 510708767,
   "doctor_id": 11368
 },
 {
   "prescription_id": 725594002,
   "prescription_date": "2023-02-03",
   "medication": "Allopurinol",
   "drug_brand": "Allopurinol",
   "patient_id": 667148888,
   "doctor_id": 11369
 },
 {
   "prescription_id": 260885583,
   "prescription_date": "2023-01-12",
   "medication": "ALUMINUM CHLOROHYDRATE",
   "drug_brand": "Roll On Anti Perspirant",
   "patient_id": 439725005,
   "doctor_id": 11370
 },
 {
   "prescription_id": 374775741,
   "prescription_date": "2023-03-21",
   "medication": "Guaifenesin",
   "drug_brand": "up and up childrens mucus relief",
   "patient_id": 366580016,
   "doctor_id": 11371
 },
 {
   "prescription_id": 716329104,
   "prescription_date": "2023-03-09",
   "medication": "OCTINOXATE and TITANIUM DIOXIDE",
   "drug_brand": "Ceramide Lift and Firm Makeup Broad Spectrum Sunscreen SPF 15 Vanilla Shell",
   "patient_id": 832436540,
   "doctor_id": 11372
 },
 {
   "prescription_id": 577558059,
   "prescription_date": "2023-10-03",
   "medication": "Doxazosin",
   "drug_brand": "Doxazosin",
   "patient_id": 118189821,
   "doctor_id": 11373
 },
 {
   "prescription_id": 327235437,
   "prescription_date": "2023-07-01",
   "medication": "TECHNETIUM TC-99M SODIUM PERTECHNETATE",
   "drug_brand": "Technetium Tc99m Generator",
   "patient_id": 142386290,
   "doctor_id": 11374
 },
 {
   "prescription_id": 96173480,
   "prescription_date": "2023-11-03",
   "medication": "Methylergonovine Maleate",
   "drug_brand": "Methylergonovine Maleate",
   "patient_id": 10890207,
   "doctor_id": 11375
 },
 {
   "prescription_id": 174487443,
   "prescription_date": "2022-11-15",
   "medication": "Glycerin",
   "drug_brand": "Lubriderm Intense Skin Repair",
   "patient_id": 364075393,
   "doctor_id": 11376
 },
 {
   "prescription_id": 26871029,
   "prescription_date": "2023-04-19",
   "medication": "Acetaminophen, Diphenhydramine HCl, Phenylephrine HCl",
   "drug_brand": "Wal-Dryl Severe Allergy and Sinus Headache",
   "patient_id": 841358317,
   "doctor_id": 11377
 },
 {
   "prescription_id": 444896358,
   "prescription_date": "2023-02-04",
   "medication": "Pseudoephedrine hydrochloride",
   "drug_brand": "Childrens Uniphed",
   "patient_id": 830073825,
   "doctor_id": 11378
 },
 {
   "prescription_id": 376740955,
   "prescription_date": "2023-10-04",
   "medication": "Penicillin V Potassium",
   "drug_brand": "Penicillin V Potassium",
   "patient_id": 616964315,
   "doctor_id": 11379
 },
 {
   "prescription_id": 332319080,
   "prescription_date": "2023-07-25",
   "medication": "OCTINOXATE, ZINC OXIDE",
   "drug_brand": "Tropical Vanilla Body Sunscreen Broad Spectrum SPF 32",
   "patient_id": 289140264,
   "doctor_id": 11380
 },
 {
   "prescription_id": 295580481,
   "prescription_date": "2023-01-07",
   "medication": "NOT APPLICABLE",
   "drug_brand": "Female Stimulant",
   "patient_id": 564585080,
   "doctor_id": 11381
 },
 {
   "prescription_id": 224576452,
   "prescription_date": "2023-02-16",
   "medication": "Aesculus, Cina, Croton, Fagopyrum, Kali sulph, Sulphur",
   "drug_brand": "Anal Itch Assist",
   "patient_id": 425903349,
   "doctor_id": 11382
 },
 {
   "prescription_id": 907269136,
   "prescription_date": "2023-10-28",
   "medication": "Polyethylene Glycol 3350",
   "drug_brand": "Polyethylene Glycol 3350",
   "patient_id": 79773476,
   "doctor_id": 11383
 },
 {
   "prescription_id": 597593580,
   "prescription_date": "2023-02-23",
   "medication": "Nicotine Polacrilex",
   "drug_brand": "Good Neighbor Pharmacy Nicotine",
   "patient_id": 177646991,
   "doctor_id": 11384
 },
 {
   "prescription_id": 677859883,
   "prescription_date": "2023-08-07",
   "medication": "Acetaminophen, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride",
   "drug_brand": "wal flu severe cold and cough",
   "patient_id": 846745304,
   "doctor_id": 11385
 },
 {
   "prescription_id": 701400803,
   "prescription_date": "2023-08-15",
   "medication": "ETHYL ALCOHOL",
   "drug_brand": "Instant Hand Sanitizer Fresh Aloe",
   "patient_id": 988770075,
   "doctor_id": 11386
 },
 {
   "prescription_id": 846134136,
   "prescription_date": "2023-05-17",
   "medication": "PROMETHAZINE HYDROCHLORIDE",
   "drug_brand": "PROMETHAZINE HYDROCHLORIDE",
   "patient_id": 791742898,
   "doctor_id": 11387
 },
 {
   "prescription_id": 973849613,
   "prescription_date": "2022-11-27",
   "medication": "Sodium Fluoride",
   "drug_brand": "Burkhart",
   "patient_id": 529288405,
   "doctor_id": 11388
 },
 {
   "prescription_id": 647170996,
   "prescription_date": "2023-01-26",
   "medication": "Estradiol",
   "drug_brand": "Estradiol",
   "patient_id": 314273459,
   "doctor_id": 11389
 },
 {
   "prescription_id": 18327677,
   "prescription_date": "2023-02-10",
   "medication": "Ethyl Alcohol",
   "drug_brand": "Appeal Alcohol Foaming Hand Sanitizer",
   "patient_id": 797445830,
   "doctor_id": 11390
 },
 {
   "prescription_id": 849381731,
   "prescription_date": "2023-03-05",
   "medication": "venlafaxine hydrochloride",
   "drug_brand": "Effexor",
   "patient_id": 453787601,
   "doctor_id": 11391
 },
 {
   "prescription_id": 44235147,
   "prescription_date": "2022-11-16",
   "medication": "Enalapril Maleate",
   "drug_brand": "Vasotec",
   "patient_id": 388503082,
   "doctor_id": 11392
 },
 {
   "prescription_id": 913309351,
   "prescription_date": "2023-03-03",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 640029536,
   "doctor_id": 11393
 },
 {
   "prescription_id": 387659324,
   "prescription_date": "2023-08-15",
   "medication": "Risperidone",
   "drug_brand": "Risperidone",
   "patient_id": 735342884,
   "doctor_id": 11394
 },
 {
   "prescription_id": 865110024,
   "prescription_date": "2023-03-31",
   "medication": "sumatriptan succinate",
   "drug_brand": "sumatriptan succinate",
   "patient_id": 585713445,
   "doctor_id": 11395
 },
 {
   "prescription_id": 506675805,
   "prescription_date": "2023-06-10",
   "medication": "Hepatitis B Immune Globulin (Human)",
   "drug_brand": "HepaGam B",
   "patient_id": 393558923,
   "doctor_id": 11396
 },
 {
   "prescription_id": 416321767,
   "prescription_date": "2023-02-13",
   "medication": "phenobarbital elixir",
   "drug_brand": "Donnatal",
   "patient_id": 757255325,
   "doctor_id": 11397
 },
 {
   "prescription_id": 974913807,
   "prescription_date": "2023-03-09",
   "medication": "hydrocortisone",
   "drug_brand": "Duane Reade",
   "patient_id": 308646340,
   "doctor_id": 11398
 },
 {
   "prescription_id": 603332554,
   "prescription_date": "2023-03-17",
   "medication": "Venlafaxine Hydrochloride",
   "drug_brand": "Venlafaxine Hydrochloride",
   "patient_id": 687945795,
   "doctor_id": 11399
 },
 {
   "prescription_id": 939763697,
   "prescription_date": "2023-02-02",
   "medication": "ECHINACEA ANGUSTIFOLIA, ECHINACEA PURPUREA, ACONITUM NAPELLUS, ARNICA MONTANA, CALENDULA OFFICIANALIS, HAMAMELIS VIRGINIANA, BELLADONNA, BELLIS PERENNIS, CHAMOMILLIA, MILLEFOLIUM, HYPERICUM PERFORATUM, SYMPHYTUM OFFICINALE, COLCHICINUM",
   "drug_brand": "TRANZGEL",
   "patient_id": 623031103,
   "doctor_id": 11400
 },
 {
   "prescription_id": 72651913,
   "prescription_date": "2023-02-01",
   "medication": "Titanium Dioxide",
   "drug_brand": "bareMinerals bareSkin Pure Brightening Serum Foundation Broad Spectrum SPF 20",
   "patient_id": 876250646,
   "doctor_id": 11401
 },
 {
   "prescription_id": 774258852,
   "prescription_date": "2023-03-24",
   "medication": "Titanium Dioxide",
   "drug_brand": "Golden Medium Foundation SPF 15",
   "patient_id": 344454710,
   "doctor_id": 11402
 },
 {
   "prescription_id": 65579292,
   "prescription_date": "2023-03-15",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE",
   "drug_brand": "CD DIORSKIN NUDE SKIN-GLOWING MAKEUP SUNSCREEN BROAD SPECTRUM SPF 15 063 Amber",
   "patient_id": 995352285,
   "doctor_id": 11403
 },
 {
   "prescription_id": 949299187,
   "prescription_date": "2023-06-30",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 973927366,
   "doctor_id": 11404
 },
 {
   "prescription_id": 368679711,
   "prescription_date": "2023-04-21",
   "medication": "nitroglycerin",
   "drug_brand": "NITROGLYCERIN",
   "patient_id": 218742481,
   "doctor_id": 11405
 },
 {
   "prescription_id": 827092263,
   "prescription_date": "2023-01-18",
   "medication": "Octinoxate",
   "drug_brand": "No7 Lift and Luminate Foundation Sunscreen Broad Spectrum SPF 15 Deeply Beige",
   "patient_id": 517790823,
   "doctor_id": 11406
 },
 {
   "prescription_id": 519586999,
   "prescription_date": "2023-01-07",
   "medication": "MIDAZOLAM HYDROCHLORIDE",
   "drug_brand": "Midazolam",
   "patient_id": 964797340,
   "doctor_id": 11407
 },
 {
   "prescription_id": 687807620,
   "prescription_date": "2023-08-22",
   "medication": "simvastatin",
   "drug_brand": "simvastatin",
   "patient_id": 575157065,
   "doctor_id": 11408
 },
 {
   "prescription_id": 528039841,
   "prescription_date": "2023-01-28",
   "medication": "ranitidine hydrochloride",
   "drug_brand": "ZANTAC",
   "patient_id": 468469624,
   "doctor_id": 11409
 },
 {
   "prescription_id": 534937297,
   "prescription_date": "2023-03-03",
   "medication": "Wheat Smut",
   "drug_brand": "Wheat Smut",
   "patient_id": 883643157,
   "doctor_id": 11410
 },
 {
   "prescription_id": 663092903,
   "prescription_date": "2023-05-26",
   "medication": "simvastatin",
   "drug_brand": "simvastatin",
   "patient_id": 704435054,
   "doctor_id": 11411
 },
 {
   "prescription_id": 979498836,
   "prescription_date": "2023-05-03",
   "medication": "BENZALKONIUM CHLORIDE",
   "drug_brand": "CLEANpHIRST Alcohol Free Antiseptic Hand Sanitizer",
   "patient_id": 948301490,
   "doctor_id": 11412
 },
 {
   "prescription_id": 560724164,
   "prescription_date": "2023-10-11",
   "medication": "DOXYCYCLINE",
   "drug_brand": "Doxy 100",
   "patient_id": 992901019,
   "doctor_id": 11413
 },
 {
   "prescription_id": 609005333,
   "prescription_date": "2023-10-11",
   "medication": "oxybutynin",
   "drug_brand": "Oxytrol For Women",
   "patient_id": 462510418,
   "doctor_id": 11414
 },
 {
   "prescription_id": 483430600,
   "prescription_date": "2023-08-04",
   "medication": "ATROPINE SULFATE",
   "drug_brand": "Atropine Sulfate",
   "patient_id": 386514075,
   "doctor_id": 11415
 },
 {
   "prescription_id": 659181148,
   "prescription_date": "2023-02-20",
   "medication": "Mirtazapine",
   "drug_brand": "Mirtazapine",
   "patient_id": 1590456,
   "doctor_id": 11416
 },
 {
   "prescription_id": 910626098,
   "prescription_date": "2023-08-25",
   "medication": "OCTISALATE, TITANIUM DIOXIDE",
   "drug_brand": "FLAWLESS FINISH FOUNDATION",
   "patient_id": 54935676,
   "doctor_id": 11417
 },
 {
   "prescription_id": 311171704,
   "prescription_date": "2023-08-06",
   "medication": "Kali phos, Nat phos, Nat sulph",
   "drug_brand": "Triple Complex Mood Tonic",
   "patient_id": 161105413,
   "doctor_id": 11418
 },
 {
   "prescription_id": 86342595,
   "prescription_date": "2023-08-28",
   "medication": "N-ACETYLGLUCOSAMINE",
   "drug_brand": "Cheon Shim Bo Yun",
   "patient_id": 146106230,
   "doctor_id": 11419
 },
 {
   "prescription_id": 366056535,
   "prescription_date": "2023-03-07",
   "medication": "Loratadine",
   "drug_brand": "Loratadine",
   "patient_id": 681225657,
   "doctor_id": 11420
 },
 {
   "prescription_id": 408516699,
   "prescription_date": "2023-04-19",
   "medication": "Acetaminophen, Diphenhydramine HCl",
   "drug_brand": "Non-Aspirin PM",
   "patient_id": 390007509,
   "doctor_id": 11421
 },
 {
   "prescription_id": 493848503,
   "prescription_date": "2023-01-27",
   "medication": "Acetaminophen, Dextromethorphan Hydrobromide, and Phenylephrine Hydrochloride",
   "drug_brand": "DayQuil",
   "patient_id": 648341355,
   "doctor_id": 11422
 },
 {
   "prescription_id": 68782544,
   "prescription_date": "2023-01-28",
   "medication": "OCTISALATE, AVOBENZONE, HOMOSALATE",
   "drug_brand": "DAYWEAR",
   "patient_id": 179766140,
   "doctor_id": 11423
 },
 {
   "prescription_id": 545936628,
   "prescription_date": "2023-05-09",
   "medication": "TITANIUM DIOXIDE and ZINC OXIDE",
   "drug_brand": "Mustela SPF 50",
   "patient_id": 143586442,
   "doctor_id": 11424
 },
 {
   "prescription_id": 106773189,
   "prescription_date": "2023-02-21",
   "medication": "Aspirin",
   "drug_brand": "Safety Coated Enteric Aspirin",
   "patient_id": 976032998,
   "doctor_id": 11425
 },
 {
   "prescription_id": 758178489,
   "prescription_date": "2023-10-02",
   "medication": "OCTINOXATE and TITANIUM DIOXIDE",
   "drug_brand": "SHISEIDO UV PROTECTIVE FOUNDATION",
   "patient_id": 118190694,
   "doctor_id": 11426
 },
 {
   "prescription_id": 599973552,
   "prescription_date": "2023-06-06",
   "medication": "Piperonyl Butoxide, Pyrethrum Extract",
   "drug_brand": "Lice Complete Kit",
   "patient_id": 576286948,
   "doctor_id": 11427
 },
 {
   "prescription_id": 346236492,
   "prescription_date": "2022-11-24",
   "medication": "OCTINOXATE",
   "drug_brand": "flormar PERFECT COVERAGE FOUNDATION SUNSCREEN BROAD SPECTRUM SPF 15 106 Classic Ivory",
   "patient_id": 235592819,
   "doctor_id": 11428
 },
 {
   "prescription_id": 379288612,
   "prescription_date": "2023-10-23",
   "medication": "Escitalopram",
   "drug_brand": "Escitalopram",
   "patient_id": 190580163,
   "doctor_id": 11429
 },
 {
   "prescription_id": 798785822,
   "prescription_date": "2023-01-17",
   "medication": "Ethyl Alcohol",
   "drug_brand": "Waterless Anti-Bacterial Hand Cleanser",
   "patient_id": 595786856,
   "doctor_id": 11430
 },
 {
   "prescription_id": 494412744,
   "prescription_date": "2023-01-24",
   "medication": "sulfacetamide sodium and sulfur",
   "drug_brand": "Sumadan",
   "patient_id": 604700309,
   "doctor_id": 11431
 },
 {
   "prescription_id": 713269179,
   "prescription_date": "2023-07-23",
   "medication": "Valproate Sodium",
   "drug_brand": "Valproate Sodium",
   "patient_id": 902219821,
   "doctor_id": 11432
 },
 {
   "prescription_id": 588324427,
   "prescription_date": "2023-02-01",
   "medication": "Oxymorphone Hydrochloride",
   "drug_brand": "OPANA",
   "patient_id": 188976169,
   "doctor_id": 11433
 },
 {
   "prescription_id": 147682400,
   "prescription_date": "2022-12-02",
   "medication": "Prednisone",
   "drug_brand": "Prednisone",
   "patient_id": 369442227,
   "doctor_id": 11434
 },
 {
   "prescription_id": 227407039,
   "prescription_date": "2023-09-11",
   "medication": "Salicylic Acid",
   "drug_brand": "Spot Repairing Serum",
   "patient_id": 18906918,
   "doctor_id": 11435
 },
 {
   "prescription_id": 668387637,
   "prescription_date": "2023-01-21",
   "medication": "Cephalexin",
   "drug_brand": "Cephalexin",
   "patient_id": 35693825,
   "doctor_id": 11436
 },
 {
   "prescription_id": 459483348,
   "prescription_date": "2023-09-01",
   "medication": "Guaifenesin and Dextromethorphan Hydrobromide",
   "drug_brand": "Siltussin DM",
   "patient_id": 362364938,
   "doctor_id": 11437
 },
 {
   "prescription_id": 251204737,
   "prescription_date": "2023-05-01",
   "medication": "STANNOUS FLUORIDE",
   "drug_brand": "GINGIMED",
   "patient_id": 973178479,
   "doctor_id": 11438
 },
 {
   "prescription_id": 935632193,
   "prescription_date": "2023-08-09",
   "medication": "Rho(D) Immune Globulin (Human)",
   "drug_brand": "HyperRHO S/D Full Dose",
   "patient_id": 421353640,
   "doctor_id": 11439
 },
 {
   "prescription_id": 908093611,
   "prescription_date": "2023-04-01",
   "medication": "Chlorpheniramine maleate, Phenylephrine HCl",
   "drug_brand": "Sinus and Allergy Releif PE",
   "patient_id": 665583477,
   "doctor_id": 11440
 },
 {
   "prescription_id": 406551038,
   "prescription_date": "2023-04-23",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE, OXYBENZONE",
   "drug_brand": "DiorSnow Light Veil 021 Linen SPF 20",
   "patient_id": 672042085,
   "doctor_id": 11441
 },
 {
   "prescription_id": 976199213,
   "prescription_date": "2023-01-10",
   "medication": "Homeopathic Liquid",
   "drug_brand": "Colo-Chord",
   "patient_id": 208512165,
   "doctor_id": 11442
 },
 {
   "prescription_id": 352785434,
   "prescription_date": "2023-03-08",
   "medication": "Hydromorphone Hydrochloride",
   "drug_brand": "EXALGO",
   "patient_id": 696254421,
   "doctor_id": 11443
 },
 {
   "prescription_id": 83621353,
   "prescription_date": "2023-07-14",
   "medication": "Berberis Urtica",
   "drug_brand": "Berberis Urtica",
   "patient_id": 785024059,
   "doctor_id": 11444
 },
 {
   "prescription_id": 510688990,
   "prescription_date": "2023-10-27",
   "medication": "Allantoin",
   "drug_brand": "Perfect Calming BB Remover",
   "patient_id": 104852602,
   "doctor_id": 11445
 },
 {
   "prescription_id": 540453638,
   "prescription_date": "2022-12-19",
   "medication": "ciprofloxacin",
   "drug_brand": "ciprofloxacin",
   "patient_id": 169056437,
   "doctor_id": 11446
 },
 {
   "prescription_id": 704418072,
   "prescription_date": "2023-01-13",
   "medication": "Chloroxylenol",
   "drug_brand": "Antimicrobial Hand Wash",
   "patient_id": 353612846,
   "doctor_id": 11447
 },
 {
   "prescription_id": 355668781,
   "prescription_date": "2023-09-20",
   "medication": "Diclofenac Sodium",
   "drug_brand": "Diclofenac Sodium",
   "patient_id": 623874543,
   "doctor_id": 11448
 },
 {
   "prescription_id": 991648299,
   "prescription_date": "2023-03-02",
   "medication": "Zinc Oxide, Titanium Dioxide",
   "drug_brand": "supernatural airbrushed canvas broad spectrum spf 15 sunscreen",
   "patient_id": 174674776,
   "doctor_id": 11449
 },
 {
   "prescription_id": 829497834,
   "prescription_date": "2022-11-16",
   "medication": "Naproxen",
   "drug_brand": "Naproxen",
   "patient_id": 207832878,
   "doctor_id": 11450
 },
 {
   "prescription_id": 763226793,
   "prescription_date": "2022-11-26",
   "medication": "Alprazolam",
   "drug_brand": "Alprazolam",
   "patient_id": 248029357,
   "doctor_id": 11451
 },
 {
   "prescription_id": 971742313,
   "prescription_date": "2023-09-29",
   "medication": "Acetaminophen and Diphenhydramine Citrate",
   "drug_brand": "Headache Relief PM",
   "patient_id": 358243418,
   "doctor_id": 11452
 },
 {
   "prescription_id": 725290432,
   "prescription_date": "2022-11-29",
   "medication": "Citalopram Hydrobromide",
   "drug_brand": "Citalopram Hydrobromide",
   "patient_id": 90632849,
   "doctor_id": 11453
 },
 {
   "prescription_id": 84579475,
   "prescription_date": "2022-12-06",
   "medication": "glipizide",
   "drug_brand": "Glipizide",
   "patient_id": 998686365,
   "doctor_id": 11454
 },
 {
   "prescription_id": 907570501,
   "prescription_date": "2023-07-15",
   "medication": "Protriptyline Hydrochloride",
   "drug_brand": "Protriptyline Hydrochloride",
   "patient_id": 819078814,
   "doctor_id": 11455
 },
 {
   "prescription_id": 164150420,
   "prescription_date": "2023-06-04",
   "medication": "PANTOPRAZOLE SODIUM",
   "drug_brand": "Pantoprazole Sodium Delayed-Release Delayed-Release",
   "patient_id": 412893753,
   "doctor_id": 11456
 },
 {
   "prescription_id": 247549439,
   "prescription_date": "2022-12-14",
   "medication": "rizatriptan benzoate",
   "drug_brand": "rizatriptan benzoate",
   "patient_id": 32778867,
   "doctor_id": 11457
 },
 {
   "prescription_id": 546490937,
   "prescription_date": "2023-09-20",
   "medication": "Isopropyl Alcohol",
   "drug_brand": "Isopropyl Rubbing Alcohol",
   "patient_id": 930710192,
   "doctor_id": 11458
 },
 {
   "prescription_id": 384384733,
   "prescription_date": "2023-04-29",
   "medication": "OCTINOXATE, OXYBENZONE, TITANIUM DIOXIDE, ZINC OXIDE",
   "drug_brand": "Surfers Skin Sunscreen",
   "patient_id": 645199470,
   "doctor_id": 11459
 },
 {
   "prescription_id": 561560932,
   "prescription_date": "2023-01-13",
   "medication": "AVOBENZONE, HOMOSALATE, OCTISALATE, OCTOCRYLENE, OXYBENZONE",
   "drug_brand": "BANANA BOAT",
   "patient_id": 396282953,
   "doctor_id": 11460
 },
 {
   "prescription_id": 609184778,
   "prescription_date": "2023-10-23",
   "medication": "DIMETHICONE",
   "drug_brand": "By Pharmicell Lab Luxury Cell Performance",
   "patient_id": 537457424,
   "doctor_id": 11461
 },
 {
   "prescription_id": 98866391,
   "prescription_date": "2023-09-24",
   "medication": "Aluminum Chlorohydrate",
   "drug_brand": "Suave",
   "patient_id": 202267689,
   "doctor_id": 11462
 },
 {
   "prescription_id": 899685884,
   "prescription_date": "2023-08-12",
   "medication": "Venlafaxine",
   "drug_brand": "Venlafaxine",
   "patient_id": 696593451,
   "doctor_id": 11463
 },
 {
   "prescription_id": 361146666,
   "prescription_date": "2023-01-30",
   "medication": "Nasal Throat Spray",
   "drug_brand": "Cold and Infection Defense",
   "patient_id": 173354845,
   "doctor_id": 11464
 },
 {
   "prescription_id": 83035294,
   "prescription_date": "2023-03-08",
   "medication": "Voriconazole",
   "drug_brand": "Voriconazole",
   "patient_id": 195955527,
   "doctor_id": 11465
 },
 {
   "prescription_id": 408988146,
   "prescription_date": "2023-01-23",
   "medication": "olanzapine",
   "drug_brand": "Olanzapine",
   "patient_id": 467823139,
   "doctor_id": 11466
 },
 {
   "prescription_id": 884749817,
   "prescription_date": "2023-03-12",
   "medication": "Amiloride Hydrochloride and Hydrochlorothiazide",
   "drug_brand": "Amiloride Hydrochloride and Hydrochlorothiazide",
   "patient_id": 446009214,
   "doctor_id": 11467
 },
 {
   "prescription_id": 681421065,
   "prescription_date": "2023-01-29",
   "medication": "Butalbital, Acetaminophen, and Caffeine",
   "drug_brand": "Butalbital, Acetaminophen and Caffeine",
   "patient_id": 404831768,
   "doctor_id": 11468
 },
 {
   "prescription_id": 569494558,
   "prescription_date": "2022-12-27",
   "medication": "Tetracaine Hydrochloride",
   "drug_brand": "TetraVisc",
   "patient_id": 582248667,
   "doctor_id": 11469
 },
 {
   "prescription_id": 134747644,
   "prescription_date": "2023-06-25",
   "medication": "Diethylpropion Hydrochloride",
   "drug_brand": "Diethylpropion Hydrochloride",
   "patient_id": 362633029,
   "doctor_id": 11470
 },
 {
   "prescription_id": 326564666,
   "prescription_date": "2023-05-15",
   "medication": "Zinc Oxide Dimethicone",
   "drug_brand": "Rash Relief",
   "patient_id": 260717309,
   "doctor_id": 11471
 },
 {
   "prescription_id": 608782820,
   "prescription_date": "2023-09-27",
   "medication": "Alfalfa, Laminaria digitata, Symphytum officinale, Ascorbic acid, Melatonin, Calcarea carbonica, Cuprum metallicum, Ferrum metallicum, Iodium,",
   "drug_brand": "EMF Protect and Balance",
   "patient_id": 630281586,
   "doctor_id": 11472
 },
 {
   "prescription_id": 623117164,
   "prescription_date": "2023-08-10",
   "medication": "Miconazole Nitrate",
   "drug_brand": "Ting",
   "patient_id": 895975590,
   "doctor_id": 11473
 },
 {
   "prescription_id": 697819283,
   "prescription_date": "2023-01-20",
   "medication": "VENLAFAXINE HYDROCHLORIDE",
   "drug_brand": "VENLAFAXINE HYDROCHLORIDE",
   "patient_id": 816280609,
   "doctor_id": 11474
 },
 {
   "prescription_id": 981872599,
   "prescription_date": "2022-12-26",
   "medication": "Potassium Nitrate and Sodium Fluoride",
   "drug_brand": "Up and UP Sensitive Toothpaste Enamel Strengthening formula",
   "patient_id": 239527640,
   "doctor_id": 11475
 },
 {
   "prescription_id": 824071025,
   "prescription_date": "2023-03-03",
   "medication": "ASPIRIN",
   "drug_brand": "ASPIRIN",
   "patient_id": 362959196,
   "doctor_id": 11476
 },
 {
   "prescription_id": 759409774,
   "prescription_date": "2023-04-18",
   "medication": "Pancrelipase",
   "drug_brand": "Creon",
   "patient_id": 524081774,
   "doctor_id": 11477
 },
 {
   "prescription_id": 719084784,
   "prescription_date": "2023-01-17",
   "medication": "Glycerin",
   "drug_brand": "Lemon Glycerin",
   "patient_id": 982501745,
   "doctor_id": 11478
 },
 {
   "prescription_id": 416517840,
   "prescription_date": "2023-02-03",
   "medication": "Felodipine",
   "drug_brand": "Felodipine",
   "patient_id": 786322265,
   "doctor_id": 11479
 },
 {
   "prescription_id": 88469060,
   "prescription_date": "2023-05-21",
   "medication": "meclizine hydrochloride",
   "drug_brand": "Meclizine Hydrochloride",
   "patient_id": 469585889,
   "doctor_id": 11480
 },
 {
   "prescription_id": 20251192,
   "prescription_date": "2023-09-01",
   "medication": "nicotine polacrilex",
   "drug_brand": "NICORETTE",
   "patient_id": 787573949,
   "doctor_id": 11481
 },
 {
   "prescription_id": 912250234,
   "prescription_date": "2023-03-31",
   "medication": "Ranitidine",
   "drug_brand": "Acid Reducer",
   "patient_id": 346855516,
   "doctor_id": 11482
 },
 {
   "prescription_id": 648637190,
   "prescription_date": "2023-07-30",
   "medication": "calcium carbonate",
   "drug_brand": "Medi First Antacid",
   "patient_id": 313267691,
   "doctor_id": 11483
 },
 {
   "prescription_id": 627295430,
   "prescription_date": "2023-07-11",
   "medication": "Olanzapine",
   "drug_brand": "Olanzapine",
   "patient_id": 621609609,
   "doctor_id": 11484
 },
 {
   "prescription_id": 574250864,
   "prescription_date": "2023-03-22",
   "medication": "Fluconazole",
   "drug_brand": "Fluconazole",
   "patient_id": 650036716,
   "doctor_id": 11485
 },
 {
   "prescription_id": 954409582,
   "prescription_date": "2023-04-24",
   "medication": "Tolnafate, Triclosan",
   "drug_brand": "Nail MD",
   "patient_id": 85032150,
   "doctor_id": 11486
 },
 {
   "prescription_id": 637930041,
   "prescription_date": "2022-12-03",
   "medication": "SAMBUCUS NIGRA FLOWER, CALENDULA OFFICINALIS FLOWER, ECHINACEA ANGUSTIFOLIA",
   "drug_brand": "ORIGINAL HEALING",
   "patient_id": 749112003,
   "doctor_id": 11487
 },
 {
   "prescription_id": 67726324,
   "prescription_date": "2023-08-24",
   "medication": "milnacipran hydrochloride",
   "drug_brand": "Savella",
   "patient_id": 667496237,
   "doctor_id": 11488
 },
 {
   "prescription_id": 886519362,
   "prescription_date": "2023-06-28",
   "medication": "BROMPHENIRAMINE MALEATE, DEXTROMETHORPHAN HYDROBROMIDE, PHENYLEPHRINE HYDROCHLORIDE",
   "drug_brand": "Altipres-B",
   "patient_id": 498148613,
   "doctor_id": 11489
 },
 {
   "prescription_id": 683599713,
   "prescription_date": "2023-10-27",
   "medication": "Morphine Sulfate",
   "drug_brand": "Morphine Sulfate",
   "patient_id": 648972547,
   "doctor_id": 11490
 },
 {
   "prescription_id": 905133870,
   "prescription_date": "2023-10-06",
   "medication": "Treatment Set TS344592",
   "drug_brand": "Treatment Set TS344592",
   "patient_id": 804337980,
   "doctor_id": 11491
 },
 {
   "prescription_id": 54807809,
   "prescription_date": "2023-07-05",
   "medication": "DIMETHICONE",
   "drug_brand": "SNAYTOX ESSENCE BOOSTER",
   "patient_id": 509309578,
   "doctor_id": 11492
 },
 {
   "prescription_id": 918802160,
   "prescription_date": "2023-04-25",
   "medication": "diltiazem hydrochloride",
   "drug_brand": "Diltiazem Hydrochloride",
   "patient_id": 235463303,
   "doctor_id": 11493
 },
 {
   "prescription_id": 326381769,
   "prescription_date": "2023-06-15",
   "medication": "brimonidine tartrate, timolol maleate",
   "drug_brand": "COMBIGAN",
   "patient_id": 27255569,
   "doctor_id": 11494
 },
 {
   "prescription_id": 629803972,
   "prescription_date": "2023-07-11",
   "medication": "Haloperidol lactate",
   "drug_brand": "Haloperidol",
   "patient_id": 532706040,
   "doctor_id": 11495
 },
 {
   "prescription_id": 882643866,
   "prescription_date": "2023-08-02",
   "medication": "standardized senna concentrate and docusate sodium",
   "drug_brand": "Senokot-S",
   "patient_id": 692001184,
   "doctor_id": 11496
 },
 {
   "prescription_id": 118409202,
   "prescription_date": "2022-11-25",
   "medication": "Betamethasone Valerate",
   "drug_brand": "Betamethasone Valerate",
   "patient_id": 142758365,
   "doctor_id": 11497
 },
 {
   "prescription_id": 133660443,
   "prescription_date": "2023-05-21",
   "medication": "Titanium Dioxide",
   "drug_brand": "Wet n Wild Fergie BB Cream SPF 15",
   "patient_id": 82048598,
   "doctor_id": 11498
 },
 {
   "prescription_id": 684964320,
   "prescription_date": "2023-08-24",
   "medication": "ISOPROTERENOL HYDROCHLORIDE",
   "drug_brand": "Isuprel",
   "patient_id": 174628396,
   "doctor_id": 11499
 },
 {
   "prescription_id": 610564100,
   "prescription_date": "2023-10-01",
   "medication": "Levocetirizine Dihydrochloride",
   "drug_brand": "Levocetirizine Dihydrochloride",
   "patient_id": 560384589,
   "doctor_id": 11500
 },
 {
   "prescription_id": 504987079,
   "prescription_date": "2023-06-29",
   "medication": "Meprobamate",
   "drug_brand": "Meprobamate",
   "patient_id": 624936117,
   "doctor_id": 11501
 },
 {
   "prescription_id": 512286269,
   "prescription_date": "2023-10-01",
   "medication": "Prednisone",
   "drug_brand": "Prednisone",
   "patient_id": 398885724,
   "doctor_id": 11502
 },
 {
   "prescription_id": 673495404,
   "prescription_date": "2023-08-15",
   "medication": "bicalutamide",
   "drug_brand": "Bicalutamide",
   "patient_id": 54328749,
   "doctor_id": 11503
 },
 {
   "prescription_id": 931340413,
   "prescription_date": "2023-06-05",
   "medication": "Calc phos, Kali sulph, Nat sulphuricum",
   "drug_brand": "Triple Complex Diabetonic",
   "patient_id": 992634308,
   "doctor_id": 11504
 },
 {
   "prescription_id": 868337415,
   "prescription_date": "2023-02-02",
   "medication": "WITCH HAZEL",
   "drug_brand": "MEDICATED-PADS Hemorrhoidal Pads with Witch Hazel",
   "patient_id": 793003815,
   "doctor_id": 11505
 },
 {
   "prescription_id": 185397112,
   "prescription_date": "2023-11-08",
   "medication": "Carvedilol",
   "drug_brand": "Carvedilol",
   "patient_id": 495787877,
   "doctor_id": 11506
 },
 {
   "prescription_id": 227666653,
   "prescription_date": "2023-01-15",
   "medication": "OCTINOXATE, OCTOCRYLENE, OCTISALATE, and Avobenzone",
   "drug_brand": "Kinesys Broad Spectrum SPF 30 Alcohol-Free Performance Sunscreen - Fragrance Free",
   "patient_id": 267743189,
   "doctor_id": 11507
 },
 {
   "prescription_id": 701419932,
   "prescription_date": "2023-07-05",
   "medication": "Salicylic Acid",
   "drug_brand": "Clearasil Ultra",
   "patient_id": 55659397,
   "doctor_id": 11508
 },
 {
   "prescription_id": 382541939,
   "prescription_date": "2023-10-23",
   "medication": "Aspirin",
   "drug_brand": "Medi First Plus Aspirin",
   "patient_id": 122404338,
   "doctor_id": 11509
 },
 {
   "prescription_id": 11465808,
   "prescription_date": "2023-03-15",
   "medication": "desipramine hydrochloride",
   "drug_brand": "Norpramin",
   "patient_id": 77165315,
   "doctor_id": 11510
 },
 {
   "prescription_id": 973249224,
   "prescription_date": "2023-06-27",
   "medication": "Dextromethorphan",
   "drug_brand": "Delsym",
   "patient_id": 275412918,
   "doctor_id": 11511
 },
 {
   "prescription_id": 565773684,
   "prescription_date": "2023-02-23",
   "medication": "Dextroamphetamine Sulfate",
   "drug_brand": "Dextroamphetamine Sulfate",
   "patient_id": 828460468,
   "doctor_id": 11512
 },
 {
   "prescription_id": 373457762,
   "prescription_date": "2023-02-15",
   "medication": "Tolterodine Tartrate",
   "drug_brand": "Tolterodine Tartrate",
   "patient_id": 556879037,
   "doctor_id": 11513
 },
 {
   "prescription_id": 946066686,
   "prescription_date": "2023-05-13",
   "medication": "SODIUM ACETATE",
   "drug_brand": "Sodium Acetate",
   "patient_id": 514125439,
   "doctor_id": 11514
 },
 {
   "prescription_id": 915915359,
   "prescription_date": "2023-03-28",
   "medication": "Naproxen",
   "drug_brand": "Naproxen",
   "patient_id": 727065332,
   "doctor_id": 11515
 },
 {
   "prescription_id": 841220295,
   "prescription_date": "2023-01-18",
   "medication": "Benzalkonium Chloride",
   "drug_brand": "First Aid Antiseptic",
   "patient_id": 422709967,
   "doctor_id": 11516
 },
 {
   "prescription_id": 891740419,
   "prescription_date": "2023-01-04",
   "medication": "Aluminum Zirconium Tetrachlorohydrex GLY",
   "drug_brand": "Degree",
   "patient_id": 355411103,
   "doctor_id": 11517
 },
 {
   "prescription_id": 78096869,
   "prescription_date": "2023-07-04",
   "medication": "Tetrahydrozoline hydrochloride",
   "drug_brand": "CVS Redness Relief Original",
   "patient_id": 722061898,
   "doctor_id": 11518
 },
 {
   "prescription_id": 10058585,
   "prescription_date": "2023-06-03",
   "medication": "ACETAMINOPHEN",
   "drug_brand": "NON-ASPIRIN",
   "patient_id": 834934164,
   "doctor_id": 11519
 },
 {
   "prescription_id": 927826504,
   "prescription_date": "2023-08-11",
   "medication": "Measles, Mumps, Rubella and Varicella Virus Vaccine Live",
   "drug_brand": "ProQuad",
   "patient_id": 399411276,
   "doctor_id": 11520
 },
 {
   "prescription_id": 82201640,
   "prescription_date": "2022-12-22",
   "medication": "siltuximab",
   "drug_brand": "SYLVANT",
   "patient_id": 711641592,
   "doctor_id": 11521
 },
 {
   "prescription_id": 679040922,
   "prescription_date": "2023-03-15",
   "medication": "Lorazepam",
   "drug_brand": "Lorazepam",
   "patient_id": 828018247,
   "doctor_id": 11522
 },
 {
   "prescription_id": 8214143,
   "prescription_date": "2023-03-03",
   "medication": "Titanium dioxide",
   "drug_brand": "CLE DE PEAU BEAUTE CREAM COMPACT FOUNDATION",
   "patient_id": 220892804,
   "doctor_id": 11523
 },
 {
   "prescription_id": 783014871,
   "prescription_date": "2023-08-29",
   "medication": "CITALOPRAM",
   "drug_brand": "CITALOPRAM HYDROBROMIDE",
   "patient_id": 927887398,
   "doctor_id": 11524
 },
 {
   "prescription_id": 312694714,
   "prescription_date": "2023-01-31",
   "medication": "Aspirin",
   "drug_brand": "Regular Strength Tri-Buffered Aspirin",
   "patient_id": 196667880,
   "doctor_id": 11525
 },
 {
   "prescription_id": 698528279,
   "prescription_date": "2022-12-13",
   "medication": "Camphor, Menthol, Methyl Salicylate",
   "drug_brand": "Yu Long You Pain Relieving",
   "patient_id": 606450439,
   "doctor_id": 11526
 },
 {
   "prescription_id": 365868447,
   "prescription_date": "2023-02-28",
   "medication": "OCTINOXATE and TITANIUM DIOXIDE",
   "drug_brand": "PERFECTION LUMIERE VELVET",
   "patient_id": 425822956,
   "doctor_id": 11527
 },
 {
   "prescription_id": 514002217,
   "prescription_date": "2023-07-15",
   "medication": "Donepezil Hydrochloride",
   "drug_brand": "Donepezil Hydrochloride",
   "patient_id": 204069482,
   "doctor_id": 11528
 },
 {
   "prescription_id": 377203045,
   "prescription_date": "2023-05-19",
   "medication": "ARBUTIN, ETHYLHEXYL METHOXYCINNAMATE",
   "drug_brand": "Dr Young 2p Brightening UV Sun Block SPF50 PA",
   "patient_id": 783006925,
   "doctor_id": 11529
 },
 {
   "prescription_id": 864680049,
   "prescription_date": "2023-07-01",
   "medication": "Gabapentin",
   "drug_brand": "Gabapentin",
   "patient_id": 663380934,
   "doctor_id": 11530
 },
 {
   "prescription_id": 141844428,
   "prescription_date": "2022-11-22",
   "medication": "isosorbide mononitrate",
   "drug_brand": "isosorbide mononitrate",
   "patient_id": 370327248,
   "doctor_id": 11531
 },
 {
   "prescription_id": 993787413,
   "prescription_date": "2022-12-17",
   "medication": "Serotonin (Hydrochloride)",
   "drug_brand": "Serotonin",
   "patient_id": 751139588,
   "doctor_id": 11532
 },
 {
   "prescription_id": 370116206,
   "prescription_date": "2023-03-16",
   "medication": "Triclosan",
   "drug_brand": "Passion Flower Antibacterial Foaming Hand Wash",
   "patient_id": 71234680,
   "doctor_id": 11533
 },
 {
   "prescription_id": 881854347,
   "prescription_date": "2023-05-15",
   "medication": "norethindrone acetate, ethinyl estradiol and ferrous fumarate",
   "drug_brand": "GILDESS FE 1/20",
   "patient_id": 158221518,
   "doctor_id": 11534
 },
 {
   "prescription_id": 64369548,
   "prescription_date": "2023-04-19",
   "medication": "Naproxen Sodium",
   "drug_brand": "All Day Pain Relief",
   "patient_id": 610043626,
   "doctor_id": 11535
 },
 {
   "prescription_id": 62065555,
   "prescription_date": "2023-08-25",
   "medication": "Mango",
   "drug_brand": "Mango",
   "patient_id": 302026565,
   "doctor_id": 11536
 },
 {
   "prescription_id": 309780922,
   "prescription_date": "2023-02-14",
   "medication": "Levothyroxine",
   "drug_brand": "Levothyroxine",
   "patient_id": 614049323,
   "doctor_id": 11537
 },
 {
   "prescription_id": 611166744,
   "prescription_date": "2023-02-19",
   "medication": "ascorbic acid, cholecalciferol, .alpha.-tocopherol, dl-, folic acid, pyridoxine hydrochloride, cyanocobalamin, calcium formate, ferrous asparto glycinate, magnesium oxide and doconexent",
   "drug_brand": "PRENATE DHA",
   "patient_id": 146173247,
   "doctor_id": 11538
 },
 {
   "prescription_id": 840874677,
   "prescription_date": "2023-09-08",
   "medication": "Hydromorphone Hydrochloride",
   "drug_brand": "Hydromorphone Hydrochloride",
   "patient_id": 447848844,
   "doctor_id": 11539
 },
 {
   "prescription_id": 152363534,
   "prescription_date": "2023-08-29",
   "medication": "Lidocaine Hydrochloride",
   "drug_brand": "Lidocaine Hydrochloride",
   "patient_id": 962204244,
   "doctor_id": 11540
 },
 {
   "prescription_id": 908799167,
   "prescription_date": "2023-10-19",
   "medication": "SALICYLIC ACID",
   "drug_brand": "EQUALINE",
   "patient_id": 58847187,
   "doctor_id": 11541
 },
 {
   "prescription_id": 410720609,
   "prescription_date": "2023-01-23",
   "medication": "ciprofloxacin hydrochloride",
   "drug_brand": "Ciprofloxacin",
   "patient_id": 727571485,
   "doctor_id": 11542
 },
 {
   "prescription_id": 599411168,
   "prescription_date": "2023-11-11",
   "medication": "Povidone-iodine",
   "drug_brand": "Aplicare Povidone-iodine Scrub",
   "patient_id": 387562934,
   "doctor_id": 11543
 },
 {
   "prescription_id": 563841750,
   "prescription_date": "2023-02-16",
   "medication": "Octreotide Acetate",
   "drug_brand": "Octreotide Acetate",
   "patient_id": 578778803,
   "doctor_id": 11544
 },
 {
   "prescription_id": 604208557,
   "prescription_date": "2023-08-05",
   "medication": "Treatment Set TS346791",
   "drug_brand": "Treatment Set TS346791",
   "patient_id": 852057075,
   "doctor_id": 11545
 },
 {
   "prescription_id": 568849533,
   "prescription_date": "2022-11-24",
   "medication": "baclofen",
   "drug_brand": "Lioresal",
   "patient_id": 841305837,
   "doctor_id": 11546
 },
 {
   "prescription_id": 994502402,
   "prescription_date": "2023-08-05",
   "medication": "Octinoxate and Titanium Dioxide",
   "drug_brand": "LBEL NATURAL FINISH MOISTURIZING FOUNDATION SPF 25",
   "patient_id": 163440809,
   "doctor_id": 11547
 },
 {
   "prescription_id": 337884490,
   "prescription_date": "2023-09-01",
   "medication": "Isosorbide mononitrate",
   "drug_brand": "Isosorbide Mononitrate",
   "patient_id": 234840191,
   "doctor_id": 11548
 },
 {
   "prescription_id": 379401887,
   "prescription_date": "2022-11-29",
   "medication": "Lisinopril",
   "drug_brand": "Lisinopril",
   "patient_id": 628295878,
   "doctor_id": 11549
 },
 {
   "prescription_id": 37547453,
   "prescription_date": "2023-03-29",
   "medication": "imipramine pamoate",
   "drug_brand": "TOFRANIL-PM",
   "patient_id": 293277773,
   "doctor_id": 11550
 },
 {
   "prescription_id": 445693930,
   "prescription_date": "2023-10-12",
   "medication": "Pyrethrum Extract and Piperonyl Butoxide",
   "drug_brand": "LiceMD",
   "patient_id": 380391051,
   "doctor_id": 11551
 },
 {
   "prescription_id": 439203399,
   "prescription_date": "2023-07-27",
   "medication": "GUAIFENESIN DEXTROMETHORPHAN",
   "drug_brand": "GUAIFENESIN DM",
   "patient_id": 822119060,
   "doctor_id": 11302
 },
 {
   "prescription_id": 375113928,
   "prescription_date": "2023-05-18",
   "medication": "Cephalosporium",
   "drug_brand": "Cephalosporium",
   "patient_id": 216341589,
   "doctor_id": 11303
 },
 {
   "prescription_id": 316810608,
   "prescription_date": "2023-04-02",
   "medication": "CEFPROZIL",
   "drug_brand": "CEFPROZIL",
   "patient_id": 341005835,
   "doctor_id": 11304
 },
 {
   "prescription_id": 248766555,
   "prescription_date": "2023-06-16",
   "medication": "Pentoxifylline",
   "drug_brand": "Pentoxifylline",
   "patient_id": 723143458,
   "doctor_id": 11305
 },
 {
   "prescription_id": 254932529,
   "prescription_date": "2023-07-27",
   "medication": "Tramadol Hydrochloride and Acetaminophen",
   "drug_brand": "Tramadol Hydrochloride and Acetaminophen",
   "patient_id": 871416790,
   "doctor_id": 11306
 },
 {
   "prescription_id": 116605209,
   "prescription_date": "2023-06-18",
   "medication": "Tramadol Hydrochloride and Acetaminophen",
   "drug_brand": "Tramadol Hydrochloride and Acetaminophen",
   "patient_id": 975198286,
   "doctor_id": 11307
 },
 {
   "prescription_id": 291401558,
   "prescription_date": "2023-05-12",
   "medication": "Naproxen",
   "drug_brand": "Naproxen",
   "patient_id": 180585272,
   "doctor_id": 11308
 },
 {
   "prescription_id": 33823587,
   "prescription_date": "2023-05-05",
   "medication": "buprenorphine",
   "drug_brand": "Butrans",
   "patient_id": 552127421,
   "doctor_id": 11309
 },
 {
   "prescription_id": 207759652,
   "prescription_date": "2023-03-29",
   "medication": "TRICLOSAN",
   "drug_brand": "ANTIBACTERIAL FOAMING",
   "patient_id": 53267561,
   "doctor_id": 11310
 },
 {
   "prescription_id": 852230860,
   "prescription_date": "2023-02-12",
   "medication": "BENZETHONIUM CHLORIDE",
   "drug_brand": "Insti-Foam Sanitizer",
   "patient_id": 488000191,
   "doctor_id": 11311
 },
 {
   "prescription_id": 606552784,
   "prescription_date": "2022-11-18",
   "medication": "Moexipril Hydrochloride and Hydrochlorothiazide",
   "drug_brand": "Moexipril Hydrochloride and Hydrochlorothiazide",
   "patient_id": 172196320,
   "doctor_id": 11312
 },
 {
   "prescription_id": 662580237,
   "prescription_date": "2023-11-12",
   "medication": "clonidine hydrochloride",
   "drug_brand": "Clonidine Hydrochloride",
   "patient_id": 394991105,
   "doctor_id": 11313
 },
 {
   "prescription_id": 623742180,
   "prescription_date": "2023-10-12",
   "medication": "Glycerin",
   "drug_brand": "Lemon Glycerin",
   "patient_id": 673388522,
   "doctor_id": 11314
 },
 {
   "prescription_id": 17838729,
   "prescription_date": "2023-08-05",
   "medication": "Titanium Dioxide and Octinoxate",
   "drug_brand": "Eve Lom Radiance Perfected Tinted Moisturiser Broad Spectrum SPF 15 Sunscreen",
   "patient_id": 524560183,
   "doctor_id": 11315
 },
 {
   "prescription_id": 757496180,
   "prescription_date": "2023-07-16",
   "medication": "Lisinopril",
   "drug_brand": "Lisinopril",
   "patient_id": 454773624,
   "doctor_id": 11316
 },
 {
   "prescription_id": 228275309,
   "prescription_date": "2023-03-01",
   "medication": "Tobramycin",
   "drug_brand": "Tobramycin",
   "patient_id": 237338496,
   "doctor_id": 11317
 },
 {
   "prescription_id": 465157569,
   "prescription_date": "2023-05-05",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 558371102,
   "doctor_id": 11318
 },
 {
   "prescription_id": 12770105,
   "prescription_date": "2022-12-22",
   "medication": "Trandolapril",
   "drug_brand": "Trandolapril",
   "patient_id": 174952221,
   "doctor_id": 11319
 },
 {
   "prescription_id": 121688913,
   "prescription_date": "2023-02-14",
   "medication": "BACITRACIN ZINC, NEOMYCIN SULFATE, POLYMYXIN-B SULFATE",
   "drug_brand": "SHOPKO TRIPLE ANTIBIOTIC",
   "patient_id": 958673895,
   "doctor_id": 11320
 },
 {
   "prescription_id": 712985292,
   "prescription_date": "2023-08-15",
   "medication": "Treatment Set TS348283",
   "drug_brand": "Treatment Set TS348283",
   "patient_id": 15872130,
   "doctor_id": 11321
 },
 {
   "prescription_id": 787869255,
   "prescription_date": "2023-05-27",
   "medication": "BENZALKONIUM CHLORIDE",
   "drug_brand": "Anti-Bacterial Wipes",
   "patient_id": 100833952,
   "doctor_id": 11322
 },
 {
   "prescription_id": 664303690,
   "prescription_date": "2023-01-29",
   "medication": "pomalidomide",
   "drug_brand": "Pomalyst",
   "patient_id": 443049773,
   "doctor_id": 11323
 },
 {
   "prescription_id": 342140108,
   "prescription_date": "2023-02-03",
   "medication": "Docusate sodium and sennosides",
   "drug_brand": "Laxacin",
   "patient_id": 373128023,
   "doctor_id": 11324
 },
 {
   "prescription_id": 85930588,
   "prescription_date": "2023-08-15",
   "medication": "Dipyridamole",
   "drug_brand": "Dipyridamole",
   "patient_id": 583820076,
   "doctor_id": 11325
 },
 {
   "prescription_id": 129986089,
   "prescription_date": "2022-11-15",
   "medication": "Lycopodium Clavatum",
   "drug_brand": "Lycopodium Clavatum",
   "patient_id": 16645202,
   "doctor_id": 11326
 },
 {
   "prescription_id": 295784076,
   "prescription_date": "2023-09-18",
   "medication": "Acetaminophen, Chlorpheniramine Maleate and Phenylephrine HCl",
   "drug_brand": "Allergy Mutli-Symptom",
   "patient_id": 358659356,
   "doctor_id": 11327
 },
 {
   "prescription_id": 580911384,
   "prescription_date": "2023-06-09",
   "medication": "ETHYL ALCOHOL",
   "drug_brand": "Spa Originals Instant Hand Sanitizer",
   "patient_id": 767925392,
   "doctor_id": 11328
 },
 {
   "prescription_id": 113919077,
   "prescription_date": "2023-09-13",
   "medication": "Arnica, Apis, Hepar Sulph, Hypericum, Ledum, Silicea",
   "drug_brand": "Infected Cuts and Punctures",
   "patient_id": 442239244,
   "doctor_id": 11329
 },
 {
   "prescription_id": 672934120,
   "prescription_date": "2023-03-11",
   "medication": "Acetaminophen, Dextromethorphan HBr, Doxylamine succinate, Phenylephrine HCl",
   "drug_brand": "Up and Up Cold Flu Relief Day Night",
   "patient_id": 360962395,
   "doctor_id": 11330
 },
 {
   "prescription_id": 384550996,
   "prescription_date": "2023-07-12",
   "medication": "Promethazine Hydrochloride and Dextromethorphan Hydrobromide",
   "drug_brand": "Promethazine Hydrochloride and Dextromethorphan Hydrobromide",
   "patient_id": 969926022,
   "doctor_id": 11331
 },
 {
   "prescription_id": 388886075,
   "prescription_date": "2023-07-25",
   "medication": "Triclosan",
   "drug_brand": "Olive Oil Antibacterial Foaming Hand Wash",
   "patient_id": 760783680,
   "doctor_id": 11332
 },
 {
   "prescription_id": 602030742,
   "prescription_date": "2023-09-01",
   "medication": "PHOSPHORUS",
   "drug_brand": "Phosphorus",
   "patient_id": 426150282,
   "doctor_id": 11333
 },
 {
   "prescription_id": 94029214,
   "prescription_date": "2023-06-06",
   "medication": "Clindamycin Hydrochloride",
   "drug_brand": "Clindamycin Hydrochloride",
   "patient_id": 245156077,
   "doctor_id": 11334
 },
 {
   "prescription_id": 990159038,
   "prescription_date": "2023-07-05",
   "medication": "Octinoxate, Titanium Dioxide",
   "drug_brand": "Neova DNA Damage Control - Silc Sheer",
   "patient_id": 845135006,
   "doctor_id": 11335
 },
 {
   "prescription_id": 77082600,
   "prescription_date": "2022-11-25",
   "medication": "PYRITHIONE ZINC",
   "drug_brand": "Satinique Dandruff Control Hair Cleanser",
   "patient_id": 95439846,
   "doctor_id": 11336
 },
 {
   "prescription_id": 733500779,
   "prescription_date": "2022-12-25",
   "medication": "Diethylpropion hydrochloride",
   "drug_brand": "Diethylpropion HCl Controlled-Release",
   "patient_id": 491504279,
   "doctor_id": 11337
 },
 {
   "prescription_id": 539046325,
   "prescription_date": "2023-08-14",
   "medication": "Sodium Monofluorophosphate",
   "drug_brand": "Colgate Anticavity",
   "patient_id": 561522838,
   "doctor_id": 11338
 },
 {
   "prescription_id": 671063286,
   "prescription_date": "2023-05-04",
   "medication": "Trandolapril",
   "drug_brand": "Trandolapril",
   "patient_id": 63383900,
   "doctor_id": 11339
 },
 {
   "prescription_id": 483721096,
   "prescription_date": "2023-08-25",
   "medication": "ETHYL ALCOHOL",
   "drug_brand": "Antibactierial Hand Sanitizer",
   "patient_id": 726967084,
   "doctor_id": 11340
 },
 {
   "prescription_id": 168767817,
   "prescription_date": "2023-04-21",
   "medication": "Divalproex Sodium",
   "drug_brand": "Divalproex Sodium",
   "patient_id": 951806645,
   "doctor_id": 11341
 },
 {
   "prescription_id": 499843032,
   "prescription_date": "2022-11-25",
   "medication": "Antihemophilic Factor, Human Recombinant",
   "drug_brand": "ADVATE",
   "patient_id": 56796787,
   "doctor_id": 11342
 },
 {
   "prescription_id": 228873423,
   "prescription_date": "2023-05-21",
   "medication": "Acetaminophen, Phenylephrine HCl, Dextromethorphan HBr, Chlorpheniramine maleate",
   "drug_brand": "Cold Multi-Symptom",
   "patient_id": 592008114,
   "doctor_id": 11343
 },
 {
   "prescription_id": 49711208,
   "prescription_date": "2023-02-10",
   "medication": "Erythromycin",
   "drug_brand": "Erythromycin Base",
   "patient_id": 737894934,
   "doctor_id": 11344
 },
 {
   "prescription_id": 195543056,
   "prescription_date": "2022-12-29",
   "medication": "Labetalol Hydrochloride",
   "drug_brand": "Labetalol Hydrochloride",
   "patient_id": 642803844,
   "doctor_id": 11345
 },
 {
   "prescription_id": 968529204,
   "prescription_date": "2023-10-24",
   "medication": "Ciprofloxacin Hydrochloride",
   "drug_brand": "Ciprofloxacin",
   "patient_id": 750433834,
   "doctor_id": 11346
 },
 {
   "prescription_id": 71449088,
   "prescription_date": "2023-06-28",
   "medication": "Acetaminophen, Dextromethorphan Hydrobromide, Doxylamine Succinate",
   "drug_brand": "Good Sense night time",
   "patient_id": 627864350,
   "doctor_id": 11347
 },
 {
   "prescription_id": 976913668,
   "prescription_date": "2023-03-11",
   "medication": "Cetirizine HCl",
   "drug_brand": "24-Hour All Day Allergy",
   "patient_id": 222715264,
   "doctor_id": 11348
 },
 {
   "prescription_id": 581110891,
   "prescription_date": "2023-01-14",
   "medication": "Buspirone Hydrochloride",
   "drug_brand": "Buspirone Hydrochloride",
   "patient_id": 649394034,
   "doctor_id": 11349
 },
 {
   "prescription_id": 532807356,
   "prescription_date": "2023-08-05",
   "medication": "Epicoccum nigrum",
   "drug_brand": "Epicoccum nigrum",
   "patient_id": 591904943,
   "doctor_id": 11350
 },
 {
   "prescription_id": 151394823,
   "prescription_date": "2023-03-19",
   "medication": "Menthol",
   "drug_brand": "Flexall Pain Relieving",
   "patient_id": 810238921,
   "doctor_id": 11351
 },
 {
   "prescription_id": 126447834,
   "prescription_date": "2023-01-08",
   "medication": "White Ash",
   "drug_brand": "White Ash",
   "patient_id": 666059384,
   "doctor_id": 11352
 },
 {
   "prescription_id": 760616210,
   "prescription_date": "2023-06-12",
   "medication": "Diltiazem Hydrochloride",
   "drug_brand": "Diltiazem Hydrochloride",
   "patient_id": 381282331,
   "doctor_id": 11353
 },
 {
   "prescription_id": 622904785,
   "prescription_date": "2023-01-05",
   "medication": "Paricalcitol",
   "drug_brand": "Paricalcitol",
   "patient_id": 924528870,
   "doctor_id": 11354
 },
 {
   "prescription_id": 785393695,
   "prescription_date": "2022-12-19",
   "medication": "Aconitum napellus, Arsenicum album, Baptisia tinctoria, Belladonna, Bryonia, Causticum, Echinacea, Eupatorium perfoliatum, Ferrum phosphoricum, Gelsemium sempervirens, Hydrastis canadensis,",
   "drug_brand": "Infect Rescue",
   "patient_id": 86059531,
   "doctor_id": 11355
 },
 {
   "prescription_id": 18935872,
   "prescription_date": "2023-03-07",
   "medication": "Minocycline Hydrochloride",
   "drug_brand": "Minocycline Hydrochloride",
   "patient_id": 407769727,
   "doctor_id": 11356
 },
 {
   "prescription_id": 577828562,
   "prescription_date": "2023-09-05",
   "medication": "BENZALKONIUM CHLORIDE",
   "drug_brand": "Hy5 Alcohol Free Fragrance Free Foaming Hand Sanitizer",
   "patient_id": 282326788,
   "doctor_id": 11357
 },
 {
   "prescription_id": 476799766,
   "prescription_date": "2023-04-09",
   "medication": "Homosalate, Octinoxate, Avobenzone and Octocrylene",
   "drug_brand": "LIPSTICK QUEEN ENDLESS SUMMER Broad Spectrum SPF 15 Sunscreen",
   "patient_id": 186918018,
   "doctor_id": 11358
 },
 {
   "prescription_id": 526461806,
   "prescription_date": "2023-09-23",
   "medication": "Cetirizine Hydrochloride",
   "drug_brand": "Zyrtec",
   "patient_id": 890414331,
   "doctor_id": 11359
 },
 {
   "prescription_id": 781193254,
   "prescription_date": "2023-05-31",
   "medication": "Escitalopram",
   "drug_brand": "Escitalopram",
   "patient_id": 708402744,
   "doctor_id": 11360
 },
 {
   "prescription_id": 776478100,
   "prescription_date": "2023-03-07",
   "medication": "Sodium fluoride",
   "drug_brand": "ACT Anticavity Fluoride Kids Bubblegum",
   "patient_id": 447124052,
   "doctor_id": 11361
 },
 {
   "prescription_id": 120811548,
   "prescription_date": "2023-08-25",
   "medication": "Cetylpyridinium chloride",
   "drug_brand": "Crest Pro-Health Multi-Protection",
   "patient_id": 418087409,
   "doctor_id": 11362
 },
 {
   "prescription_id": 718747937,
   "prescription_date": "2023-07-21",
   "medication": "Risperidone",
   "drug_brand": "Risperidone",
   "patient_id": 196178628,
   "doctor_id": 11363
 },
 {
   "prescription_id": 760784565,
   "prescription_date": "2023-04-23",
   "medication": "Tobacco Leaf",
   "drug_brand": "Tobacco Leaf",
   "patient_id": 627492498,
   "doctor_id": 11364
 },
 {
   "prescription_id": 976829706,
   "prescription_date": "2023-09-03",
   "medication": "Quetiapine Fumarate",
   "drug_brand": "Quetiapine Fumarate",
   "patient_id": 134474461,
   "doctor_id": 11365
 },
 {
   "prescription_id": 733336987,
   "prescription_date": "2023-07-01",
   "medication": "betamethasone valerate",
   "drug_brand": "Betamethasone Valerate",
   "patient_id": 853201296,
   "doctor_id": 11366
 },
 {
   "prescription_id": 265004036,
   "prescription_date": "2022-12-15",
   "medication": "Metformin hydrochloride",
   "drug_brand": "Metformin hydrochloride",
   "patient_id": 474252687,
   "doctor_id": 11367
 },
 {
   "prescription_id": 860844044,
   "prescription_date": "2023-09-26",
   "medication": "Loratadine",
   "drug_brand": "Childrens Loratadine",
   "patient_id": 137137630,
   "doctor_id": 11368
 },
 {
   "prescription_id": 426570652,
   "prescription_date": "2023-06-22",
   "medication": "AVOBENZONE, OCTINOXATE, and OCTISALATE",
   "drug_brand": "LAB SERIES SKINCARE FOR MEN DAILY MOISTURE DEFENSE BROAD SPECTRUM SPF 15",
   "patient_id": 661910972,
   "doctor_id": 11369
 },
 {
   "prescription_id": 397341561,
   "prescription_date": "2023-03-17",
   "medication": "Morphine Sulfate",
   "drug_brand": "Morphine Sulfate",
   "patient_id": 536786017,
   "doctor_id": 11370
 },
 {
   "prescription_id": 704939453,
   "prescription_date": "2023-03-17",
   "medication": "Dihydrocodeine Bitartrate, Phenylephrine Hydrochloride, Guaifenesin",
   "drug_brand": "Donatuss",
   "patient_id": 778253730,
   "doctor_id": 11371
 },
 {
   "prescription_id": 964254321,
   "prescription_date": "2023-09-24",
   "medication": "Aspirin",
   "drug_brand": "Flanax Aspirin Pain Reliever",
   "patient_id": 518505968,
   "doctor_id": 11372
 },
 {
   "prescription_id": 768531715,
   "prescription_date": "2023-05-16",
   "medication": "peginterferon alfa-2b",
   "drug_brand": "PEGINTRON",
   "patient_id": 707411426,
   "doctor_id": 11373
 },
 {
   "prescription_id": 79849873,
   "prescription_date": "2023-09-09",
   "medication": "Olanzapine",
   "drug_brand": "ZYPREXA",
   "patient_id": 249741020,
   "doctor_id": 11374
 },
 {
   "prescription_id": 112050774,
   "prescription_date": "2023-11-03",
   "medication": "Glycerin",
   "drug_brand": "BEEVENOM EMULSION",
   "patient_id": 783018434,
   "doctor_id": 11375
 },
 {
   "prescription_id": 640655792,
   "prescription_date": "2022-12-03",
   "medication": "Calc sil, Echinacea, Hepar sulph, Silica mar, Sulfur iod",
   "drug_brand": "Boil-Rx",
   "patient_id": 349597755,
   "doctor_id": 11376
 },
 {
   "prescription_id": 819781736,
   "prescription_date": "2023-05-14",
   "medication": "acetaminophen, caffeine, dihydrocodeine bitartrate",
   "drug_brand": "Trezix",
   "patient_id": 582503638,
   "doctor_id": 11377
 },
 {
   "prescription_id": 937583169,
   "prescription_date": "2023-04-13",
   "medication": "Bayberry Wax Myrtle",
   "drug_brand": "MORELLA CERIFERA POLLEN",
   "patient_id": 759950584,
   "doctor_id": 11378
 },
 {
   "prescription_id": 651954870,
   "prescription_date": "2023-08-15",
   "medication": "Hydrocortisone",
   "drug_brand": "hydrocortisone",
   "patient_id": 625735054,
   "doctor_id": 11379
 },
 {
   "prescription_id": 957193537,
   "prescription_date": "2023-01-20",
   "medication": "Alcohol",
   "drug_brand": "Harris Teeter",
   "patient_id": 570818174,
   "doctor_id": 11380
 },
 {
   "prescription_id": 622668493,
   "prescription_date": "2023-03-01",
   "medication": "Hydrogen Peroxide",
   "drug_brand": "Hydrogen Peroxide",
   "patient_id": 902124954,
   "doctor_id": 11381
 },
 {
   "prescription_id": 827208536,
   "prescription_date": "2023-03-05",
   "medication": "Ampicillin Sodium",
   "drug_brand": "Ampicillin",
   "patient_id": 245274251,
   "doctor_id": 11382
 },
 {
   "prescription_id": 629714906,
   "prescription_date": "2023-08-17",
   "medication": "amitriptyline hydrochloride",
   "drug_brand": "Amitriptyline Hydrochloride",
   "patient_id": 478632290,
   "doctor_id": 11383
 },
 {
   "prescription_id": 198503727,
   "prescription_date": "2023-07-04",
   "medication": "topiramate",
   "drug_brand": "Trokendi XR",
   "patient_id": 500039825,
   "doctor_id": 11384
 },
 {
   "prescription_id": 842240643,
   "prescription_date": "2023-07-20",
   "medication": "phenylephrine hydrochloride and witch hazel",
   "drug_brand": "Leader",
   "patient_id": 338587764,
   "doctor_id": 11385
 },
 {
   "prescription_id": 92418185,
   "prescription_date": "2023-03-05",
   "medication": "MEPROBAMATE",
   "drug_brand": "MEPROBAMATE",
   "patient_id": 751396983,
   "doctor_id": 11386
 },
 {
   "prescription_id": 171027756,
   "prescription_date": "2023-08-18",
   "medication": "Minoxidil",
   "drug_brand": "Minoxidil",
   "patient_id": 50742910,
   "doctor_id": 11387
 },
 {
   "prescription_id": 992482953,
   "prescription_date": "2023-03-01",
   "medication": "Omeprazole",
   "drug_brand": "leader omeprazole",
   "patient_id": 165462262,
   "doctor_id": 11388
 },
 {
   "prescription_id": 442485769,
   "prescription_date": "2022-12-10",
   "medication": "Ibuprofen",
   "drug_brand": "Green Guard Ibupro Relief",
   "patient_id": 863180058,
   "doctor_id": 11389
 },
 {
   "prescription_id": 833206616,
   "prescription_date": "2023-09-23",
   "medication": "Raspberry",
   "drug_brand": "Raspberry",
   "patient_id": 102052438,
   "doctor_id": 11390
 },
 {
   "prescription_id": 998381945,
   "prescription_date": "2023-06-14",
   "medication": "TRICLOSAN",
   "drug_brand": "dalan OCEAN BREEZE antibacterial deodorant",
   "patient_id": 871619181,
   "doctor_id": 11391
 },
 {
   "prescription_id": 501687521,
   "prescription_date": "2023-05-16",
   "medication": "Lidocaine",
   "drug_brand": "Premjact Male Desensitizer",
   "patient_id": 423531147,
   "doctor_id": 11392
 },
 {
   "prescription_id": 380160113,
   "prescription_date": "2022-12-17",
   "medication": "Theophylline",
   "drug_brand": "Theophylline",
   "patient_id": 187843865,
   "doctor_id": 11393
 },
 {
   "prescription_id": 145283606,
   "prescription_date": "2023-10-16",
   "medication": "Ovarium 6 Special Order",
   "drug_brand": "Ovarium 6 Special Order",
   "patient_id": 667342061,
   "doctor_id": 11394
 },
 {
   "prescription_id": 667838248,
   "prescription_date": "2022-12-10",
   "medication": "Isoniazid",
   "drug_brand": "Isoniazid",
   "patient_id": 140472123,
   "doctor_id": 11395
 },
 {
   "prescription_id": 745642011,
   "prescription_date": "2023-05-19",
   "medication": "Guaifenesin",
   "drug_brand": "MUCUS RELIEF",
   "patient_id": 966654090,
   "doctor_id": 11396
 },
 {
   "prescription_id": 391371243,
   "prescription_date": "2023-02-07",
   "medication": "Sodium Fluoride",
   "drug_brand": "Ludent",
   "patient_id": 196472497,
   "doctor_id": 11397
 },
 {
   "prescription_id": 325851640,
   "prescription_date": "2022-11-15",
   "medication": "Acetaminophen, Aspirin, and Caffeine",
   "drug_brand": "Bayer Migraine Formula",
   "patient_id": 353386211,
   "doctor_id": 11398
 },
 {
   "prescription_id": 519352015,
   "prescription_date": "2023-10-16",
   "medication": "PROPRANOLOL HYDROCHLORIDE",
   "drug_brand": "PROPRANOLOL HYDROCHLORIDE",
   "patient_id": 980884320,
   "doctor_id": 11399
 },
 {
   "prescription_id": 958079043,
   "prescription_date": "2023-04-19",
   "medication": "Acetaminophen, dextromethorphan HBr, doxylamine succinate, phenylephrine HCl",
   "drug_brand": "Topcare Nite Time Day Time",
   "patient_id": 846986230,
   "doctor_id": 11400
 },
 {
   "prescription_id": 194462625,
   "prescription_date": "2023-06-17",
   "medication": "Salicylic Acid",
   "drug_brand": "salicylic acid",
   "patient_id": 376436306,
   "doctor_id": 11401
 },
 {
   "prescription_id": 435417071,
   "prescription_date": "2023-04-17",
   "medication": "Bupropion Hydrochloride",
   "drug_brand": "Bupropion Hydrochloride",
   "patient_id": 942341893,
   "doctor_id": 11402
 },
 {
   "prescription_id": 150123663,
   "prescription_date": "2023-09-28",
   "medication": "Fenofibric Acid",
   "drug_brand": "FIBRICOR",
   "patient_id": 521982124,
   "doctor_id": 11403
 },
 {
   "prescription_id": 486892455,
   "prescription_date": "2023-08-07",
   "medication": "TRICLOSAN",
   "drug_brand": "Dial Pomeganate and Tangerine Antibacterial Soap",
   "patient_id": 927918713,
   "doctor_id": 11404
 },
 {
   "prescription_id": 904768403,
   "prescription_date": "2023-09-26",
   "medication": "Serotonin,",
   "drug_brand": "Serotonin",
   "patient_id": 781909731,
   "doctor_id": 11405
 },
 {
   "prescription_id": 446995489,
   "prescription_date": "2023-03-31",
   "medication": "Ethyl Alcohol",
   "drug_brand": "Instant Hand Sanitizer",
   "patient_id": 547279741,
   "doctor_id": 11406
 },
 {
   "prescription_id": 541972642,
   "prescription_date": "2023-11-09",
   "medication": "CASTOR OIL",
   "drug_brand": "LEADER Castor",
   "patient_id": 215793399,
   "doctor_id": 11407
 },
 {
   "prescription_id": 600736399,
   "prescription_date": "2023-05-07",
   "medication": "Naproxen",
   "drug_brand": "Naproxen",
   "patient_id": 486924060,
   "doctor_id": 11408
 },
 {
   "prescription_id": 48241537,
   "prescription_date": "2023-08-06",
   "medication": "montelukast sodium",
   "drug_brand": "Montelukast Sodium",
   "patient_id": 148654152,
   "doctor_id": 11409
 },
 {
   "prescription_id": 968470230,
   "prescription_date": "2023-01-22",
   "medication": "SODIUM FLUORIDE",
   "drug_brand": "Anticavity Fluoride Rinse",
   "patient_id": 197898918,
   "doctor_id": 11410
 },
 {
   "prescription_id": 817682976,
   "prescription_date": "2023-11-03",
   "medication": "Avobenzone, Homosalate, Octinoxate, Octisalate, Oxybenzone",
   "drug_brand": "Tahitian Noni",
   "patient_id": 160534729,
   "doctor_id": 11411
 },
 {
   "prescription_id": 576160026,
   "prescription_date": "2023-09-09",
   "medication": "Homeopathic Liquid",
   "drug_brand": "ReHydration",
   "patient_id": 653097176,
   "doctor_id": 11412
 },
 {
   "prescription_id": 600458655,
   "prescription_date": "2023-06-07",
   "medication": "Clonazepam",
   "drug_brand": "Clonazepam",
   "patient_id": 121001453,
   "doctor_id": 11413
 },
 {
   "prescription_id": 14729337,
   "prescription_date": "2023-07-24",
   "medication": "Ropinirole Hydrochloride",
   "drug_brand": "Ropinirole Hydrochloride",
   "patient_id": 606965170,
   "doctor_id": 11414
 },
 {
   "prescription_id": 826824829,
   "prescription_date": "2023-04-08",
   "medication": "Botrytis cinerea",
   "drug_brand": "Botrytis cinerea",
   "patient_id": 637796172,
   "doctor_id": 11415
 },
 {
   "prescription_id": 745382784,
   "prescription_date": "2023-05-10",
   "medication": "Sisal",
   "drug_brand": "Sisal",
   "patient_id": 435260700,
   "doctor_id": 11416
 },
 {
   "prescription_id": 339404484,
   "prescription_date": "2023-03-23",
   "medication": "Meloxicam",
   "drug_brand": "Meloxicam",
   "patient_id": 706180084,
   "doctor_id": 11417
 },
 {
   "prescription_id": 858722699,
   "prescription_date": "2023-03-31",
   "medication": "simvastatin",
   "drug_brand": "Simvastatin",
   "patient_id": 623294770,
   "doctor_id": 11418
 },
 {
   "prescription_id": 928172777,
   "prescription_date": "2022-12-03",
   "medication": "Acetaminophen, dextromethorphan HBr, doxylamine succinate, phenylephrine HCl",
   "drug_brand": "Day Night Cold and Flu",
   "patient_id": 660125232,
   "doctor_id": 11419
 },
 {
   "prescription_id": 993616157,
   "prescription_date": "2023-02-02",
   "medication": "Dimethicone",
   "drug_brand": "Kendall Moisturizing",
   "patient_id": 768934003,
   "doctor_id": 11420
 },
 {
   "prescription_id": 356077440,
   "prescription_date": "2023-05-12",
   "medication": "SIMVASTATIN",
   "drug_brand": "ZOCOR",
   "patient_id": 350104204,
   "doctor_id": 11421
 },
 {
   "prescription_id": 391391735,
   "prescription_date": "2023-04-29",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE, and ZINC OXIDE",
   "drug_brand": "IOPE RETIGEN MOISTURE TWIN CAKE NO.23",
   "patient_id": 484172695,
   "doctor_id": 11422
 },
 {
   "prescription_id": 433534460,
   "prescription_date": "2022-12-04",
   "medication": "Hydrocortisone",
   "drug_brand": "Family Wellness Maximum Strength Hydrocortisone",
   "patient_id": 883839913,
   "doctor_id": 11423
 },
 {
   "prescription_id": 545446823,
   "prescription_date": "2023-05-02",
   "medication": "Amoxicillin",
   "drug_brand": "Amoxicillin",
   "patient_id": 488400609,
   "doctor_id": 11424
 },
 {
   "prescription_id": 716542496,
   "prescription_date": "2023-09-15",
   "medication": "methimazole",
   "drug_brand": "Methimazole",
   "patient_id": 625023306,
   "doctor_id": 11425
 },
 {
   "prescription_id": 328967704,
   "prescription_date": "2023-08-25",
   "medication": "ranolazine",
   "drug_brand": "Ranexa",
   "patient_id": 829378323,
   "doctor_id": 11426
 },
 {
   "prescription_id": 995873062,
   "prescription_date": "2023-07-29",
   "medication": "Ranitidine",
   "drug_brand": "cool mint acid reducer",
   "patient_id": 738299771,
   "doctor_id": 11427
 },
 {
   "prescription_id": 384101798,
   "prescription_date": "2023-10-08",
   "medication": "doxycycline hyclate",
   "drug_brand": "Morgidox",
   "patient_id": 76270626,
   "doctor_id": 11428
 },
 {
   "prescription_id": 205906209,
   "prescription_date": "2023-03-22",
   "medication": "Trazodone Hydrochloride",
   "drug_brand": "Trazodone Hydrochloride",
   "patient_id": 881194918,
   "doctor_id": 11429
 },
 {
   "prescription_id": 302805846,
   "prescription_date": "2023-07-15",
   "medication": "POVIDONE-IODINE",
   "drug_brand": "Povidone Iodine",
   "patient_id": 890556032,
   "doctor_id": 11430
 },
 {
   "prescription_id": 210624318,
   "prescription_date": "2023-03-08",
   "medication": "Hydrocortisone Acetate",
   "drug_brand": "Gadaderm Hydrocortisone",
   "patient_id": 655152320,
   "doctor_id": 11431
 },
 {
   "prescription_id": 501053955,
   "prescription_date": "2023-04-16",
   "medication": "Naproxen sodium",
   "drug_brand": "health mart naproxen sodium",
   "patient_id": 734169746,
   "doctor_id": 11432
 },
 {
   "prescription_id": 390953777,
   "prescription_date": "2023-10-20",
   "medication": "Calcium carbonate",
   "drug_brand": "Sunmark smooth antacid",
   "patient_id": 37776151,
   "doctor_id": 11433
 },
 {
   "prescription_id": 297815792,
   "prescription_date": "2023-04-25",
   "medication": "Neostigmine Methylsulfate",
   "drug_brand": "Neostigmine Methylsulfate",
   "patient_id": 929970592,
   "doctor_id": 11434
 },
 {
   "prescription_id": 54714811,
   "prescription_date": "2023-08-18",
   "medication": "sertraline hydrochloride",
   "drug_brand": "Sertraline Hydrochloride",
   "patient_id": 946192834,
   "doctor_id": 11435
 },
 {
   "prescription_id": 690645100,
   "prescription_date": "2023-08-04",
   "medication": "THIAMINE HYDROCHLORIDE",
   "drug_brand": "Thiamine",
   "patient_id": 880451231,
   "doctor_id": 11436
 },
 {
   "prescription_id": 219232192,
   "prescription_date": "2023-01-19",
   "medication": "Chlordiazepoxide Hydrochloride",
   "drug_brand": "Chlordiazepoxide Hydrochloride",
   "patient_id": 415234328,
   "doctor_id": 11437
 },
 {
   "prescription_id": 136451256,
   "prescription_date": "2023-01-13",
   "medication": "Ferrous Sulfate",
   "drug_brand": "Ferrous Sulfate",
   "patient_id": 666654684,
   "doctor_id": 11438
 },
 {
   "prescription_id": 944985595,
   "prescription_date": "2023-08-08",
   "medication": "Ibuprofen",
   "drug_brand": "Childrens Ibuprofen",
   "patient_id": 583467087,
   "doctor_id": 11439
 },
 {
   "prescription_id": 901957228,
   "prescription_date": "2023-07-31",
   "medication": "diphenoxylate hydrochloride and atropine sulfate",
   "drug_brand": "Diphenoxylate Hydrochloride and Atropine Sulfate",
   "patient_id": 527249909,
   "doctor_id": 11440
 },
 {
   "prescription_id": 386849291,
   "prescription_date": "2023-01-31",
   "medication": "Nitrous Oxide",
   "drug_brand": "Nitrous Oxide",
   "patient_id": 14394039,
   "doctor_id": 11441
 },
 {
   "prescription_id": 930662332,
   "prescription_date": "2023-06-20",
   "medication": "Levothyroxine sodium",
   "drug_brand": "Levothyroxine sodium",
   "patient_id": 218900712,
   "doctor_id": 11442
 },
 {
   "prescription_id": 603403273,
   "prescription_date": "2023-08-10",
   "medication": "Oxytocin",
   "drug_brand": "Oxytocin",
   "patient_id": 300141645,
   "doctor_id": 11443
 },
 {
   "prescription_id": 775537436,
   "prescription_date": "2022-12-15",
   "medication": "Bismuth subsalicylate",
   "drug_brand": "Leader Stomach Relief",
   "patient_id": 630381666,
   "doctor_id": 11444
 },
 {
   "prescription_id": 66019639,
   "prescription_date": "2023-04-02",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE, ZINC OXIDE",
   "drug_brand": "SnowSkin Sunscreen Zinc",
   "patient_id": 786152038,
   "doctor_id": 11445
 },
 {
   "prescription_id": 230633368,
   "prescription_date": "2023-09-08",
   "medication": "Metronidazole",
   "drug_brand": "Metronidazole",
   "patient_id": 858357322,
   "doctor_id": 11446
 },
 {
   "prescription_id": 604607254,
   "prescription_date": "2023-07-03",
   "medication": "phenylephrine hcl, brompheniramine maleate",
   "drug_brand": "dg health cold and allergy",
   "patient_id": 22415356,
   "doctor_id": 11447
 },
 {
   "prescription_id": 663015605,
   "prescription_date": "2023-04-11",
   "medication": "Atropine Sulfate",
   "drug_brand": "Atropine Sulfate",
   "patient_id": 366151155,
   "doctor_id": 11448
 },
 {
   "prescription_id": 802501974,
   "prescription_date": "2023-09-14",
   "medication": "Flumazenil",
   "drug_brand": "Flumazenil",
   "patient_id": 954313360,
   "doctor_id": 11449
 },
 {
   "prescription_id": 237566859,
   "prescription_date": "2023-03-06",
   "medication": "ALCOHOL",
   "drug_brand": "Instant Hand Sanitizer With Aloe and Vitamin E",
   "patient_id": 386026887,
   "doctor_id": 11450
 },
 {
   "prescription_id": 585745370,
   "prescription_date": "2022-12-30",
   "medication": "magnesium hydroxide",
   "drug_brand": "SUNMARK MILK OF MAGNESIA MINT",
   "patient_id": 324923515,
   "doctor_id": 11451
 },
 {
   "prescription_id": 3232695,
   "prescription_date": "2023-05-29",
   "medication": "Rat Epithelium",
   "drug_brand": "Rat Epithelium",
   "patient_id": 943575883,
   "doctor_id": 11452
 },
 {
   "prescription_id": 497968230,
   "prescription_date": "2023-09-14",
   "medication": "Simethicone",
   "drug_brand": "Extra Strength Gas Relief",
   "patient_id": 883167311,
   "doctor_id": 11453
 },
 {
   "prescription_id": 951162148,
   "prescription_date": "2023-01-10",
   "medication": "Aluminum Zirconium Tetrachlorohydrex GLY",
   "drug_brand": "Suave",
   "patient_id": 731826895,
   "doctor_id": 11454
 },
 {
   "prescription_id": 218822694,
   "prescription_date": "2023-04-27",
   "medication": "Octinoxate and Oxybenzone",
   "drug_brand": "LBEL COULEUR LUXE AMPLIFIER XP",
   "patient_id": 703959081,
   "doctor_id": 11455
 },
 {
   "prescription_id": 216038628,
   "prescription_date": "2023-01-03",
   "medication": "Aluminum Zirconium Tetrachlorohydrex GLY",
   "drug_brand": "Degree",
   "patient_id": 744223687,
   "doctor_id": 11456
 },
 {
   "prescription_id": 408581588,
   "prescription_date": "2023-01-25",
   "medication": "TITANIUM DIOXIDE and ZINC OXIDE",
   "drug_brand": "ZO SKIN HEALTH",
   "patient_id": 612258223,
   "doctor_id": 11457
 },
 {
   "prescription_id": 830589708,
   "prescription_date": "2023-10-27",
   "medication": "Sodium Monofluorophosphate",
   "drug_brand": "Morning Fresh",
   "patient_id": 709888692,
   "doctor_id": 11458
 },
 {
   "prescription_id": 244843522,
   "prescription_date": "2023-11-12",
   "medication": "TECHNETIUM TC-99M SODIUM PERTECHNETATE",
   "drug_brand": "Technetium Tc99m Generator",
   "patient_id": 669229183,
   "doctor_id": 11459
 },
 {
   "prescription_id": 83956336,
   "prescription_date": "2023-11-06",
   "medication": "Eszopiclone",
   "drug_brand": "Eszopiclone",
   "patient_id": 858823891,
   "doctor_id": 11460
 },
 {
   "prescription_id": 667292344,
   "prescription_date": "2022-12-22",
   "medication": "baclofen",
   "drug_brand": "Gablofen",
   "patient_id": 654723307,
   "doctor_id": 11461
 },
 {
   "prescription_id": 313315230,
   "prescription_date": "2023-06-21",
   "medication": "Fluoxetine Hydrochloride",
   "drug_brand": "Fluoxetine",
   "patient_id": 63960445,
   "doctor_id": 11462
 },
 {
   "prescription_id": 290694386,
   "prescription_date": "2023-03-23",
   "medication": "Dicloxacillin Sodium",
   "drug_brand": "Dicloxacillin Sodium",
   "patient_id": 42843440,
   "doctor_id": 11463
 },
 {
   "prescription_id": 551641634,
   "prescription_date": "2023-08-01",
   "medication": "Octinoxate and Titanium Dioxide",
   "drug_brand": "NARS ALL DAY LUMINOUS FOUNDATION",
   "patient_id": 819407643,
   "doctor_id": 11464
 },
 {
   "prescription_id": 578227703,
   "prescription_date": "2023-03-02",
   "medication": "Penicillin V Potassium",
   "drug_brand": "Penicillin V Potassium",
   "patient_id": 25927147,
   "doctor_id": 11465
 },
 {
   "prescription_id": 609288834,
   "prescription_date": "2023-09-22",
   "medication": "Lorazepam",
   "drug_brand": "Lorazepam",
   "patient_id": 353202695,
   "doctor_id": 11466
 },
 {
   "prescription_id": 415094585,
   "prescription_date": "2023-03-28",
   "medication": "KETOROLAC TROMETHAMINE",
   "drug_brand": "KETOROLAC TROMETHAMINE",
   "patient_id": 747592361,
   "doctor_id": 11467
 },
 {
   "prescription_id": 826593984,
   "prescription_date": "2023-09-18",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE",
   "drug_brand": "Rimmel London",
   "patient_id": 627415781,
   "doctor_id": 11468
 },
 {
   "prescription_id": 212119027,
   "prescription_date": "2023-09-25",
   "medication": "Cisplatin",
   "drug_brand": "Cisplatin",
   "patient_id": 18573610,
   "doctor_id": 11469
 },
 {
   "prescription_id": 230991545,
   "prescription_date": "2023-04-18",
   "medication": "Lamivudine and Zidovudine",
   "drug_brand": "Lamivudine and Zidovudine",
   "patient_id": 39917989,
   "doctor_id": 11470
 },
 {
   "prescription_id": 438271467,
   "prescription_date": "2023-08-14",
   "medication": "Beef Bovine spp.",
   "drug_brand": "Food - Animal Products and Poultry Products, Beef Bovine spp.",
   "patient_id": 878378933,
   "doctor_id": 11471
 },
 {
   "prescription_id": 990556088,
   "prescription_date": "2022-11-25",
   "medication": "VENLAFAXINE HYDROCHLORIDE",
   "drug_brand": "VENLAFAXINE HYDROCHLORIDE",
   "patient_id": 879106274,
   "doctor_id": 11472
 },
 {
   "prescription_id": 11062866,
   "prescription_date": "2023-04-28",
   "medication": "EPICOCCUM NIGRUM",
   "drug_brand": "EPICOCCUM NIGRUM",
   "patient_id": 454491716,
   "doctor_id": 11473
 },
 {
   "prescription_id": 889647053,
   "prescription_date": "2023-09-02",
   "medication": "ESZOPICLONE",
   "drug_brand": "Lunesta",
   "patient_id": 483478758,
   "doctor_id": 11474
 },
 {
   "prescription_id": 630004724,
   "prescription_date": "2023-08-15",
   "medication": "Acetaminophen, Chlorpheniramine maleate, Dextromethorphan HBr, Phenylephrine HCl",
   "drug_brand": "cold relief",
   "patient_id": 572319515,
   "doctor_id": 11475
 },
 {
   "prescription_id": 872337423,
   "prescription_date": "2023-04-22",
   "medication": "Cayenne Pepper",
   "drug_brand": "Cayenne Pepper",
   "patient_id": 366575206,
   "doctor_id": 11476
 },
 {
   "prescription_id": 222165261,
   "prescription_date": "2023-04-15",
   "medication": "Methocarbamol",
   "drug_brand": "Methocarbamol",
   "patient_id": 846657317,
   "doctor_id": 11477
 },
 {
   "prescription_id": 243591285,
   "prescription_date": "2023-08-15",
   "medication": "triamterene and hydrochlorothiazide",
   "drug_brand": "Triamterene and Hydrochlorothiazide",
   "patient_id": 25021711,
   "doctor_id": 11478
 },
 {
   "prescription_id": 763490710,
   "prescription_date": "2023-05-08",
   "medication": "Pioglitazone",
   "drug_brand": "Pioglitazone",
   "patient_id": 74695298,
   "doctor_id": 11479
 },
 {
   "prescription_id": 820113207,
   "prescription_date": "2023-05-06",
   "medication": "Ciprofloxacin",
   "drug_brand": "Ciprofloxacin",
   "patient_id": 147212329,
   "doctor_id": 11480
 },
 {
   "prescription_id": 970860805,
   "prescription_date": "2023-03-10",
   "medication": "Chloroxylenol",
   "drug_brand": "VioNex",
   "patient_id": 811639771,
   "doctor_id": 11481
 },
 {
   "prescription_id": 916822126,
   "prescription_date": "2023-01-21",
   "medication": "Acyclovir Sodium",
   "drug_brand": "Acyclovir Sodium",
   "patient_id": 331010101,
   "doctor_id": 11482
 },
 {
   "prescription_id": 846094085,
   "prescription_date": "2023-02-04",
   "medication": "bisacodyl",
   "drug_brand": "Bisacodyl",
   "patient_id": 2297959,
   "doctor_id": 11483
 },
 {
   "prescription_id": 403107675,
   "prescription_date": "2022-12-22",
   "medication": "Beta vulgaris, Carduus marianus, Taraxacum officinale, Cholesterinum, Fel tauri, Chelidonium majus, Lycopodium clavatum,",
   "drug_brand": "Hepastat",
   "patient_id": 934262350,
   "doctor_id": 11484
 },
 {
   "prescription_id": 357515682,
   "prescription_date": "2023-10-23",
   "medication": "TITANIUM DIOXIDE",
   "drug_brand": "PHYTOGENIC INFINITE MAKEUP BASE",
   "patient_id": 290461967,
   "doctor_id": 11485
 },
 {
   "prescription_id": 920818614,
   "prescription_date": "2023-10-05",
   "medication": "Doxazosin",
   "drug_brand": "Doxazosin",
   "patient_id": 900240510,
   "doctor_id": 11486
 },
 {
   "prescription_id": 289381070,
   "prescription_date": "2023-05-18",
   "medication": "Aluminum Zirconium Pentachlorohydrex Gly",
   "drug_brand": "RG TD5 Inv.Solid Antiperspirant Deodorant Cooling",
   "patient_id": 973387827,
   "doctor_id": 11487
 },
 {
   "prescription_id": 787922866,
   "prescription_date": "2023-08-08",
   "medication": "Risperidone",
   "drug_brand": "Risperidone",
   "patient_id": 681948800,
   "doctor_id": 11488
 },
 {
   "prescription_id": 278002978,
   "prescription_date": "2023-04-02",
   "medication": "febuxostat",
   "drug_brand": "ULORIC",
   "patient_id": 178145847,
   "doctor_id": 11489
 },
 {
   "prescription_id": 887948857,
   "prescription_date": "2023-07-11",
   "medication": "BENZALKONIUM CHLORIDE, POVIDONE-IODINE, ACETAMINOPHEN, ASPIRIN, DIPHENHYDRAMINE HYDROCHLORIDE, IBUPROFEN, BACITRACIN ZINC, NEOMYCIN SULFATE, POLYMYXIN B SULFATE",
   "drug_brand": "Mountain Series Weekender Medical",
   "patient_id": 187208422,
   "doctor_id": 11490
 },
 {
   "prescription_id": 945715198,
   "prescription_date": "2022-12-05",
   "medication": "Duck Feathers",
   "drug_brand": "Duck Feathers",
   "patient_id": 341300963,
   "doctor_id": 11491
 },
 {
   "prescription_id": 657859842,
   "prescription_date": "2023-06-04",
   "medication": "Clonidine",
   "drug_brand": "Nexiclon XR",
   "patient_id": 56390042,
   "doctor_id": 11492
 },
 {
   "prescription_id": 151626072,
   "prescription_date": "2023-03-02",
   "medication": "OCTINOXATE, ZINC OXIDE",
   "drug_brand": "Vanilla Latte Tinted Moisturizer Broad Spectrum SPF 25 Sunscreen Light",
   "patient_id": 590508251,
   "doctor_id": 11493
 },
 {
   "prescription_id": 719293060,
   "prescription_date": "2023-04-01",
   "medication": "Diaper Rash Treatment",
   "drug_brand": "Bye Bye Diaper Rash",
   "patient_id": 935388170,
   "doctor_id": 11494
 },
 {
   "prescription_id": 117357365,
   "prescription_date": "2023-07-03",
   "medication": "Cyclobenzaprine Hydrochloride",
   "drug_brand": "Cyclobenzaprine Hydrochloride",
   "patient_id": 969405591,
   "doctor_id": 11495
 },
 {
   "prescription_id": 833102407,
   "prescription_date": "2023-04-06",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 381131738,
   "doctor_id": 11496
 },
 {
   "prescription_id": 362852210,
   "prescription_date": "2023-05-27",
   "medication": "Mometasone Furoate",
   "drug_brand": "Mometasone Furoate",
   "patient_id": 592055135,
   "doctor_id": 11497
 },
 {
   "prescription_id": 740899269,
   "prescription_date": "2022-11-16",
   "medication": "PredniSONE",
   "drug_brand": "PredniSONE",
   "patient_id": 599939092,
   "doctor_id": 11498
 },
 {
   "prescription_id": 394438088,
   "prescription_date": "2023-09-23",
   "medication": "Alcohol",
   "drug_brand": "HAND SANITIZER",
   "patient_id": 207667394,
   "doctor_id": 11499
 },
 {
   "prescription_id": 889044800,
   "prescription_date": "2023-05-06",
   "medication": "Salicylic Acid",
   "drug_brand": "Neutrogena Oil Free Moisture",
   "patient_id": 447750689,
   "doctor_id": 11500
 },
 {
   "prescription_id": 497106257,
   "prescription_date": "2023-06-13",
   "medication": "Dextromethorphan Hydrobromide, Guaifenesin",
   "drug_brand": "Good Sense Childrens Mucus Relief Cough",
   "patient_id": 429411258,
   "doctor_id": 11501
 },
 {
   "prescription_id": 408577266,
   "prescription_date": "2023-04-08",
   "medication": "Galantamine",
   "drug_brand": "Galantamine",
   "patient_id": 797862327,
   "doctor_id": 11502
 },
 {
   "prescription_id": 2409334,
   "prescription_date": "2023-01-07",
   "medication": "ZINC OXIDE, OCTINOXATE, TITANIUM DIOXIDE",
   "drug_brand": "NOEVIR N5",
   "patient_id": 479407967,
   "doctor_id": 11503
 },
 {
   "prescription_id": 353677209,
   "prescription_date": "2023-07-04",
   "medication": "Fluoxetine hydrochloride",
   "drug_brand": "Prozac",
   "patient_id": 210876543,
   "doctor_id": 11504
 },
 {
   "prescription_id": 343965990,
   "prescription_date": "2023-03-19",
   "medication": "AVOBENZONE, OCTOCRYLENE, OXYBENZONE",
   "drug_brand": "HAWAIIAN Tropic",
   "patient_id": 604515794,
   "doctor_id": 11505
 },
 {
   "prescription_id": 242936040,
   "prescription_date": "2022-11-27",
   "medication": "Trichophyton Mentagrophytes",
   "drug_brand": "TRICHOPHYTON MENTAGROPHYTES",
   "patient_id": 989879335,
   "doctor_id": 11506
 },
 {
   "prescription_id": 756298882,
   "prescription_date": "2023-09-22",
   "medication": "Nicotine Polacrilex",
   "drug_brand": "nicotine",
   "patient_id": 220735964,
   "doctor_id": 11507
 },
 {
   "prescription_id": 171657244,
   "prescription_date": "2023-06-01",
   "medication": "Ruta Graveolens",
   "drug_brand": "Pain Relief",
   "patient_id": 808413564,
   "doctor_id": 11508
 },
 {
   "prescription_id": 613968411,
   "prescription_date": "2023-11-02",
   "medication": "acetaminophen, dextromethorphan hydrobromide, guaifenesin, and phenylephrine hydrochloride",
   "drug_brand": "Childrens Delsym",
   "patient_id": 829467866,
   "doctor_id": 11509
 },
 {
   "prescription_id": 271806562,
   "prescription_date": "2023-02-09",
   "medication": "Ampicillin Sodium",
   "drug_brand": "Ampicillin",
   "patient_id": 188513616,
   "doctor_id": 11510
 },
 {
   "prescription_id": 235147950,
   "prescription_date": "2023-03-17",
   "medication": "Cimetidine",
   "drug_brand": "Cimetidine",
   "patient_id": 901854803,
   "doctor_id": 11511
 },
 {
   "prescription_id": 478426857,
   "prescription_date": "2023-09-07",
   "medication": "Glimepiride",
   "drug_brand": "Glimepiride",
   "patient_id": 491919538,
   "doctor_id": 11512
 },
 {
   "prescription_id": 295919907,
   "prescription_date": "2023-01-19",
   "medication": "Mucor plumbeus",
   "drug_brand": "Mucor plumbeus",
   "patient_id": 659724148,
   "doctor_id": 11513
 },
 {
   "prescription_id": 657399829,
   "prescription_date": "2023-05-03",
   "medication": "Nicotine Polacrilex",
   "drug_brand": "nicotine",
   "patient_id": 145389062,
   "doctor_id": 11514
 },
 {
   "prescription_id": 565819314,
   "prescription_date": "2023-10-02",
   "medication": "Primaquine Phosphate",
   "drug_brand": "Primaquine Phosphate",
   "patient_id": 776243688,
   "doctor_id": 11515
 },
 {
   "prescription_id": 423615432,
   "prescription_date": "2022-11-25",
   "medication": "spironolactone",
   "drug_brand": "Spironolactone",
   "patient_id": 184592138,
   "doctor_id": 11516
 },
 {
   "prescription_id": 427381682,
   "prescription_date": "2023-01-28",
   "medication": "Sword Fish",
   "drug_brand": "Sword Fish",
   "patient_id": 621004408,
   "doctor_id": 11517
 },
 {
   "prescription_id": 425004667,
   "prescription_date": "2023-02-06",
   "medication": "ARSENIC TRIOXIDE",
   "drug_brand": "ARSENICUM ALBUM",
   "patient_id": 252815187,
   "doctor_id": 11518
 },
 {
   "prescription_id": 325144382,
   "prescription_date": "2023-08-30",
   "medication": "nifedipine",
   "drug_brand": "Nifedipine",
   "patient_id": 545455312,
   "doctor_id": 11519
 },
 {
   "prescription_id": 226273392,
   "prescription_date": "2023-09-06",
   "medication": "Metoclopramide",
   "drug_brand": "Metoclopramide",
   "patient_id": 523320726,
   "doctor_id": 11520
 },
 {
   "prescription_id": 38951085,
   "prescription_date": "2023-08-13",
   "medication": "Aspirin",
   "drug_brand": "Aspirin",
   "patient_id": 598563519,
   "doctor_id": 11521
 },
 {
   "prescription_id": 725681819,
   "prescription_date": "2023-02-14",
   "medication": "Alendronate Sodium",
   "drug_brand": "Alendronate Sodium",
   "patient_id": 937545077,
   "doctor_id": 11522
 },
 {
   "prescription_id": 455155097,
   "prescription_date": "2023-04-14",
   "medication": "Peanut",
   "drug_brand": "Peanut",
   "patient_id": 99096823,
   "doctor_id": 11523
 },
 {
   "prescription_id": 538183510,
   "prescription_date": "2023-10-20",
   "medication": "Diltiazem Hydrochloride Extended-Release Tablets",
   "drug_brand": "Diltiazem Hydrochloride",
   "patient_id": 436995951,
   "doctor_id": 11524
 },
 {
   "prescription_id": 284049780,
   "prescription_date": "2023-03-14",
   "medication": "Amoxicillin",
   "drug_brand": "Amoxicillin",
   "patient_id": 42423535,
   "doctor_id": 11525
 },
 {
   "prescription_id": 422653031,
   "prescription_date": "2022-11-29",
   "medication": "hydrocodone bitartrate",
   "drug_brand": "Zohydro",
   "patient_id": 806821599,
   "doctor_id": 11526
 },
 {
   "prescription_id": 427415199,
   "prescription_date": "2023-04-02",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 428044745,
   "doctor_id": 11527
 },
 {
   "prescription_id": 139233221,
   "prescription_date": "2022-12-14",
   "medication": "prazosin hydrochloride",
   "drug_brand": "Prazosin Hydrochloride",
   "patient_id": 585156219,
   "doctor_id": 11528
 },
 {
   "prescription_id": 250835853,
   "prescription_date": "2023-08-17",
   "medication": "Acetaminophen, Chlorpheniramine Maleate, Dextromethorphan HBr, Phenylephrine HCl",
   "drug_brand": "multi symptom cold relief",
   "patient_id": 960806565,
   "doctor_id": 11529
 },
 {
   "prescription_id": 876500628,
   "prescription_date": "2023-05-21",
   "medication": ".Alpha.-Tocopherol Acetate, DL-, Ascorbic Acid, Cyanocobalamin, Sodium Fluoride, Folic Acid, Niacin, Pyridoxine, Riboflavin, Thiamine, Vitamin A, and Vitamin D",
   "drug_brand": "Multivitamin with fluoride",
   "patient_id": 376111879,
   "doctor_id": 11530
 },
 {
   "prescription_id": 863409933,
   "prescription_date": "2023-09-13",
   "medication": "Not applicable",
   "drug_brand": "Enviroclenz",
   "patient_id": 246164908,
   "doctor_id": 11531
 },
 {
   "prescription_id": 606061785,
   "prescription_date": "2023-07-01",
   "medication": "Yellow Dock",
   "drug_brand": "Yellow Dock",
   "patient_id": 208177476,
   "doctor_id": 11532
 },
 {
   "prescription_id": 415866127,
   "prescription_date": "2023-08-18",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 35575624,
   "doctor_id": 11533
 },
 {
   "prescription_id": 924676133,
   "prescription_date": "2023-03-10",
   "medication": "NAJA NAJA VENOM",
   "drug_brand": "NYLOXIN",
   "patient_id": 255011495,
   "doctor_id": 11534
 },
 {
   "prescription_id": 707648784,
   "prescription_date": "2023-08-14",
   "medication": "PSYLLIUM HUSK",
   "drug_brand": "equate Sugar Free Fiber Therapy Smooth Texture Orange Flavor",
   "patient_id": 204613429,
   "doctor_id": 11535
 },
 {
   "prescription_id": 805635015,
   "prescription_date": "2023-10-05",
   "medication": "Pyrithione Zinc",
   "drug_brand": "LBEL",
   "patient_id": 3920046,
   "doctor_id": 11536
 },
 {
   "prescription_id": 485089362,
   "prescription_date": "2023-11-11",
   "medication": "Hydrocortisone",
   "drug_brand": "healthy accents cortisone",
   "patient_id": 730244038,
   "doctor_id": 11537
 },
 {
   "prescription_id": 448756554,
   "prescription_date": "2023-03-09",
   "medication": "diphenhydramine citrate and ibuprofen",
   "drug_brand": "sunmark ibuprofen pm",
   "patient_id": 907809267,
   "doctor_id": 11538
 },
 {
   "prescription_id": 669697225,
   "prescription_date": "2023-03-08",
   "medication": "Acetaminophen",
   "drug_brand": "Pain and Fever",
   "patient_id": 328484013,
   "doctor_id": 11539
 },
 {
   "prescription_id": 345173546,
   "prescription_date": "2023-07-29",
   "medication": "Aluminum Sesquichlorohydrate",
   "drug_brand": "CYZONE",
   "patient_id": 154597673,
   "doctor_id": 11540
 },
 {
   "prescription_id": 364544781,
   "prescription_date": "2023-01-23",
   "medication": "Calc phos, Kali sulph, Nat sulphuricum",
   "drug_brand": "Triple Complex Glucose Control",
   "patient_id": 697094684,
   "doctor_id": 11541
 },
 {
   "prescription_id": 517422240,
   "prescription_date": "2023-01-14",
   "medication": "Octinoxate, Octisalate, and Oxybenzone",
   "drug_brand": "Neutrogena OIl Free Moisture",
   "patient_id": 929063617,
   "doctor_id": 11542
 },
 {
   "prescription_id": 636681870,
   "prescription_date": "2023-01-26",
   "medication": "APIOLUM",
   "drug_brand": "APIOLUM",
   "patient_id": 603095791,
   "doctor_id": 11543
 },
 {
   "prescription_id": 29988551,
   "prescription_date": "2023-01-03",
   "medication": "adenosine",
   "drug_brand": "Adenosine",
   "patient_id": 333820060,
   "doctor_id": 11544
 },
 {
   "prescription_id": 497638317,
   "prescription_date": "2023-03-04",
   "medication": "Ondansetron HCL",
   "drug_brand": "Ondansetron HCL",
   "patient_id": 682607507,
   "doctor_id": 11545
 },
 {
   "prescription_id": 450682005,
   "prescription_date": "2023-04-15",
   "medication": "Fexofenadine HCl",
   "drug_brand": "Allergy Relief",
   "patient_id": 994855858,
   "doctor_id": 11546
 },
 {
   "prescription_id": 954218805,
   "prescription_date": "2022-11-21",
   "medication": "Miconazole Nitrate",
   "drug_brand": "Monistat 1 Combination Pack",
   "patient_id": 592374001,
   "doctor_id": 11547
 },
 {
   "prescription_id": 685575616,
   "prescription_date": "2023-07-08",
   "medication": "Fluoxetine",
   "drug_brand": "Fluoxetine",
   "patient_id": 273416192,
   "doctor_id": 11548
 },
 {
   "prescription_id": 510585577,
   "prescription_date": "2022-12-03",
   "medication": "Treatment Set TS346620",
   "drug_brand": "Treatment Set TS346620",
   "patient_id": 364249880,
   "doctor_id": 11549
 },
 {
   "prescription_id": 306897816,
   "prescription_date": "2023-05-16",
   "medication": "TRIBASIC CALCIUM PHOSPHATE, MATRICARIA RECUTITA, ARABICA COFFEE BEAN, ATROPA BELLADONNA, MAGNESIUM PHOSPHATE, DIBASIC TRIHYDRATE, SILICON DIOXIDE, and RHEUM OFFICINALE ROOT",
   "drug_brand": "NIGHTTIME TEETHING",
   "patient_id": 273661298,
   "doctor_id": 11550
 },
 {
   "prescription_id": 68767149,
   "prescription_date": "2023-05-01",
   "medication": "Levothyroxine sodium",
   "drug_brand": "Levothyroxine sodium",
   "patient_id": 65371072,
   "doctor_id": 11551
 },
 {
   "prescription_id": 425210336,
   "prescription_date": "2023-09-05",
   "medication": "Oxymetazoline HCl",
   "drug_brand": "nasal",
   "patient_id": 180138867,
   "doctor_id": 11302
 },
 {
   "prescription_id": 916490281,
   "prescription_date": "2023-02-26",
   "medication": "Dermatophagoides pteronyssinus",
   "drug_brand": "STANDARDIZED MITE D PTERONYSSINUS",
   "patient_id": 155537626,
   "doctor_id": 11303
 },
 {
   "prescription_id": 87184498,
   "prescription_date": "2023-09-30",
   "medication": "Aluminum Zirconium Tetrachlorohydrex GLY",
   "drug_brand": "Degree Women UltraClear Pure Rain",
   "patient_id": 506688784,
   "doctor_id": 11304
 },
 {
   "prescription_id": 852133997,
   "prescription_date": "2023-04-30",
   "medication": "Hydrocortisone",
   "drug_brand": "Scalpicin",
   "patient_id": 71090443,
   "doctor_id": 11305
 },
 {
   "prescription_id": 787929590,
   "prescription_date": "2023-04-28",
   "medication": "CAULOPHYLLUM THALICTROIDES",
   "drug_brand": "CAULOPHYLLUM THALICTROIDES",
   "patient_id": 394352457,
   "doctor_id": 11306
 },
 {
   "prescription_id": 803450269,
   "prescription_date": "2023-02-26",
   "medication": "Benzocaine",
   "drug_brand": "Lollicaine Pina Colada",
   "patient_id": 581906070,
   "doctor_id": 11307
 },
 {
   "prescription_id": 695175759,
   "prescription_date": "2023-03-17",
   "medication": "flurazepam hydrochloride",
   "drug_brand": "Flurazepam Hydrochloride",
   "patient_id": 719019779,
   "doctor_id": 11308
 },
 {
   "prescription_id": 221760789,
   "prescription_date": "2023-09-06",
   "medication": "Ibuprofen",
   "drug_brand": "sunmark ibuprofen",
   "patient_id": 649261849,
   "doctor_id": 11309
 },
 {
   "prescription_id": 53633777,
   "prescription_date": "2023-09-23",
   "medication": "tetrahydrozoline HCl",
   "drug_brand": "Redness reliever",
   "patient_id": 333221560,
   "doctor_id": 11310
 },
 {
   "prescription_id": 834169277,
   "prescription_date": "2023-09-07",
   "medication": "TRETINOIN",
   "drug_brand": "TRETIN.X",
   "patient_id": 372813190,
   "doctor_id": 11311
 },
 {
   "prescription_id": 301507928,
   "prescription_date": "2023-08-27",
   "medication": "Phenazopyridine",
   "drug_brand": "Phenazopyridine Hydrochloride",
   "patient_id": 85007457,
   "doctor_id": 11312
 },
 {
   "prescription_id": 873371236,
   "prescription_date": "2023-10-08",
   "medication": "Beractant",
   "drug_brand": "Survanta",
   "patient_id": 388072192,
   "doctor_id": 11313
 },
 {
   "prescription_id": 513036315,
   "prescription_date": "2023-10-25",
   "medication": "Benzalkonium Chloride",
   "drug_brand": "Kleenex Foam Antibacterial Skin Cleanser",
   "patient_id": 502880069,
   "doctor_id": 11314
 },
 {
   "prescription_id": 27187572,
   "prescription_date": "2023-10-16",
   "medication": "Donepezil Hydrochloride",
   "drug_brand": "Donepezil Hydrochloride",
   "patient_id": 403168081,
   "doctor_id": 11315
 },
 {
   "prescription_id": 398663336,
   "prescription_date": "2022-12-12",
   "medication": "Menthol",
   "drug_brand": "Cryogel Island Rain Natural Pain Relieving",
   "patient_id": 444020272,
   "doctor_id": 11316
 },
 {
   "prescription_id": 194328808,
   "prescription_date": "2022-12-11",
   "medication": "Acetaminophen",
   "drug_brand": "Extra Strength Acetaminophen",
   "patient_id": 643925198,
   "doctor_id": 11317
 },
 {
   "prescription_id": 277780574,
   "prescription_date": "2023-07-07",
   "medication": "TOPIRAMATE",
   "drug_brand": "TOPIRAMATE",
   "patient_id": 395843428,
   "doctor_id": 11318
 },
 {
   "prescription_id": 842915162,
   "prescription_date": "2023-11-05",
   "medication": "Tuna Fish",
   "drug_brand": "Tuna Fish",
   "patient_id": 567334355,
   "doctor_id": 11319
 },
 {
   "prescription_id": 987839155,
   "prescription_date": "2023-08-22",
   "medication": "Earwax Removal Kit",
   "drug_brand": "Earwax Removal Kit",
   "patient_id": 388051628,
   "doctor_id": 11320
 },
 {
   "prescription_id": 546736957,
   "prescription_date": "2022-12-05",
   "medication": "naproxen",
   "drug_brand": "Naprosyn",
   "patient_id": 390924633,
   "doctor_id": 11321
 },
 {
   "prescription_id": 954165628,
   "prescription_date": "2023-10-18",
   "medication": "TITANIUM DIOXIDE",
   "drug_brand": "CLARINS Broad Spectrum SPF 15 Sunscreen Extra-Firming Foundation Tint 108",
   "patient_id": 416720452,
   "doctor_id": 11322
 },
 {
   "prescription_id": 119537419,
   "prescription_date": "2023-04-07",
   "medication": "TITANIUM DIOXIDE",
   "drug_brand": "CLARINS Ever Matte Broad Spectrum SPF 15 Tint 107",
   "patient_id": 797659316,
   "doctor_id": 11323
 },
 {
   "prescription_id": 586744017,
   "prescription_date": "2023-06-27",
   "medication": "PRIMIDONE",
   "drug_brand": "PRIMIDONE",
   "patient_id": 752517319,
   "doctor_id": 11324
 },
 {
   "prescription_id": 298509707,
   "prescription_date": "2023-04-02",
   "medication": "Progesterone Injection",
   "drug_brand": "Progesterone Injection",
   "patient_id": 47866943,
   "doctor_id": 11325
 },
 {
   "prescription_id": 42648016,
   "prescription_date": "2023-08-01",
   "medication": "Salicylic Acid",
   "drug_brand": "Acne and Blemish Target",
   "patient_id": 877265404,
   "doctor_id": 11326
 },
 {
   "prescription_id": 947156628,
   "prescription_date": "2023-05-29",
   "medication": "Fluoxetine Hydrochloride",
   "drug_brand": "Fluoxetine",
   "patient_id": 228493718,
   "doctor_id": 11327
 },
 {
   "prescription_id": 308786299,
   "prescription_date": "2023-06-02",
   "medication": "Venlafaxine Hydrochloride",
   "drug_brand": "Venlafaxine Hydrochloride",
   "patient_id": 806283022,
   "doctor_id": 11328
 },
 {
   "prescription_id": 454383847,
   "prescription_date": "2023-09-23",
   "medication": "QUETIAPINE FUMARATE",
   "drug_brand": "QUETIAPINE FUMARATE",
   "patient_id": 939205933,
   "doctor_id": 11329
 },
 {
   "prescription_id": 982052424,
   "prescription_date": "2023-08-09",
   "medication": "Acetaminophen, Aspirin, Caffeine",
   "drug_brand": "Smart Sense migraine relief",
   "patient_id": 257708969,
   "doctor_id": 11330
 },
 {
   "prescription_id": 952085204,
   "prescription_date": "2023-07-26",
   "medication": "Acetaminophen, Dextromethorphan HBr, Phenylephrine HCl",
   "drug_brand": "Cold Head Congestion Daytime Non-Drowsy",
   "patient_id": 883510909,
   "doctor_id": 11331
 },
 {
   "prescription_id": 881267372,
   "prescription_date": "2023-07-24",
   "medication": "nifedipine",
   "drug_brand": "nifedipine",
   "patient_id": 472481729,
   "doctor_id": 11332
 },
 {
   "prescription_id": 271259766,
   "prescription_date": "2023-02-21",
   "medication": "fluconazole",
   "drug_brand": "Diflucan",
   "patient_id": 780975441,
   "doctor_id": 11333
 },
 {
   "prescription_id": 505521120,
   "prescription_date": "2023-05-01",
   "medication": "povidone-iodine",
   "drug_brand": "Povidone Iodine",
   "patient_id": 873684294,
   "doctor_id": 11334
 },
 {
   "prescription_id": 159206232,
   "prescription_date": "2023-09-12",
   "medication": "Arnica, Apis, Hepar Sulph, Hypericum, Ledum, Silicea",
   "drug_brand": "Infected Cuts and Punctures",
   "patient_id": 318485506,
   "doctor_id": 11335
 },
 {
   "prescription_id": 451205447,
   "prescription_date": "2022-11-21",
   "medication": "light mineral oil and mineral oil",
   "drug_brand": "Soothe XP",
   "patient_id": 970283344,
   "doctor_id": 11336
 },
 {
   "prescription_id": 357454314,
   "prescription_date": "2022-12-08",
   "medication": "Fenofibric Acid",
   "drug_brand": "Trilipix",
   "patient_id": 813290433,
   "doctor_id": 11337
 },
 {
   "prescription_id": 388634783,
   "prescription_date": "2022-11-29",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 684321934,
   "doctor_id": 11338
 },
 {
   "prescription_id": 140081176,
   "prescription_date": "2023-02-23",
   "medication": "Antihemophilic Factor Recombinant",
   "drug_brand": "Recombinate",
   "patient_id": 396824525,
   "doctor_id": 11339
 },
 {
   "prescription_id": 844721343,
   "prescription_date": "2022-11-26",
   "medication": "Miconazole nitrate",
   "drug_brand": "Baza Antifungal",
   "patient_id": 747195788,
   "doctor_id": 11340
 },
 {
   "prescription_id": 491192690,
   "prescription_date": "2023-01-01",
   "medication": "MALATHION",
   "drug_brand": "OVIDE",
   "patient_id": 738184994,
   "doctor_id": 11341
 },
 {
   "prescription_id": 510936819,
   "prescription_date": "2022-11-29",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 306449774,
   "doctor_id": 11342
 },
 {
   "prescription_id": 603527018,
   "prescription_date": "2023-01-18",
   "medication": "Benzalkonium Chloride",
   "drug_brand": "Antibacterial Foaming Hand",
   "patient_id": 31093536,
   "doctor_id": 11343
 },
 {
   "prescription_id": 693435088,
   "prescription_date": "2023-05-18",
   "medication": "Quetiapine fumarate",
   "drug_brand": "Quetiapine fumarate",
   "patient_id": 443159557,
   "doctor_id": 11344
 },
 {
   "prescription_id": 668350701,
   "prescription_date": "2023-06-05",
   "medication": "Dextromethorphan Hydrobromide, Guaifenesin",
   "drug_brand": "Good Neighbor Pharmacy Tussin dm",
   "patient_id": 505834958,
   "doctor_id": 11345
 },
 {
   "prescription_id": 615674929,
   "prescription_date": "2022-12-20",
   "medication": "ciprofloxacin",
   "drug_brand": "Ciprofloxacin",
   "patient_id": 732127954,
   "doctor_id": 11346
 },
 {
   "prescription_id": 44038450,
   "prescription_date": "2023-05-18",
   "medication": "Labetalol hydrochloride",
   "drug_brand": "Labetalol hydrochloride",
   "patient_id": 203291276,
   "doctor_id": 11347
 },
 {
   "prescription_id": 294791092,
   "prescription_date": "2023-01-29",
   "medication": "CLOSTRIDIUM TETANI TOXOID ANTIGEN (FORMALDEHYDE INACTIVATED)",
   "drug_brand": "TETANUS TOXOID ADSORBED",
   "patient_id": 699496459,
   "doctor_id": 11348
 },
 {
   "prescription_id": 201274492,
   "prescription_date": "2023-03-13",
   "medication": "Bismuth Subsalicylate",
   "drug_brand": "Bismuth Subsalicylate",
   "patient_id": 384857728,
   "doctor_id": 11349
 },
 {
   "prescription_id": 791480689,
   "prescription_date": "2023-01-12",
   "medication": "Homeopathic Sublingual Immunotherapy",
   "drug_brand": "Allergena",
   "patient_id": 820763212,
   "doctor_id": 11350
 },
 {
   "prescription_id": 670291414,
   "prescription_date": "2023-05-15",
   "medication": "Petrolatum",
   "drug_brand": "Care One Medicated Lip Balm in a Pot",
   "patient_id": 632031678,
   "doctor_id": 11351
 },
 {
   "prescription_id": 936577767,
   "prescription_date": "2022-11-15",
   "medication": "Elaps corallinus, Aconitum nap.,Aur. met., Baryta carb., Belladonna, Crotalus horridus, Gelsemium, Hamamelis, Lachesis, Merc. viv.,Phosphorus, Picricum ac., Plumbum met., Pulsatilla,Rhus toxicodendron, Stramonium, Theridion, Euphrasia",
   "drug_brand": "Macular Degeneration",
   "patient_id": 45145366,
   "doctor_id": 11352
 },
 {
   "prescription_id": 946920632,
   "prescription_date": "2023-05-29",
   "medication": "Naproxen sodium, Pseudoephedrine HCl",
   "drug_brand": "Good Neighbor Pharmacy Sinus and Cold D",
   "patient_id": 404231713,
   "doctor_id": 11353
 },
 {
   "prescription_id": 659685884,
   "prescription_date": "2022-12-27",
   "medication": "Theraflu Nighttime",
   "drug_brand": "Flu Relief Therapy Night Time",
   "patient_id": 769193118,
   "doctor_id": 11354
 },
 {
   "prescription_id": 394723032,
   "prescription_date": "2023-08-25",
   "medication": "Nitrogen",
   "drug_brand": "Nitrogen",
   "patient_id": 858031186,
   "doctor_id": 11355
 },
 {
   "prescription_id": 307784313,
   "prescription_date": "2023-10-03",
   "medication": "DEXTROMETHORPHAN HYDROBROMIDE, GUAIFENESIN",
   "drug_brand": "Tussin DM",
   "patient_id": 666404959,
   "doctor_id": 11356
 },
 {
   "prescription_id": 417615488,
   "prescription_date": "2022-12-23",
   "medication": "pioglitazone and glimepiride",
   "drug_brand": "Duetact",
   "patient_id": 995167361,
   "doctor_id": 11357
 },
 {
   "prescription_id": 836163506,
   "prescription_date": "2023-10-18",
   "medication": "Oxymetazoline HCl",
   "drug_brand": "nasal mist",
   "patient_id": 969806601,
   "doctor_id": 11358
 },
 {
   "prescription_id": 147722291,
   "prescription_date": "2022-12-21",
   "medication": "Magnesium citrate",
   "drug_brand": "Magnesium Citrate",
   "patient_id": 161179524,
   "doctor_id": 11359
 },
 {
   "prescription_id": 921386868,
   "prescription_date": "2023-05-11",
   "medication": "Poverty Weed",
   "drug_brand": "Poverty Weed",
   "patient_id": 587742970,
   "doctor_id": 11360
 },
 {
   "prescription_id": 290666718,
   "prescription_date": "2023-10-21",
   "medication": "Lovastatin",
   "drug_brand": "Lovastatin",
   "patient_id": 312156718,
   "doctor_id": 11361
 },
 {
   "prescription_id": 540036846,
   "prescription_date": "2023-02-16",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 800183744,
   "doctor_id": 11362
 },
 {
   "prescription_id": 588424005,
   "prescription_date": "2023-02-25",
   "medication": "Wheat Smut",
   "drug_brand": "Wheat Smut",
   "patient_id": 582841888,
   "doctor_id": 11363
 },
 {
   "prescription_id": 259670692,
   "prescription_date": "2023-03-13",
   "medication": "lorazepam",
   "drug_brand": "Lorazepam",
   "patient_id": 5567131,
   "doctor_id": 11364
 },
 {
   "prescription_id": 606783373,
   "prescription_date": "2023-07-11",
   "medication": "simethicone",
   "drug_brand": "gas relief",
   "patient_id": 505693890,
   "doctor_id": 11365
 },
 {
   "prescription_id": 439951387,
   "prescription_date": "2023-06-18",
   "medication": "Irbesartan",
   "drug_brand": "Irbesartan",
   "patient_id": 791250786,
   "doctor_id": 11366
 },
 {
   "prescription_id": 672276676,
   "prescription_date": "2023-05-13",
   "medication": "Titanium Dioxide and Zinc Oxide",
   "drug_brand": "Purminerals 4-in-1 Mineral Tinted Moisturizer Broad Spectrum SPF 20 (LIGHT)",
   "patient_id": 130571109,
   "doctor_id": 11367
 },
 {
   "prescription_id": 677794415,
   "prescription_date": "2023-02-10",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 875417523,
   "doctor_id": 11368
 },
 {
   "prescription_id": 814671755,
   "prescription_date": "2023-02-26",
   "medication": "Norethindrone",
   "drug_brand": "Norethindrone",
   "patient_id": 842734890,
   "doctor_id": 11369
 },
 {
   "prescription_id": 231613109,
   "prescription_date": "2023-03-23",
   "medication": "SODIUM BICARBONATE",
   "drug_brand": "Neut Sodium Bicarbonate",
   "patient_id": 533119949,
   "doctor_id": 11370
 },
 {
   "prescription_id": 355010798,
   "prescription_date": "2022-12-10",
   "medication": "Nabumetone",
   "drug_brand": "Nabumetone",
   "patient_id": 240344681,
   "doctor_id": 11371
 },
 {
   "prescription_id": 328792628,
   "prescription_date": "2023-05-09",
   "medication": "amlodipine besylate and olmesartan medoxomil",
   "drug_brand": "Azor",
   "patient_id": 966324907,
   "doctor_id": 11372
 },
 {
   "prescription_id": 97042407,
   "prescription_date": "2023-09-13",
   "medication": "Acetaminophen, Dextromethorphan HBr, Phenylephrine HCl, Doxylamine succinate",
   "drug_brand": "Cold and Flu",
   "patient_id": 267175698,
   "doctor_id": 11373
 },
 {
   "prescription_id": 308865076,
   "prescription_date": "2022-12-20",
   "medication": "polyethylene glycol, propylene glycol",
   "drug_brand": "Eye Lubricant",
   "patient_id": 789751037,
   "doctor_id": 11374
 },
 {
   "prescription_id": 449718899,
   "prescription_date": "2023-05-24",
   "medication": "SODIUM FLUORIDE and TRICLOSAN",
   "drug_brand": "Colgate",
   "patient_id": 864220310,
   "doctor_id": 11375
 },
 {
   "prescription_id": 482471694,
   "prescription_date": "2023-05-09",
   "medication": "acetaminophen, dextromethorphan hydrobromide and doxylamine succinate",
   "drug_brand": "McKesson Nite Time",
   "patient_id": 734341774,
   "doctor_id": 11376
 },
 {
   "prescription_id": 446170938,
   "prescription_date": "2023-08-03",
   "medication": "hyoscyamine sulfate, methenamine, methylene blue, phenyl salicylate, and sodium phosphate, monobasic, monohydrate",
   "drug_brand": "Urelle",
   "patient_id": 864719756,
   "doctor_id": 11377
 },
 {
   "prescription_id": 521030252,
   "prescription_date": "2023-09-13",
   "medication": "Octinoxate, Octisalate, and Titanium Dioxide",
   "drug_brand": "09 Balancing Foundation",
   "patient_id": 697049992,
   "doctor_id": 11378
 },
 {
   "prescription_id": 203840163,
   "prescription_date": "2023-05-12",
   "medication": "Neomycin Sulfate",
   "drug_brand": "Antibiotic",
   "patient_id": 187125560,
   "doctor_id": 11379
 },
 {
   "prescription_id": 798337305,
   "prescription_date": "2023-08-19",
   "medication": "Butalbital, Aspirin, Caffeine, and Codeine Phosphate",
   "drug_brand": "Fiorinal with Codeine",
   "patient_id": 28045487,
   "doctor_id": 11380
 },
 {
   "prescription_id": 119101680,
   "prescription_date": "2023-03-28",
   "medication": "Acetaminophen, Dextromethorphan HBr, Doxylamine succinate",
   "drug_brand": "Nighttime",
   "patient_id": 558447165,
   "doctor_id": 11381
 },
 {
   "prescription_id": 409650745,
   "prescription_date": "2023-07-04",
   "medication": "Acetaminophen, Phenylephrine HCl",
   "drug_brand": "equate sinus",
   "patient_id": 908185378,
   "doctor_id": 11382
 },
 {
   "prescription_id": 234430210,
   "prescription_date": "2023-09-05",
   "medication": "Octocrylene, Avobenzone",
   "drug_brand": "SPF-15 Sunscreen",
   "patient_id": 495424841,
   "doctor_id": 11383
 },
 {
   "prescription_id": 142809365,
   "prescription_date": "2023-02-25",
   "medication": "Dicloxacillin Sodium",
   "drug_brand": "Dicloxacillin Sodium",
   "patient_id": 752047936,
   "doctor_id": 11384
 },
 {
   "prescription_id": 899760267,
   "prescription_date": "2023-04-03",
   "medication": "Fragaria Vitis Liver Support",
   "drug_brand": "Fragaria Vitis Liver Support",
   "patient_id": 313519494,
   "doctor_id": 11385
 },
 {
   "prescription_id": 503497595,
   "prescription_date": "2023-10-15",
   "medication": "Calcitriol",
   "drug_brand": "Calcitriol",
   "patient_id": 520593545,
   "doctor_id": 11386
 },
 {
   "prescription_id": 832651281,
   "prescription_date": "2023-09-20",
   "medication": "Boldo, Carduus Marianus, Curcuma Longa, Echinacea, Taraxacum Officinale, Magnesia Phosphorica, Gallbladder",
   "drug_brand": "Liver Tonic II",
   "patient_id": 110191095,
   "doctor_id": 11387
 },
 {
   "prescription_id": 659391801,
   "prescription_date": "2023-06-14",
   "medication": "icatibant acetate",
   "drug_brand": "Firazyr",
   "patient_id": 676935066,
   "doctor_id": 11388
 },
 {
   "prescription_id": 377100876,
   "prescription_date": "2023-08-30",
   "medication": "paroxetine hydrochloride",
   "drug_brand": "PAXIL",
   "patient_id": 61612635,
   "doctor_id": 11389
 },
 {
   "prescription_id": 685139579,
   "prescription_date": "2023-05-13",
   "medication": "alcohol",
   "drug_brand": "Clear Defense",
   "patient_id": 760052236,
   "doctor_id": 11390
 },
 {
   "prescription_id": 881690775,
   "prescription_date": "2023-07-21",
   "medication": "Calcium citrate, Iron pentacarbonyl, Cholecalciferol, .Alpha.-Tocopherol, Dl-, Pyridoxine hydrochloride, Folic Acid, Docusate Sodium, and Doconexent",
   "drug_brand": "CitraNatal Harmony 3.0",
   "patient_id": 758646284,
   "doctor_id": 11391
 },
 {
   "prescription_id": 430431981,
   "prescription_date": "2023-08-06",
   "medication": "Citalopram hydrobromide",
   "drug_brand": "Citalopram hydrobromide",
   "patient_id": 223365582,
   "doctor_id": 11392
 },
 {
   "prescription_id": 351818361,
   "prescription_date": "2023-04-29",
   "medication": "Acetylcholine chloride, Dopamine, GABA, Octopamine, Serotonin, Taurine, Adenosinum cyclophosphoricum, Cerebrum (suis), Diencephalon (suis), Pineal gland (suis), Thalamus opticus (suis),",
   "drug_brand": "Brain Blance Core Formula",
   "patient_id": 715222613,
   "doctor_id": 11393
 },
 {
   "prescription_id": 894651423,
   "prescription_date": "2023-08-02",
   "medication": "Diltiazem HCl",
   "drug_brand": "Diltiazem HCl",
   "patient_id": 974261172,
   "doctor_id": 11394
 },
 {
   "prescription_id": 338046042,
   "prescription_date": "2022-12-24",
   "medication": "Treatment Set TS128811",
   "drug_brand": "Treatment Set TS128811",
   "patient_id": 455378373,
   "doctor_id": 11395
 },
 {
   "prescription_id": 245452192,
   "prescription_date": "2023-07-24",
   "medication": "GABAPENTIN",
   "drug_brand": "GABAPENTIN",
   "patient_id": 993573279,
   "doctor_id": 11396
 },
 {
   "prescription_id": 667105932,
   "prescription_date": "2023-07-21",
   "medication": "Bismuth subsalicylate",
   "drug_brand": "stomach relief",
   "patient_id": 429524030,
   "doctor_id": 11397
 },
 {
   "prescription_id": 826729846,
   "prescription_date": "2023-04-10",
   "medication": "Acetaminophen, dextromethorphan HBr, guaifenesin, Phenylephrine HCl",
   "drug_brand": "HealthMart Mucus Relief FM",
   "patient_id": 503292829,
   "doctor_id": 11398
 },
 {
   "prescription_id": 995457920,
   "prescription_date": "2023-04-11",
   "medication": "Polyethylene Glycol 400",
   "drug_brand": "CVS Long Lasting Lubricant Eye",
   "patient_id": 526234604,
   "doctor_id": 11399
 },
 {
   "prescription_id": 282618318,
   "prescription_date": "2023-09-25",
   "medication": "Norethindrone Acetate and Ethinyl Estradiol, and Ferrous Fumarate",
   "drug_brand": "Tilia Fe",
   "patient_id": 389263482,
   "doctor_id": 11400
 },
 {
   "prescription_id": 596043592,
   "prescription_date": "2023-05-24",
   "medication": "Stannous Fluoride",
   "drug_brand": "Home Care Fluoride",
   "patient_id": 423750746,
   "doctor_id": 11401
 },
 {
   "prescription_id": 448387542,
   "prescription_date": "2023-09-15",
   "medication": "ZOLPIDEM TARTRATE",
   "drug_brand": "ZOLPIDEM TARTRATE",
   "patient_id": 167149706,
   "doctor_id": 11402
 },
 {
   "prescription_id": 182767711,
   "prescription_date": "2023-02-16",
   "medication": "Allantoin",
   "drug_brand": "Whitening Repairing Cover Cushion",
   "patient_id": 725148885,
   "doctor_id": 11403
 },
 {
   "prescription_id": 46721888,
   "prescription_date": "2023-01-05",
   "medication": "Triticum aestivum, Chelidonium majus, Taraxacum officinale, Glutathione, Hepar suis, Thyroidinum (suis), Lycopodium clavatum, Nux vomica, Phosphoricum acidum,",
   "drug_brand": "Hepatatox",
   "patient_id": 271367290,
   "doctor_id": 11404
 },
 {
   "prescription_id": 590664994,
   "prescription_date": "2023-07-12",
   "medication": "Calcium carbonate",
   "drug_brand": "Antacid",
   "patient_id": 360920760,
   "doctor_id": 11405
 },
 {
   "prescription_id": 945848506,
   "prescription_date": "2023-01-08",
   "medication": "Sepia",
   "drug_brand": "Sepia",
   "patient_id": 351155334,
   "doctor_id": 11406
 },
 {
   "prescription_id": 399412928,
   "prescription_date": "2023-03-27",
   "medication": "Gerbil Epithelium",
   "drug_brand": "Gerbil Epithelium",
   "patient_id": 398053484,
   "doctor_id": 11407
 },
 {
   "prescription_id": 553565185,
   "prescription_date": "2023-01-25",
   "medication": "DIPHENDYDRAMINE HYDROCHLORIDE",
   "drug_brand": "DIPHENDYDRAMINE HYDROCHLORIDE",
   "patient_id": 446219873,
   "doctor_id": 11408
 },
 {
   "prescription_id": 826901275,
   "prescription_date": "2023-01-20",
   "medication": "OCTINOXATE, TITANIUM DIOXIDE",
   "drug_brand": "CD DIORSKIN NUDE SKIN-GLOWING MAKEUP SUNSCREEN BROAD SPECTRUM SPF 15 050 Dark Beige",
   "patient_id": 610671700,
   "doctor_id": 11409
 },
 {
   "prescription_id": 405292649,
   "prescription_date": "2022-11-26",
   "medication": "warfarin sodium",
   "drug_brand": "COUMADIN",
   "patient_id": 62402667,
   "doctor_id": 11410
 },
 {
   "prescription_id": 580323134,
   "prescription_date": "2023-11-10",
   "medication": "Acetaminophen",
   "drug_brand": "pain relief",
   "patient_id": 476321216,
   "doctor_id": 11411
 },
 {
   "prescription_id": 178689303,
   "prescription_date": "2023-02-04",
   "medication": "Pancreas, Stomach, Arsenicum album, Graphites, Lycopodium clavatum, Nux vomica, Phosphorus, Syzygium jambolanum,",
   "drug_brand": "Gastropanpar",
   "patient_id": 680145556,
   "doctor_id": 11412
 },
 {
   "prescription_id": 545628771,
   "prescription_date": "2023-08-03",
   "medication": "Terazosin",
   "drug_brand": "Terazosin",
   "patient_id": 636520697,
   "doctor_id": 11413
 },
 {
   "prescription_id": 648039486,
   "prescription_date": "2023-02-01",
   "medication": "Lenscale",
   "drug_brand": "Lenscale",
   "patient_id": 829420116,
   "doctor_id": 11414
 },
 {
   "prescription_id": 91474288,
   "prescription_date": "2022-12-03",
   "medication": "Titanium Dioxide",
   "drug_brand": "ck one 3-in-1 face makeup",
   "patient_id": 505455481,
   "doctor_id": 11415
 },
 {
   "prescription_id": 409812249,
   "prescription_date": "2023-08-16",
   "medication": "morphine sulfate",
   "drug_brand": "Kadian",
   "patient_id": 348420494,
   "doctor_id": 11416
 },
 {
   "prescription_id": 260588416,
   "prescription_date": "2023-06-13",
   "medication": "Dihydrocodeine Bitartrate, Phenylephrine Hydrochloride, Pyrilamine Maleate",
   "drug_brand": "POLY HIST",
   "patient_id": 677253395,
   "doctor_id": 11417
 },
 {
   "prescription_id": 283110160,
   "prescription_date": "2023-06-10",
   "medication": "Loratadine",
   "drug_brand": "Loratadine ODT",
   "patient_id": 835227317,
   "doctor_id": 11418
 },
 {
   "prescription_id": 769121426,
   "prescription_date": "2022-11-21",
   "medication": "Metoprolol Tartrate",
   "drug_brand": "Metoprolol Tartrate",
   "patient_id": 338410930,
   "doctor_id": 11419
 },
 {
   "prescription_id": 87265262,
   "prescription_date": "2023-06-19",
   "medication": "SAW PALMETTO and CALCIUM SULFIDE",
   "drug_brand": "Sabal Homaccord",
   "patient_id": 82516801,
   "doctor_id": 11420
 },
 {
   "prescription_id": 970369248,
   "prescription_date": "2022-12-22",
   "medication": "Amitriptyline Hydrochloride",
   "drug_brand": "Amitriptyline Hydrochloride",
   "patient_id": 490636288,
   "doctor_id": 11421
 },
 {
   "prescription_id": 126869490,
   "prescription_date": "2023-09-12",
   "medication": "Diclofenac Sodium",
   "drug_brand": "Diclofenac Sodium",
   "patient_id": 830911448,
   "doctor_id": 11422
 },
 {
   "prescription_id": 716944080,
   "prescription_date": "2023-02-04",
   "medication": "Paroxetine",
   "drug_brand": "Paroxetine",
   "patient_id": 307020250,
   "doctor_id": 11423
 },
 {
   "prescription_id": 942208866,
   "prescription_date": "2023-10-27",
   "medication": "Loratadine, Pseudoephedrine",
   "drug_brand": "wal itin d",
   "patient_id": 653344568,
   "doctor_id": 11424
 },
 {
   "prescription_id": 45482183,
   "prescription_date": "2023-09-13",
   "medication": "Desloratadine",
   "drug_brand": "Desloratadine",
   "patient_id": 803974891,
   "doctor_id": 11425
 },
 {
   "prescription_id": 997042991,
   "prescription_date": "2023-09-17",
   "medication": "Dimethicone",
   "drug_brand": "XtraCare with cooling action Oatmeal Skin Relief Calmin",
   "patient_id": 319052571,
   "doctor_id": 11426
 },
 {
   "prescription_id": 702325671,
   "prescription_date": "2023-03-27",
   "medication": "LEMON CHINESE QUINCE EXTRACT BERBERIS VULGARIS FRUIT SILICON DIOXIDE",
   "drug_brand": "Lemon Quince Allergy Relief",
   "patient_id": 456625759,
   "doctor_id": 11427
 },
 {
   "prescription_id": 563371964,
   "prescription_date": "2023-01-15",
   "medication": "CAPSAICIN",
   "drug_brand": "GOOD NEIGHBOR PHARMACY CAPSAICIN",
   "patient_id": 286802785,
   "doctor_id": 11428
 },
 {
   "prescription_id": 793820462,
   "prescription_date": "2023-02-28",
   "medication": "Octocrylene and Octinoxate",
   "drug_brand": "No7 CC",
   "patient_id": 160595895,
   "doctor_id": 11429
 },
 {
   "prescription_id": 932143186,
   "prescription_date": "2023-11-11",
   "medication": "Codeine Phosphate, Dexchorpheniramine Maleate, Phenylephrine Hydrochloride",
   "drug_brand": "PRO-RED",
   "patient_id": 394950834,
   "doctor_id": 11430
 },
 {
   "prescription_id": 438478845,
   "prescription_date": "2023-03-31",
   "medication": "ALCOHOL",
   "drug_brand": "FRESH SPLASH SCENTED HAND SANITIZER",
   "patient_id": 664878310,
   "doctor_id": 11431
 },
 {
   "prescription_id": 990078370,
   "prescription_date": "2023-10-31",
   "medication": "Adenosinum cyclophosphoricum, Adrenalinum, Adrenocorticotrophin, Allium cepa, Alnus serrulata, Carduus benedictus, Cichorium intybus, Cortisone aceticum, Dolichos pruriens, Euphrasia officinalis, Galphimia glauca, Histaminum hydrochloricum, Juglans cinerea, Kali muriaticum, Mucosa nasalis suis, Nasturtium, Natrum muriaticum, Rhus tox, RNA, Sabadilla, Sassafras officinale",
   "drug_brand": "AllergyEase Southern",
   "patient_id": 411640905,
   "doctor_id": 11432
 },
 {
   "prescription_id": 740074642,
   "prescription_date": "2023-02-13",
   "medication": "Methimazole",
   "drug_brand": "Methimazole",
   "patient_id": 766949552,
   "doctor_id": 11433
 },
 {
   "prescription_id": 863564595,
   "prescription_date": "2022-11-15",
   "medication": "Triclosan",
   "drug_brand": "Citrus Basil Antibacterial Foaming Hand Wash",
   "patient_id": 136525515,
   "doctor_id": 11434
 },
 {
   "prescription_id": 690509795,
   "prescription_date": "2023-05-20",
   "medication": "Anastrozole",
   "drug_brand": "Anastrozole",
   "patient_id": 629360169,
   "doctor_id": 11435
 },
 {
   "prescription_id": 400674037,
   "prescription_date": "2023-03-19",
   "medication": "GOSSYPIUM HERBACEUM ROOT BARK",
   "drug_brand": "Nausea",
   "patient_id": 978079253,
   "doctor_id": 11436
 },
 {
   "prescription_id": 375173414,
   "prescription_date": "2022-12-25",
   "medication": "CETIRIZINE HYDROCHLORIDE",
   "drug_brand": "CETIRIZINE HYDROCHLORIDE",
   "patient_id": 740012748,
   "doctor_id": 11437
 },
 {
   "prescription_id": 90641352,
   "prescription_date": "2023-07-17",
   "medication": "Coccus cacti, Drosera (Rotundifolia), Scilla maritima, Stica pulmonaria, Arsenicum iodatum, Causticum, Cuprum aceticum, Carbo vegetabilis, Kali carbonicum, Lachesis mutus,",
   "drug_brand": "Bronchial Cough",
   "patient_id": 634565899,
   "doctor_id": 11438
 },
 {
   "prescription_id": 462439265,
   "prescription_date": "2023-10-11",
   "medication": "BENZOYL PEROXIDE",
   "drug_brand": "ACNE TREATMENT SERUM",
   "patient_id": 170169666,
   "doctor_id": 11439
 },
 {
   "prescription_id": 163342584,
   "prescription_date": "2022-11-30",
   "medication": "Phentermine Hydrochloride",
   "drug_brand": "Phentermine Hydrochloride",
   "patient_id": 575653879,
   "doctor_id": 11440
 },
 {
   "prescription_id": 220801958,
   "prescription_date": "2023-08-26",
   "medication": "Phentermine Hydrochloride",
   "drug_brand": "Phentermine Hydrochloride",
   "patient_id": 613797911,
   "doctor_id": 11441
 },
 {
   "prescription_id": 385811128,
   "prescription_date": "2023-03-25",
   "medication": "Benzoyl Peroxide",
   "drug_brand": "Acne Treatment Kit",
   "patient_id": 805570965,
   "doctor_id": 11442
 },
 {
   "prescription_id": 334196513,
   "prescription_date": "2023-04-06",
   "medication": "SALICYLIC ACID",
   "drug_brand": "ACNE CLEANSING PADS",
   "patient_id": 533980153,
   "doctor_id": 11443
 },
 {
   "prescription_id": 141620302,
   "prescription_date": "2023-06-12",
   "medication": "SODIUM MONOFLUOROPHOSPHATE",
   "drug_brand": "Dental plus Baking Soda",
   "patient_id": 410895481,
   "doctor_id": 11444
 },
 {
   "prescription_id": 583219003,
   "prescription_date": "2023-04-27",
   "medication": "Mugwort",
   "drug_brand": "Mugwort",
   "patient_id": 172199378,
   "doctor_id": 11445
 },
 {
   "prescription_id": 82969947,
   "prescription_date": "2023-03-06",
   "medication": "Benztropine Mesylate",
   "drug_brand": "Benztropine Mesylate",
   "patient_id": 42603162,
   "doctor_id": 11446
 },
 {
   "prescription_id": 687295094,
   "prescription_date": "2023-02-10",
   "medication": "NIACIN",
   "drug_brand": "NIACIN",
   "patient_id": 457685546,
   "doctor_id": 11447
 },
 {
   "prescription_id": 290340026,
   "prescription_date": "2023-02-28",
   "medication": "Salicylic Acid",
   "drug_brand": "Santalia Clinical Acne",
   "patient_id": 737188999,
   "doctor_id": 11448
 },
 {
   "prescription_id": 613853292,
   "prescription_date": "2023-03-27",
   "medication": "Dimethicone",
   "drug_brand": "Remedy Skin Repair",
   "patient_id": 941996225,
   "doctor_id": 11449
 },
 {
   "prescription_id": 118448974,
   "prescription_date": "2023-05-07",
   "medication": "Cetirizine",
   "drug_brand": "Cetirizine Hydrochloride",
   "patient_id": 334830018,
   "doctor_id": 11450
 },
 {
   "prescription_id": 933801659,
   "prescription_date": "2023-06-19",
   "medication": "minoxidil",
   "drug_brand": "MINOXIDIL",
   "patient_id": 827834808,
   "doctor_id": 11451
 },
 {
   "prescription_id": 338336417,
   "prescription_date": "2023-08-31",
   "medication": "fluticasone propionate and salmeterol",
   "drug_brand": "ADVAIR",
   "patient_id": 82428620,
   "doctor_id": 11452
 },
 {
   "prescription_id": 478546078,
   "prescription_date": "2023-03-01",
   "medication": "Homosalate and Octinoxate and Octisalate and Oxybenzone and Avobenzone and Octocrylene",
   "drug_brand": "Banana Boat Ultra Defense SPF 30 Canada",
   "patient_id": 920397895,
   "doctor_id": 11453
 },
 {
   "prescription_id": 955072259,
   "prescription_date": "2023-06-03",
   "medication": "Phentermine Hydrochloride",
   "drug_brand": "Phentermine Hydrochloride",
   "patient_id": 598094261,
   "doctor_id": 11454
 },
 {
   "prescription_id": 398293507,
   "prescription_date": "2023-07-28",
   "medication": "methyldopa",
   "drug_brand": "Methyldopa",
   "patient_id": 710298268,
   "doctor_id": 11455
 },
 {
   "prescription_id": 99149250,
   "prescription_date": "2023-03-11",
   "medication": "Acetaminophen, Dextromethorphan HBr, Guaifenesin, Phenylephrine HCl",
   "drug_brand": "Severe Cold and Congestion Maximum Strength",
   "patient_id": 544336421,
   "doctor_id": 11456
 },
 {
   "prescription_id": 994939009,
   "prescription_date": "2023-03-24",
   "medication": "Live Oak",
   "drug_brand": "Live Oak",
   "patient_id": 701693862,
   "doctor_id": 11457
 },
 {
   "prescription_id": 139790977,
   "prescription_date": "2023-11-10",
   "medication": "certolizumab pegol",
   "drug_brand": "Cimzia",
   "patient_id": 617236500,
   "doctor_id": 11458
 },
 {
   "prescription_id": 340338147,
   "prescription_date": "2022-12-18",
   "medication": "BENZALKONIUM CHLORIDE",
   "drug_brand": "SANITACK SANITIZING WIPES PLUS",
   "patient_id": 426606480,
   "doctor_id": 11459
 },
 {
   "prescription_id": 153244944,
   "prescription_date": "2023-06-15",
   "medication": "Cyclobenzaprine Hydrochloride",
   "drug_brand": "Cyclobenzaprine Hydrochloride",
   "patient_id": 954134662,
   "doctor_id": 11460
 },
 {
   "prescription_id": 550963175,
   "prescription_date": "2023-04-27",
   "medication": "OCTINOXATE and TITANIUM DIOXIDE",
   "drug_brand": "SHISEIDO RADIANT LIFTING FOUNDATION",
   "patient_id": 970865766,
   "doctor_id": 11461
 },
 {
   "prescription_id": 954317746,
   "prescription_date": "2023-10-06",
   "medication": "Simvastatin",
   "drug_brand": "Simvastatin",
   "patient_id": 483638406,
   "doctor_id": 11462
 },
 {
   "prescription_id": 792485043,
   "prescription_date": "2023-05-14",
   "medication": "Diphenhydramine HCl",
   "drug_brand": "sleep time",
   "patient_id": 705580317,
   "doctor_id": 11463
 },
 {
   "prescription_id": 597910298,
   "prescription_date": "2022-12-18",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 799059055,
   "doctor_id": 11464
 },
 {
   "prescription_id": 517999398,
   "prescription_date": "2022-12-16",
   "medication": "Triclosan",
   "drug_brand": "Pomegranate Antibacterial Foaming Hand Wash",
   "patient_id": 17338453,
   "doctor_id": 11465
 },
 {
   "prescription_id": 425448195,
   "prescription_date": "2023-07-20",
   "medication": "Acetaminophen, Dextromethorphan HBr, Chlorpheniramine maleate",
   "drug_brand": "Maximum Strength Flu HBP",
   "patient_id": 377306027,
   "doctor_id": 11466
 },
 {
   "prescription_id": 200356955,
   "prescription_date": "2023-11-03",
   "medication": "Octreotide acetate",
   "drug_brand": "Octreotide acetate",
   "patient_id": 588625438,
   "doctor_id": 11467
 },
 {
   "prescription_id": 224932690,
   "prescription_date": "2023-05-06",
   "medication": "Ranitidine",
   "drug_brand": "Good Neighbor Pharmacy Acid Control 150",
   "patient_id": 858545236,
   "doctor_id": 11468
 },
 {
   "prescription_id": 87702350,
   "prescription_date": "2023-07-08",
   "medication": "Azithromycin",
   "drug_brand": "Azithromycin",
   "patient_id": 207627194,
   "doctor_id": 11469
 },
 {
   "prescription_id": 31905340,
   "prescription_date": "2023-08-15",
   "medication": "Sodium Monofluorophosphate",
   "drug_brand": "United Airlines Business Class Kit",
   "patient_id": 886836391,
   "doctor_id": 11470
 },
 {
   "prescription_id": 35090995,
   "prescription_date": "2023-07-25",
   "medication": "OXYBUTYNIN CHLORIDE",
   "drug_brand": "OXYBUTYNIN CHLORIDE",
   "patient_id": 357098270,
   "doctor_id": 11471
 },
 {
   "prescription_id": 140758241,
   "prescription_date": "2023-03-25",
   "medication": "Hydrocortisone",
   "drug_brand": "Apres Peel Soothing Balm",
   "patient_id": 749114152,
   "doctor_id": 11472
 },
 {
   "prescription_id": 689750741,
   "prescription_date": "2023-09-20",
   "medication": "GABAPENTIN",
   "drug_brand": "GABAPENTIN",
   "patient_id": 642128006,
   "doctor_id": 11473
 },
 {
   "prescription_id": 875579948,
   "prescription_date": "2023-06-12",
   "medication": "aluminum chlorohydrate",
   "drug_brand": "Fresh Sugar Roll-On Deodorant Antiperspirant",
   "patient_id": 54104016,
   "doctor_id": 11474
 },
 {
   "prescription_id": 43208299,
   "prescription_date": "2023-05-10",
   "medication": "Amoxicillin and Clavulanate Potassium",
   "drug_brand": "Amoxicillin and Clavulanate Potassium",
   "patient_id": 65340054,
   "doctor_id": 11475
 },
 {
   "prescription_id": 287101098,
   "prescription_date": "2023-07-05",
   "medication": "BISMUTH SUBSALICYLATE",
   "drug_brand": "Peptic Relief",
   "patient_id": 127514732,
   "doctor_id": 11476
 },
 {
   "prescription_id": 733900,
   "prescription_date": "2023-08-04",
   "medication": "Sodium Fluoride",
   "drug_brand": "Walgreen Anticavity Whitening",
   "patient_id": 603227507,
   "doctor_id": 11477
 },
 {
   "prescription_id": 891925600,
   "prescription_date": "2022-12-21",
   "medication": "Methyl Salicylate and Menthol",
   "drug_brand": "Noble Lion Medicated Balm",
   "patient_id": 793312476,
   "doctor_id": 11478
 },
 {
   "prescription_id": 135100904,
   "prescription_date": "2023-04-19",
   "medication": "ACARBOSE",
   "drug_brand": "Acarbose",
   "patient_id": 926837897,
   "doctor_id": 11479
 },
 {
   "prescription_id": 839849900,
   "prescription_date": "2022-12-30",
   "medication": "TITANIUM DIOXIDE",
   "drug_brand": "SHISEIDO THE MAKEUP FOUNDATION",
   "patient_id": 651066349,
   "doctor_id": 11480
 },
 {
   "prescription_id": 534266192,
   "prescription_date": "2023-10-02",
   "medication": "Octinoxate",
   "drug_brand": "Purminerals 4-in-1 14-Hour Wear Foundation Broad Spectrum SPF 15 (BLUSH MEDIUM)",
   "patient_id": 738850041,
   "doctor_id": 11481
 },
 {
   "prescription_id": 934481359,
   "prescription_date": "2023-06-20",
   "medication": "Diphenhydramine HCl",
   "drug_brand": "Sleep Aid",
   "patient_id": 905531458,
   "doctor_id": 11482
 },
 {
   "prescription_id": 482491371,
   "prescription_date": "2023-04-30",
   "medication": "Fluocinolone Acetonide",
   "drug_brand": "Retisert",
   "patient_id": 202945400,
   "doctor_id": 11483
 },
 {
   "prescription_id": 22442498,
   "prescription_date": "2023-09-14",
   "medication": "Queen Palm",
   "drug_brand": "Queen Palm",
   "patient_id": 948692529,
   "doctor_id": 11484
 },
 {
   "prescription_id": 218291623,
   "prescription_date": "2023-03-25",
   "medication": "OCTINOXATE and TITANIUM DIOXIDE",
   "drug_brand": "NARS FOUNDATION",
   "patient_id": 954112687,
   "doctor_id": 11485
 },
 {
   "prescription_id": 304866080,
   "prescription_date": "2023-10-18",
   "medication": "Oxycodone",
   "drug_brand": "Oxycodone Hydrochloride",
   "patient_id": 353318290,
   "doctor_id": 11486
 },
 {
   "prescription_id": 788181635,
   "prescription_date": "2023-10-13",
   "medication": "Carisoprodol",
   "drug_brand": "Carisoprodol",
   "patient_id": 38612144,
   "doctor_id": 11487
 },
 {
   "prescription_id": 802324303,
   "prescription_date": "2023-04-20",
   "medication": "Octinoxate, Titanium Dioxide",
   "drug_brand": "Sheer Defense Tinted Moisturizer SPF 15 ML 40",
   "patient_id": 878198207,
   "doctor_id": 11488
 },
 {
   "prescription_id": 662077738,
   "prescription_date": "2023-08-23",
   "medication": "Sodium Acetate",
   "drug_brand": "Sodium Acetate",
   "patient_id": 30260222,
   "doctor_id": 11489
 },
 {
   "prescription_id": 408703234,
   "prescription_date": "2023-10-17",
   "medication": "GLYCERIN",
   "drug_brand": "MIRU Oriental Whitening Ampoule",
   "patient_id": 416034690,
   "doctor_id": 11490
 },
 {
   "prescription_id": 429121311,
   "prescription_date": "2023-01-19",
   "medication": "JATROPHA CURCAS SEED",
   "drug_brand": "STOMACH CRAMPS",
   "patient_id": 865213684,
   "doctor_id": 11491
 },
 {
   "prescription_id": 412788829,
   "prescription_date": "2022-12-31",
   "medication": "Carvedilol",
   "drug_brand": "Carvedilol",
   "patient_id": 693441454,
   "doctor_id": 11492
 },
 {
   "prescription_id": 925538491,
   "prescription_date": "2023-07-27",
   "medication": "SODIUM MONOFLUOROPHOSPHATE",
   "drug_brand": "Dental guardian",
   "patient_id": 595184482,
   "doctor_id": 11493
 },
 {
   "prescription_id": 503086699,
   "prescription_date": "2023-09-29",
   "medication": "Timolol Maleate",
   "drug_brand": "Timolol Maleate",
   "patient_id": 36541113,
   "doctor_id": 11494
 },
 {
   "prescription_id": 852873389,
   "prescription_date": "2023-06-13",
   "medication": "POTASSIUM CHLORIDE",
   "drug_brand": "POTASSIUM CHLORIDE",
   "patient_id": 267413981,
   "doctor_id": 11495
 },
 {
   "prescription_id": 511120621,
   "prescription_date": "2023-08-19",
   "medication": "Nefazodone Hydrochloride",
   "drug_brand": "Nefazodone Hydrochloride",
   "patient_id": 118145479,
   "doctor_id": 11496
 },
 {
   "prescription_id": 357651368,
   "prescription_date": "2023-07-30",
   "medication": "Glycerin",
   "drug_brand": "Infant Glycerin Laxative",
   "patient_id": 56538788,
   "doctor_id": 11497
 },
 {
   "prescription_id": 870431441,
   "prescription_date": "2023-07-30",
   "medication": "Pyrithione Zinc",
   "drug_brand": "Clear",
   "patient_id": 631870869,
   "doctor_id": 11498
 },
 {
   "prescription_id": 873840672,
   "prescription_date": "2023-07-04",
   "medication": "Niacinamide",
   "drug_brand": "A.H.C. C-SERUM",
   "patient_id": 627832947,
   "doctor_id": 11499
 },
 {
   "prescription_id": 13308260,
   "prescription_date": "2023-10-22",
   "medication": "glycerin, phenylephrine HCl, pramoxine HCl, white petrolatum",
   "drug_brand": "hemorrhoidal",
   "patient_id": 963998441,
   "doctor_id": 11500
 },
 {
   "prescription_id": 621031025,
   "prescription_date": "2022-11-14",
   "medication": "SALICYLIC ACID",
   "drug_brand": "ACNE",
   "patient_id": 783858327,
   "doctor_id": 11501
 },
 {
   "prescription_id": 840453275,
   "prescription_date": "2023-08-12",
   "medication": "Nicotine Polacrilex",
   "drug_brand": "nicorelief",
   "patient_id": 787822005,
   "doctor_id": 11502
 },
 {
   "prescription_id": 4890573,
   "prescription_date": "2023-06-12",
   "medication": "fentanyl",
   "drug_brand": "DURAGESIC",
   "patient_id": 751031194,
   "doctor_id": 11503
 },
 {
   "prescription_id": 996167606,
   "prescription_date": "2023-02-25",
   "medication": "Guaifenesin",
   "drug_brand": "Shopko Chest Congestion Relief",
   "patient_id": 655100135,
   "doctor_id": 11504
 },
 {
   "prescription_id": 759978817,
   "prescription_date": "2023-03-12",
   "medication": "Benzethonium Chloride",
   "drug_brand": "Vanilla Bean Anti-bacterial foaming Hand Wash",
   "patient_id": 668110119,
   "doctor_id": 11505
 },
 {
   "prescription_id": 913923318,
   "prescription_date": "2023-06-18",
   "medication": "Adenosine",
   "drug_brand": "Adenosine",
   "patient_id": 686409607,
   "doctor_id": 11506
 },
 {
   "prescription_id": 341385643,
   "prescription_date": "2023-05-27",
   "medication": "Sucralfate",
   "drug_brand": "Sucralfate",
   "patient_id": 759161476,
   "doctor_id": 11507
 },
 {
   "prescription_id": 608179847,
   "prescription_date": "2023-01-20",
   "medication": "Ofloxaxin",
   "drug_brand": "Ofloxacin",
   "patient_id": 569000498,
   "doctor_id": 11508
 },
 {
   "prescription_id": 916772277,
   "prescription_date": "2023-07-07",
   "medication": "Hand Sanitizer Wipes",
   "drug_brand": "Tough Guy Hand Sanitizer Wipes",
   "patient_id": 53392125,
   "doctor_id": 11509
 },
 {
   "prescription_id": 541117079,
   "prescription_date": "2023-02-28",
   "medication": "methylprednisolone",
   "drug_brand": "Methylprednisolone",
   "patient_id": 355821067,
   "doctor_id": 11510
 },
 {
   "prescription_id": 233286180,
   "prescription_date": "2023-09-02",
   "medication": "Desloratadine",
   "drug_brand": "Desloratadine",
   "patient_id": 190058585,
   "doctor_id": 11511
 },
 {
   "prescription_id": 459133712,
   "prescription_date": "2023-10-31",
   "medication": "Sodium Fluoride",
   "drug_brand": "CLOSE UP",
   "patient_id": 795916875,
   "doctor_id": 11512
 },
 {
   "prescription_id": 213791608,
   "prescription_date": "2023-01-26",
   "medication": "Omeprazole",
   "drug_brand": "leader omeprazole",
   "patient_id": 904946044,
   "doctor_id": 11513
 },
 {
   "prescription_id": 766444189,
   "prescription_date": "2023-06-26",
   "medication": "Benzalkonium chloride",
   "drug_brand": "Hand Wash",
   "patient_id": 750457543,
   "doctor_id": 11514
 },
 {
   "prescription_id": 665389352,
   "prescription_date": "2023-05-25",
   "medication": "Aspirin",
   "drug_brand": "Aspirin",
   "patient_id": 911206717,
   "doctor_id": 11515
 },
 {
   "prescription_id": 808510805,
   "prescription_date": "2023-01-16",
   "medication": "Acetaminophen",
   "drug_brand": "TYLENOL",
   "patient_id": 978085718,
   "doctor_id": 11516
 },
 {
   "prescription_id": 627721778,
   "prescription_date": "2023-09-22",
   "medication": "VITAMIN A PALMITATE, ASCORBIC ACID, CHOLECALCIFEROL, .ALPHA.-TOCOPHEROL ACETATE, D-, THIAMINE HYDROCHLORIDE, RIBOFLAVIN, NIACIN, PYRIDOXINE HYDROCHLORIDE, CYANOCOBALAMIN, FERRIC PYROPHOSPHATE, FERROUS CYSTEINE GLYCINATE, and SODIUM FLUORIDE",
   "drug_brand": "ESCAVITE LQ",
   "patient_id": 772647129,
   "doctor_id": 11517
 },
 {
   "prescription_id": 772568374,
   "prescription_date": "2023-01-20",
   "medication": "LISINOPRIL",
   "drug_brand": "Lisinopril",
   "patient_id": 644204092,
   "doctor_id": 11518
 },
 {
   "prescription_id": 62572268,
   "prescription_date": "2023-03-28",
   "medication": "Amlodipine Besylate",
   "drug_brand": "Amlodipine Besylate",
   "patient_id": 927165195,
   "doctor_id": 11519
 },
 {
   "prescription_id": 539240740,
   "prescription_date": "2023-01-15",
   "medication": "Ranitidine",
   "drug_brand": "good sense acid reducer",
   "patient_id": 418668646,
   "doctor_id": 11520
 },
 {
   "prescription_id": 22610471,
   "prescription_date": "2023-06-25",
   "medication": "Ondansetron",
   "drug_brand": "Ondansetron",
   "patient_id": 400366873,
   "doctor_id": 11521
 },
 {
   "prescription_id": 873927051,
   "prescription_date": "2023-05-30",
   "medication": "Berberis Vulgaris, Cantharis, Clematis Erecta, Lac Caninum, Lycopodium Clavatum, Pulsatilla, Sarsaparilla",
   "drug_brand": "Cystoges HP",
   "patient_id": 604383105,
   "doctor_id": 11522
 },
 {
   "prescription_id": 115247276,
   "prescription_date": "2022-11-15",
   "medication": "Hydroxyamphetamine hydrobromide, tropicamide",
   "drug_brand": "Paremyd",
   "patient_id": 786646728,
   "doctor_id": 11523
 },
 {
   "prescription_id": 403929380,
   "prescription_date": "2023-01-19",
   "medication": "ARNICA MONTANA",
   "drug_brand": "Arnica",
   "patient_id": 747988027,
   "doctor_id": 11524
 },
 {
   "prescription_id": 780055903,
   "prescription_date": "2023-05-10",
   "medication": "Ibuprofen",
   "drug_brand": "Ibuprofen",
   "patient_id": 515946802,
   "doctor_id": 11525
 },
 {
   "prescription_id": 106368338,
   "prescription_date": "2023-06-24",
   "medication": "Morphine Sulfate",
   "drug_brand": "Morphine Sulfate",
   "patient_id": 421660732,
   "doctor_id": 11526
 },
 {
   "prescription_id": 226837777,
   "prescription_date": "2023-11-03",
   "medication": "venlafaxine hydrochloride",
   "drug_brand": "venlafaxine",
   "patient_id": 123224346,
   "doctor_id": 11527
 },
 {
   "prescription_id": 283629364,
   "prescription_date": "2022-12-13",
   "medication": "ATORVASTATIN CALCIUM",
   "drug_brand": "ATORVASTATIN CALCIUM",
   "patient_id": 298641329,
   "doctor_id": 11528
 },
 {
   "prescription_id": 689990914,
   "prescription_date": "2023-11-12",
   "medication": "Mirtazapine",
   "drug_brand": "MIRTAZAPINE",
   "patient_id": 544608506,
   "doctor_id": 11529
 },
 {
   "prescription_id": 217145466,
   "prescription_date": "2023-07-18",
   "medication": "Phenylephrine HCl, Witch hazel",
   "drug_brand": "Equaline hemorrhoidal cooling",
   "patient_id": 305845556,
   "doctor_id": 11530
 },
 {
   "prescription_id": 456053693,
   "prescription_date": "2023-08-09",
   "medication": "OCTISALATE, OCTINOXATE, ZINC OXIDE",
   "drug_brand": "SOLAR SENSE CLEAR ZINC SUNSCREEN FACE and BODY SPORT BROAD SPECTRUM SPF 50 Plus",
   "patient_id": 635180616,
   "doctor_id": 11531
 },
 {
   "prescription_id": 735964542,
   "prescription_date": "2023-02-16",
   "medication": "coagulation factor ix (recombinant)",
   "drug_brand": "BeneFIX",
   "patient_id": 254289496,
   "doctor_id": 11532
 },
 {
   "prescription_id": 510784768,
   "prescription_date": "2022-12-10",
   "medication": "Titanium Dioxide, Ethylhexyl Methoxycinnamate, Ethylhexyl Salicylate",
   "drug_brand": "IQueen CCC Light",
   "patient_id": 744132499,
   "doctor_id": 11533
 },
 {
   "prescription_id": 122417593,
   "prescription_date": "2023-10-11",
   "medication": "indocyanine green",
   "drug_brand": "IC-Green",
   "patient_id": 838486941,
   "doctor_id": 11534
 },
 {
   "prescription_id": 655807151,
   "prescription_date": "2023-05-27",
   "medication": "Ciprofloxacin",
   "drug_brand": "Ciprofloxacin",
   "patient_id": 14003406,
   "doctor_id": 11535
 },
 {
   "prescription_id": 203800247,
   "prescription_date": "2023-03-03",
   "medication": "oxymetazoline hydrochloride",
   "drug_brand": "care one nasal",
   "patient_id": 2232128,
   "doctor_id": 11536
 },
 {
   "prescription_id": 249314599,
   "prescription_date": "2023-06-03",
   "medication": "Trazodone Hydrochloride",
   "drug_brand": "Trazodone Hydrochloride",
   "patient_id": 937385430,
   "doctor_id": 11537
 },
 {
   "prescription_id": 746678791,
   "prescription_date": "2023-10-29",
   "medication": "Midazolam hydrochloride",
   "drug_brand": "Midazolam hydrochloride",
   "patient_id": 568706422,
   "doctor_id": 11538
 },
 {
   "prescription_id": 233185944,
   "prescription_date": "2023-07-30",
   "medication": "Dextromethorphan Hydrobromide and Promethazine Hydrochloride",
   "drug_brand": "Dextromethorphan Hydrobromide and Promethazine Hydrochloride",
   "patient_id": 872187881,
   "doctor_id": 11539
 },
 {
   "prescription_id": 409138671,
   "prescription_date": "2023-08-26",
   "medication": "Cetirizine Hydrochloride",
   "drug_brand": "Cetirizine Hydrochloride",
   "patient_id": 216523313,
   "doctor_id": 11540
 },
 {
   "prescription_id": 911909673,
   "prescription_date": "2022-12-11",
   "medication": "Ethyl Alcohol",
   "drug_brand": "Antibacterial Hand Towelettes",
   "patient_id": 84624609,
   "doctor_id": 11541
 },
 {
   "prescription_id": 514328790,
   "prescription_date": "2023-04-30",
   "medication": "Atenolol",
   "drug_brand": "Atenolol",
   "patient_id": 335106388,
   "doctor_id": 11542
 },
 {
   "prescription_id": 750198281,
   "prescription_date": "2023-03-30",
   "medication": "Fludrocortisone Acetate",
   "drug_brand": "Fludrocortisone Acetate",
   "patient_id": 878716595,
   "doctor_id": 11543
 },
 {
   "prescription_id": 321897426,
   "prescription_date": "2022-12-06",
   "medication": "galantamine hydrobromide",
   "drug_brand": "Galantamine",
   "patient_id": 666832461,
   "doctor_id": 11544
 },
 {
   "prescription_id": 502127591,
   "prescription_date": "2023-05-07",
   "medication": "Oxygen",
   "drug_brand": "Oxygen",
   "patient_id": 710642619,
   "doctor_id": 11545
 },
 {
   "prescription_id": 476376747,
   "prescription_date": "2023-02-16",
   "medication": "Trace Elements 4",
   "drug_brand": "Multitrace-4",
   "patient_id": 831776062,
   "doctor_id": 11546
 },
 {
   "prescription_id": 129561187,
   "prescription_date": "2022-11-21",
   "medication": "Promethazinehydrochloride and phenylephrine hydrochloride",
   "drug_brand": "Promethazine VC",
   "patient_id": 786222900,
   "doctor_id": 11547
 },
 {
   "prescription_id": 222332977,
   "prescription_date": "2023-11-12",
   "medication": "Venlafaxine",
   "drug_brand": "Venlafaxine",
   "patient_id": 515400834,
   "doctor_id": 11548
 },
 {
   "prescription_id": 140534956,
   "prescription_date": "2023-02-06",
   "medication": "Salicylic Acid",
   "drug_brand": "Clearasil Ultra",
   "patient_id": 952690846,
   "doctor_id": 11549
 },
 {
   "prescription_id": 142156147,
   "prescription_date": "2023-11-10",
   "medication": "Rabbit Hair",
   "drug_brand": "Rabbit Hair",
   "patient_id": 841533027,
   "doctor_id": 11550
 },
 {
   "prescription_id": 257129064,
   "prescription_date": "2023-04-29",
   "medication": "amlodipine besylate and valsartan",
   "drug_brand": "Exforge",
   "patient_id": 654504908,
   "doctor_id": 11551
 }
]);

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for insertion: " + timeTaken + " milliseconds");