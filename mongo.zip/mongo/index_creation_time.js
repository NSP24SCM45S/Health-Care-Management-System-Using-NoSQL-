// Record the start time
var startTime = new Date();

db.appointment.createIndex({ "prescription_id": 1 }, { unique: true });

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for index creation: " + timeTaken + " milliseconds");