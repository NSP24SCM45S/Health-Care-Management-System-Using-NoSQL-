// Record the start time
var startTime = new Date();

// Run the aggregate query and capture the results
var aggregationPipeline = [
  {
    $group: {
      _id: null,
      Averageprem: { $avg: "$premium_amount" }
    }
  }
];

var aggregateResults = db.Insurance.aggregate(aggregationPipeline).toArray();

// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print only the average value
if (aggregateResults.length > 0) {
  print("Average Premium Amount: " + aggregateResults[0].Averageprem);
} else {
  print("No results found.");
}

// Print the time taken
print("Query time: " + timeTaken + " milliseconds");
