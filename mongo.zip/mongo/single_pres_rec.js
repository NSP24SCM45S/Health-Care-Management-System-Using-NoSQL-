// Record the start time
var startTime = new Date();

var newDocument = {
   "prescription_id": 4777777777,
   "prescription_date": "2023-01-03",
   "medication": "Promethazine",
   "drug_brand": "chloro",
   "patient_id": 22195242,
   "doctor_id": 11304
 };

db.Prescription.insertOne(newDocument);


// Record the end time
var endTime = new Date();

// Calculate the time taken
var timeTaken = endTime - startTime;

// Print the time taken
print("Time taken for single record insertion: " + timeTaken + " milliseconds");